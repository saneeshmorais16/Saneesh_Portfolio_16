# Iris - AI Job Search Assistant

Iris is a local FastAPI, SQLite, and vanilla JavaScript assistant for Saneesh Morais's job search. It helps search safely, score roles, track applications, tailor CV plans, draft recruiter messages, prepare interviews, manage follow-ups, and use push-to-talk voice where the browser supports it.

The app works without Gemini or OpenAI keys. When keys are missing, Iris uses deterministic matching, keyword extraction, local templates, SQLite tracking, and rule-based workflows.

## Windows Setup

```cmd
cd /d "C:\Users\sanee\AppData\Local\Programs\Python\Python313\Iris_python_assistant_v2"
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn iris.main:app --reload
```

Open:

```text
http://127.0.0.1:8000/dashboard
```

The older entry point also works:

```cmd
uvicorn backend.main:app --reload
```

## Environment

Create `.env` from `.env.example` only if you want to configure keys or paths.

```text
GEMINI_API_KEY=
OPENAI_API_KEY=
IRIS_DEFAULT_LOCATION=London
IRIS_DEFAULT_EMAIL=saneeshmorais@gmail.com
IRIS_DB_PATH=./data/iris.db
```

No real `.env` file is required for local offline mode.

## Add and Score a Job

1. Open `/dashboard`.
2. Paste the full job description into `Paste Job Description`.
3. Add any known company, role, source, or application link fields.
4. Select `Analyse, Score, and Save`.

Iris extracts company, role, location, work type, salary, deadlines, intake dates, skills, experience, degree notes, visa notes, seniority, category, risk flags, and a match score out of 10.

By default, saved job views show roles scoring 7+ unless `Show all` is enabled.

## Search Jobs

Use `Search Jobs` or the command bar with prompts such as:

```text
Iris, find junior AI internships in London posted this week
Iris, find September 2026 graduate software roles
Iris, find January 2027 AI or data placements
```

Iris builds safe source-adapter links for UK job boards. It does not depend on fragile scraping. Open a source link, then paste strong descriptions back into Iris for extraction and scoring.

## Track Applications

Use `Track` on a saved job to create an application record. Supported statuses are:

```text
Found, Shortlisted, CV Needed, CV Tailored, Applied, Assessment, Interview, Follow-Up, Rejected, Offer, Archived
```

Marking a role as applied requires explicit approval through the API. Archiving or deleting a job also requires approval.

## Tailor a CV

Use `CV Tailoring Workspace` with a saved job or pasted description.

Workflow:

1. Analyse the job.
2. Create a rewrite plan.
3. Review extracted keywords and selected projects.
4. Tick approval before generating final LaTeX.

Iris does not generate final LaTeX until approval is provided. The generated CV plan uses only Saneesh's real evidence and preserves the fixed metrics 72% to 85%, 30%, 15%, and 10%.

## Recruiter Messages

Use `Recruiter Message Writer` to draft:

- Recruiter messages
- LinkedIn-style notes
- Application follow-ups
- Interview thank-you emails

Iris drafts only. It does not send emails or messages automatically.

## Interview Preparation

Use `Interview Preparation Panel` with a saved job or role context. Iris creates:

- Why this company
- Why this role
- Tell me about yourself
- 30-second pitch
- STAR examples
- Project explanations
- Technical questions
- Questions to ask
- Weak areas
- Screening questions
- Preparation checklist

## Voice Mode

Use `Talk to Iris` in a browser that supports the Web Speech API, such as Chrome or Edge. Iris uses browser speech recognition and browser speech synthesis where available.

If voice is unavailable, the dashboard shows a message and text chat continues to work.

Wake word behavior is push-to-talk only. If the transcript starts with `Iris,`, the app removes it before processing the command.

## Configure Gemini or OpenAI

Add keys to `.env` and restart the server:

```text
GEMINI_API_KEY=your_key_here
OPENAI_API_KEY=your_key_here
```

The app never requires these keys to start.

## Reset the Local Database

Stop the server, then remove the SQLite file:

```cmd
del data\iris.db
```

Restart:

```cmd
uvicorn iris.main:app --reload
```

Iris recreates the database tables automatically.

## Main API Routes

- `GET /` and `GET /dashboard`
- `POST /api/agent/chat`
- `POST /api/agent/voice-command`
- `POST /api/jobs/search`
- `POST /api/jobs/add`
- `GET /api/jobs`
- `GET /api/jobs/{job_id}`
- `PATCH /api/jobs/{job_id}`
- `DELETE /api/jobs/{job_id}`
- `POST /api/jobs/{job_id}/score`
- `POST /api/jobs/{job_id}/shortlist`
- `POST /api/jobs/{job_id}/archive`
- `GET /api/applications`
- `POST /api/applications`
- `PATCH /api/applications/{application_id}`
- `POST /api/cv/analyse-job`
- `POST /api/cv/rewrite-plan`
- `POST /api/cv/generate-latex`
- `POST /api/messages/recruiter`
- `POST /api/messages/follow-up`
- `POST /api/messages/thank-you`
- `POST /api/interviews/prepare`
- `GET /api/reminders`
- `POST /api/reminders`
- `PATCH /api/reminders/{reminder_id}`
- `GET /api/audit`
- `GET /api/memory`
- `PATCH /api/memory/preferences`
