from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AgentCommandRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=12000)
    speak: bool = False


class VoiceCommandRequest(BaseModel):
    transcript: str = Field(..., min_length=1, max_length=12000)


class AgentResponse(BaseModel):
    reply: str
    intent: str
    action_plan: List[str]
    risk_level: str
    approval_required: bool = False
    data: Dict[str, Any] = Field(default_factory=dict)
    spoken_response: Optional[str] = None


class JobSearchRequest(BaseModel):
    query: Optional[str] = None
    role_type: Optional[str] = None
    location: Optional[str] = None
    work_type: Optional[str] = None
    date_posted: Optional[str] = None
    start_date: Optional[str] = None
    company_size: Optional[str] = None
    skills: List[str] = Field(default_factory=list)
    salary: Optional[str] = None
    source: Optional[str] = None
    minimum_match_score: float = 7


class JobCreateRequest(BaseModel):
    company_name: Optional[str] = None
    role_title: Optional[str] = None
    location: Optional[str] = None
    work_type: Optional[str] = None
    salary: Optional[str] = None
    date_posted: Optional[str] = None
    deadline: Optional[str] = None
    intake_start: Optional[str] = None
    source: Optional[str] = None
    application_url: Optional[str] = None
    description: str = Field(..., min_length=1, max_length=60000)
    notes: Optional[str] = None
    status: Optional[str] = None


class JobUpdateRequest(BaseModel):
    company_name: Optional[str] = None
    role_title: Optional[str] = None
    location: Optional[str] = None
    work_type: Optional[str] = None
    salary: Optional[str] = None
    date_posted: Optional[str] = None
    deadline: Optional[str] = None
    intake_start: Optional[str] = None
    source: Optional[str] = None
    application_url: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    notes: Optional[str] = None
    approved: bool = False


class ApplicationCreateRequest(BaseModel):
    job_id: Optional[int] = None
    company_name: Optional[str] = None
    role_title: Optional[str] = None
    status: str = "Found"
    stage_notes: Optional[str] = None
    applied_at: Optional[str] = None
    follow_up_at: Optional[str] = None
    approved: bool = False


class ApplicationUpdateRequest(BaseModel):
    status: Optional[str] = None
    stage_notes: Optional[str] = None
    applied_at: Optional[str] = None
    follow_up_at: Optional[str] = None
    approved: bool = False


class CVAnalyseRequest(BaseModel):
    job_id: Optional[int] = None
    job_description: Optional[str] = Field(default=None, max_length=60000)


class CVGenerateRequest(BaseModel):
    job_id: Optional[int] = None
    job_description: Optional[str] = Field(default=None, max_length=60000)
    rewrite_plan: Optional[str] = None
    approved: bool = False


class MessageRequest(BaseModel):
    job_id: Optional[int] = None
    job_description: Optional[str] = Field(default=None, max_length=60000)
    message_type: str = "recruiter"
    recipient_name: Optional[str] = None
    company_name: Optional[str] = None
    role_title: Optional[str] = None


class InterviewPrepRequest(BaseModel):
    job_id: Optional[int] = None
    job_description: Optional[str] = Field(default=None, max_length=60000)
    company_name: Optional[str] = None
    role_title: Optional[str] = None


class ReminderCreateRequest(BaseModel):
    job_id: Optional[int] = None
    application_id: Optional[int] = None
    title: str = Field(..., min_length=1, max_length=500)
    due_at: Optional[str] = None


class ReminderUpdateRequest(BaseModel):
    title: Optional[str] = None
    due_at: Optional[str] = None
    status: Optional[str] = None
    approved: bool = False


class MemoryUpdateRequest(BaseModel):
    preferences: Dict[str, Any]
    approved: bool = False

