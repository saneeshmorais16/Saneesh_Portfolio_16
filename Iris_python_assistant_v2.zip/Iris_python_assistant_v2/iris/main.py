from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from iris.config import APP_NAME, STATIC_DIR
from iris.database import init_db
from iris.routes import agent, applications, audit, cv, dashboard, interviews, jobs, memory, messages, reminders, voice

app = FastAPI(title=APP_NAME, version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

app.include_router(dashboard.router)
app.include_router(agent.router)
app.include_router(jobs.router)
app.include_router(applications.router)
app.include_router(cv.router)
app.include_router(messages.router)
app.include_router(interviews.router)
app.include_router(reminders.router)
app.include_router(audit.router)
app.include_router(memory.router)
app.include_router(voice.router)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/health")
def health_check():
    return {"status": "ok", "app": APP_NAME, "mode": "local"}

