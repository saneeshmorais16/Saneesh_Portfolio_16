from contextlib import contextmanager
from datetime import datetime, timezone

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from iris.config import DATABASE_FILE


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Base(DeclarativeBase):
    pass


DATABASE_FILE.parent.mkdir(parents=True, exist_ok=True)
database_url = f"sqlite:///{DATABASE_FILE.as_posix()}"

engine = create_engine(
    database_url,
    connect_args={"check_same_thread": False},
    future=True,
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def init_db() -> None:
    from iris import models  # noqa: F401

    Base.metadata.create_all(bind=engine)


@contextmanager
def get_session():
    init_db()
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()

