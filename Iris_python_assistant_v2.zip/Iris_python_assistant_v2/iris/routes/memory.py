import json

from fastapi import APIRouter, HTTPException

from iris.config import USER_PROFILE
from iris.database import get_session, utc_now
from iris.models import UserPreference
from iris.schemas import MemoryUpdateRequest
from iris.services.audit import write_audit

router = APIRouter(prefix="/api/memory", tags=["memory"])


@router.get("")
def get_memory():
    with get_session() as session:
        rows = session.query(UserPreference).order_by(UserPreference.key.asc()).all()
        preferences = {}
        for row in rows:
            try:
                preferences[row.key] = json.loads(row.value)
            except json.JSONDecodeError:
                preferences[row.key] = row.value
        return {"profile": USER_PROFILE, "preferences": preferences}


@router.patch("/preferences")
def update_preferences(payload: MemoryUpdateRequest):
    if not payload.approved:
        raise HTTPException(status_code=409, detail="Approval required before changing saved preferences.")
    with get_session() as session:
        for key, value in payload.preferences.items():
            existing = session.query(UserPreference).filter(UserPreference.key == key).one_or_none()
            encoded = json.dumps(value)
            if existing:
                existing.value = encoded
                existing.updated_at = utc_now()
            else:
                session.add(UserPreference(key=key, value=encoded))
        write_audit(
            session,
            event_type="memory_preferences_updated",
            user_input=", ".join(payload.preferences.keys()),
            action_plan=["Update approved saved user preferences."],
            result={"updated_keys": list(payload.preferences.keys())},
            risk_level="approval_required",
            requires_approval=True,
        )
        return {"updated": True, "preferences": payload.preferences}

