from fastapi import APIRouter, HTTPException

from iris.agent.cv_selector import select_projects
from iris.agent.keyword_extractor import classify_cv_keywords
from iris.agent.matcher import analyse_and_score_job
from iris.config import USER_PROFILE
from iris.database import get_session
from iris.models import CVVersion, Job
from iris.schemas import CVAnalyseRequest, CVGenerateRequest
from iris.services.audit import write_audit
from iris.services.records import as_dict

router = APIRouter(prefix="/api/cv", tags=["cv"])


def _description_from_request(session, job_id: int | None, job_description: str | None) -> tuple[str, Job | None]:
    if job_id:
        job = session.get(Job, job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found.")
        return job.description or "", job
    if job_description:
        return job_description, None
    raise HTTPException(status_code=400, detail="Provide a job_id or job_description.")


def _rewrite_plan(job_description: str) -> dict:
    keywords = classify_cv_keywords(job_description)
    projects = select_projects(job_description)
    analysis = analyse_and_score_job(job_description)
    plan = [
        "Read the job description carefully.",
        "Extract keywords line by line.",
        "Classify keywords into must include, can include carefully, and do not include without evidence.",
        "Select the three most relevant projects from the project bank.",
        "Use only real experience: Savant Technologies, 3NS.ai, and The Hippodrome Casino.",
        "Keep one clean page, include GitHub in the header, and preserve fixed metrics: 72% to 85%, 30%, 15%, 10%.",
        "Wait for user approval before generating final LaTeX.",
    ]
    return {"keywords": keywords, "selected_projects": projects, "job_analysis": analysis, "rewrite_plan": plan}


@router.post("/analyse-job")
def analyse_job_for_cv(payload: CVAnalyseRequest):
    with get_session() as session:
        description, job = _description_from_request(session, payload.job_id, payload.job_description)
        result = _rewrite_plan(description)
        write_audit(
            session,
            event_type="cv_job_analysed",
            user_input=f"job:{job.id}" if job else "pasted job description",
            action_plan=result["rewrite_plan"],
            result={"keywords": result["keywords"], "projects": result["selected_projects"]},
        )
        return result


@router.post("/rewrite-plan")
def create_rewrite_plan(payload: CVAnalyseRequest):
    with get_session() as session:
        description, job = _description_from_request(session, payload.job_id, payload.job_description)
        result = _rewrite_plan(description)
        cv = CVVersion(
            job_id=job.id if job else None,
            name=f"CV rewrite plan - {job.role_title}" if job else "CV rewrite plan - pasted job",
            rewrite_plan="\n".join(result["rewrite_plan"]),
            status="Plan Ready",
        )
        session.add(cv)
        session.flush()
        write_audit(
            session,
            event_type="cv_rewrite_plan_created",
            user_input=f"job:{job.id}" if job else "pasted job description",
            action_plan=result["rewrite_plan"],
            result={"cv_version_id": cv.id},
        )
        return {"cv_version": as_dict(cv), **result, "approval_required_for_latex": True}


def _latex_cv(projects: list[dict[str, str]]) -> str:
    project_lines = "\n".join(
        f"\\item \\textbf{{{item['project']}}}: {item['justification']}"
        for item in projects
    )
    return rf"""\documentclass[10pt,a4paper]{{article}}
\usepackage[margin=0.55in]{{geometry}}
\usepackage{{hyperref}}
\pagenumbering{{gobble}}
\begin{{document}}
\begin{{center}}
{{\Large \textbf{{{USER_PROFILE['name']}}}}}\\
London, UK \ | \ {USER_PROFILE['email']} \ | \ \href{{https://github.com/saneeshmorais}}{{GitHub}}
\end{{center}}
\section*{{Profile}}
Early-career AI, software, and data candidate with a BSc in Computing with Artificial Intelligence Technology. Practical experience across Python, SQL, FastAPI, NLP, dashboards, data validation, reporting, and LLM workflow prototypes.
\section*{{Experience}}
\textbf{{Data Analyst Intern, Savant Technologies}} \hfill Jan 2025--Mar 2025\\
\begin{{itemize}}
\item Improved reporting validation coverage from 72\% to 85\% through structured checks and clearer documentation.
\item Reduced recurring manual review effort by 30\% using repeatable data cleaning and validation steps.
\end{{itemize}}
\textbf{{AI Intern, 3NS.ai}} \hfill May 2024--Aug 2024\\
\begin{{itemize}}
\item Supported AI workflow prototypes using prompt testing, documentation, and model output review.
\item Helped improve workflow clarity by 15\% and reduced repeated handover questions by 10\%.
\end{{itemize}}
\textbf{{Cocktail Bartender, The Hippodrome Casino}} \hfill May 2024--Present\\
\begin{{itemize}}
\item Communicate clearly with customers and teams in a fast-paced London venue while managing priorities under pressure.
\end{{itemize}}
\section*{{Selected Projects}}
\begin{{itemize}}
{project_lines}
\end{{itemize}}
\section*{{Skills}}
Python, SQL, JavaScript, FastAPI, Flask, REST APIs, pandas, NumPy, NLP, scikit-learn, Tableau, Power BI, Git, GitHub, dashboards, reporting, data validation, LLM workflows
\end{{document}}
"""


@router.post("/generate-latex")
def generate_latex(payload: CVGenerateRequest):
    if not payload.approved:
        return {
            "approval_required": True,
            "message": "Iris will not generate final LaTeX until you approve the rewrite plan.",
        }
    with get_session() as session:
        description, job = _description_from_request(session, payload.job_id, payload.job_description)
        projects = select_projects(description)
        latex = _latex_cv(projects)
        cv = CVVersion(
            job_id=job.id if job else None,
            name=f"Approved tailored CV - {job.role_title}" if job else "Approved tailored CV",
            rewrite_plan=payload.rewrite_plan or "Approved rewrite plan",
            content_latex=latex,
            status="Generated",
        )
        session.add(cv)
        session.flush()
        write_audit(
            session,
            event_type="cv_latex_generated",
            user_input=f"job:{job.id}" if job else "pasted job description",
            action_plan=["Generate final LaTeX after explicit approval."],
            result={"cv_version_id": cv.id},
            risk_level="approval_required",
            requires_approval=True,
        )
        return {"cv_version": as_dict(cv), "latex": latex}

