from fastapi import APIRouter

router = APIRouter(prefix="/api/voice", tags=["voice"])


@router.get("/capabilities")
def voice_capabilities():
    return {
        "speech_to_text": "browser Web Speech API when available",
        "text_to_speech": "browser SpeechSynthesis when available",
        "wake_word": "push-to-talk only; leading 'Iris,' is removed before processing",
        "always_listening": False,
    }

