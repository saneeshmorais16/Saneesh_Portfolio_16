from fastapi import APIRouter, HTTPException

from iris.database import get_session, utc_now
from iris.models import Application, Job
from iris.routes.jobs import APPLICATION_STATUSES
from iris.schemas import ApplicationCreateRequest, ApplicationUpdateRequest
from iris.services.audit import write_audit
from iris.services.records import as_dict, rows_as_dict

router = APIRouter(prefix="/api/applications", tags=["applications"])


@router.get("")
def list_applications():
    with get_session() as session:
        rows = session.query(Application).order_by(Application.updated_at.desc()).all()
        return rows_as_dict(rows)


@router.post("")
def create_application(payload: ApplicationCreateRequest):
    if payload.status == "Applied" and not payload.approved:
        raise HTTPException(status_code=409, detail="Approval required before marking a role as applied.")

    with get_session() as session:
        job = session.get(Job, payload.job_id) if payload.job_id else None
        company_name = payload.company_name or (job.company_name if job else None)
        role_title = payload.role_title or (job.role_title if job else None)
        if not company_name or not role_title:
            raise HTTPException(status_code=400, detail="Provide job_id or both company_name and role_title.")
        if payload.status not in APPLICATION_STATUSES:
            raise HTTPException(status_code=400, detail="Invalid application status.")

        application = Application(
            job_id=payload.job_id,
            company_name=company_name,
            role_title=role_title,
            status=payload.status,
            stage_notes=payload.stage_notes,
            applied_at=payload.applied_at,
            follow_up_at=payload.follow_up_at,
        )
        session.add(application)
        if job:
            job.status = payload.status
            job.updated_at = utc_now()
        session.flush()
        write_audit(
            session,
            event_type="application_created",
            user_input=f"{company_name} - {role_title}",
            action_plan=["Create local application tracker record."],
            result={"application_id": application.id, "status": application.status},
            requires_approval=payload.status == "Applied",
        )
        return as_dict(application)


@router.patch("/{application_id}")
def update_application(application_id: int, payload: ApplicationUpdateRequest):
    with get_session() as session:
        application = session.get(Application, application_id)
        if not application:
            raise HTTPException(status_code=404, detail="Application not found.")
        if payload.status == "Applied" and not payload.approved:
            raise HTTPException(status_code=409, detail="Approval required before marking a role as applied.")
        if payload.status and payload.status not in APPLICATION_STATUSES:
            raise HTTPException(status_code=400, detail="Invalid application status.")

        for field, value in payload.model_dump(exclude_unset=True).items():
            if field == "approved" or value is None:
                continue
            setattr(application, field, value)
        application.updated_at = utc_now()

        if application.job_id and payload.status:
            job = session.get(Job, application.job_id)
            if job:
                job.status = payload.status
                job.updated_at = utc_now()

        write_audit(
            session,
            event_type="application_updated",
            user_input=f"application:{application_id}",
            action_plan=["Update application tracker record."],
            result={"application_id": application.id, "status": application.status},
            requires_approval=payload.status == "Applied",
        )
        return as_dict(application)

