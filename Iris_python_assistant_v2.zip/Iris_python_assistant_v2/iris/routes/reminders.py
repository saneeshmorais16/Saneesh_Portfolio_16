from fastapi import APIRouter, HTTPException

from iris.database import get_session, utc_now
from iris.models import Reminder
from iris.schemas import ReminderCreateRequest, ReminderUpdateRequest
from iris.services.audit import write_audit
from iris.services.records import as_dict, rows_as_dict

router = APIRouter(prefix="/api/reminders", tags=["reminders"])


@router.get("")
def list_reminders(status: str | None = None):
    with get_session() as session:
        query = session.query(Reminder)
        if status:
            query = query.filter(Reminder.status == status)
        rows = query.order_by(Reminder.due_at.asc().nulls_last(), Reminder.created_at.desc()).all()
        return rows_as_dict(rows)


@router.post("")
def create_reminder(payload: ReminderCreateRequest):
    with get_session() as session:
        reminder = Reminder(
            job_id=payload.job_id,
            application_id=payload.application_id,
            title=payload.title,
            due_at=payload.due_at,
        )
        session.add(reminder)
        session.flush()
        write_audit(
            session,
            event_type="reminder_created",
            user_input=payload.title,
            action_plan=["Create one local reminder."],
            result={"reminder_id": reminder.id, "due_at": reminder.due_at},
        )
        return as_dict(reminder)


@router.patch("/{reminder_id}")
def update_reminder(reminder_id: int, payload: ReminderUpdateRequest):
    with get_session() as session:
        reminder = session.get(Reminder, reminder_id)
        if not reminder:
            raise HTTPException(status_code=404, detail="Reminder not found.")
        for field, value in payload.model_dump(exclude_unset=True).items():
            if field == "approved" or value is None:
                continue
            setattr(reminder, field, value)
        reminder.updated_at = utc_now()
        write_audit(
            session,
            event_type="reminder_updated",
            user_input=f"reminder:{reminder_id}",
            action_plan=["Update local reminder."],
            result={"reminder_id": reminder.id, "status": reminder.status},
        )
        return as_dict(reminder)

