from fastapi import APIRouter
from fastapi.responses import FileResponse

from iris.config import DASHBOARD_FILE, FRONTEND_DIR

router = APIRouter(tags=["dashboard"])


@router.get("/")
def root_dashboard():
    return FileResponse(DASHBOARD_FILE if DASHBOARD_FILE.exists() else FRONTEND_DIR / "index.html")


@router.get("/dashboard")
def dashboard():
    return FileResponse(DASHBOARD_FILE if DASHBOARD_FILE.exists() else FRONTEND_DIR / "index.html")

