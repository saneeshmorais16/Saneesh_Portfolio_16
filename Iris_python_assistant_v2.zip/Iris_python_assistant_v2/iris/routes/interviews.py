from fastapi import APIRouter, HTTPException

from iris.agent.interview_prep import build_interview_prep
from iris.database import get_session
from iris.models import InterviewNote, Job
from iris.schemas import InterviewPrepRequest
from iris.services.audit import write_audit
from iris.services.records import as_dict

router = APIRouter(prefix="/api/interviews", tags=["interviews"])


@router.post("/prepare")
def prepare_interview(payload: InterviewPrepRequest):
    with get_session() as session:
        job = session.get(Job, payload.job_id) if payload.job_id else None
        if payload.job_id and not job:
            raise HTTPException(status_code=404, detail="Job not found.")

        description = payload.job_description or (job.description if job else "")
        company_name = payload.company_name or (job.company_name if job else "the company")
        role_title = payload.role_title or (job.role_title if job else "the role")
        prep = build_interview_prep(company_name, role_title, description or "")
        note = InterviewNote(job_id=job.id if job else None, content=str(prep))
        session.add(note)
        session.flush()
        write_audit(
            session,
            event_type="interview_prep_created",
            user_input=f"{company_name} - {role_title}",
            action_plan=["Generate interview preparation from real profile evidence."],
            result={"interview_note_id": note.id},
        )
        return {"interview_note": as_dict(note), "prep": prep}

