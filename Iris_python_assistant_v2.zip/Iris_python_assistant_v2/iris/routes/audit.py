import json

from fastapi import APIRouter

from iris.database import get_session
from iris.models import AuditLog
from iris.services.records import as_dict

router = APIRouter(prefix="/api/audit", tags=["audit"])


@router.get("")
def get_audit(limit: int = 50):
    limit = min(max(limit, 1), 200)
    with get_session() as session:
        rows = session.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
        result = []
        for row in rows:
            item = as_dict(row)
            try:
                item["action_plan"] = json.loads(item["action_plan"] or "[]")
            except json.JSONDecodeError:
                item["action_plan"] = []
            result.append(item)
        return result

