from datetime import datetime, timedelta
import re

from fastapi import APIRouter

from iris.agent.matcher import analyse_and_score_job
from iris.agent.planner import clean_wake_word, create_action_plan, detect_intent
from iris.agent.safety import classify_risk
from iris.database import get_session
from iris.models import Job, Reminder
from iris.schemas import AgentCommandRequest, AgentResponse, VoiceCommandRequest
from iris.services.audit import write_audit
from iris.services.job_sources import build_source_links
from iris.services.records import rows_as_dict

router = APIRouter(prefix="/api/agent", tags=["agent"])


def _extract_job_id(text: str) -> int | None:
    match = re.search(r"\bjob\s*#?\s*(\d+)\b", text, flags=re.IGNORECASE)
    return int(match.group(1)) if match else None


def _format_jobs(jobs: list[dict]) -> str:
    if not jobs:
        return "No matching saved jobs yet."
    lines = []
    for job in jobs[:8]:
        lines.append(
            f"{job['id']}. {job['role_title']} at {job['company_name']} - {job['match_score']}/10 ({job['status']})"
        )
    return "\n".join(lines)


def _handle_message(message: str, voice: bool = False) -> AgentResponse:
    cleaned = clean_wake_word(message)
    intent = detect_intent(cleaned)
    action_plan = create_action_plan(intent)
    risk_level, approval_required = classify_risk(cleaned, intent)
    data = {}

    with get_session() as session:
        if intent == "search_jobs":
            query = cleaned
            links = build_source_links(query, location="London")
            data = {"links": links}
            reply = (
                "I built safe search links for the major UK job sources. "
                "Open the best matches, then paste the job descriptions into Iris so I can extract, score, and save them."
            )

        elif intent == "score_job":
            if len(cleaned) < 180:
                reply = "Paste the full job description or save a job first, then I can score it properly."
            else:
                analysis = analyse_and_score_job(cleaned)
                data = analysis
                reply = (
                    f"Match score: {analysis['match_score']}/10 - {analysis['recommendation']}.\n"
                    f"{analysis['match_reason']}\n"
                    f"Risk flags: {', '.join(analysis['risk_flags']) if analysis['risk_flags'] else 'None found.'}"
                )

        elif intent == "daily_priority":
            jobs = (
                session.query(Job)
                .filter(Job.match_score >= 7, Job.status.in_(["Found", "Shortlisted", "CV Needed"]))
                .order_by(Job.match_score.desc(), Job.updated_at.desc())
                .limit(8)
                .all()
            )
            job_rows = rows_as_dict(jobs)
            data = {"apply_today": job_rows}
            reply = "Here are the saved roles to prioritise today:\n" + _format_jobs(job_rows)

        elif intent == "reminder":
            due_at = None
            lowered = cleaned.lower()
            if "tomorrow" in lowered:
                due_at = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
            title = cleaned
            reminder = Reminder(title=title, due_at=due_at)
            session.add(reminder)
            session.flush()
            data = {"reminder_id": reminder.id, "due_at": reminder.due_at}
            reply = f"Reminder saved: {title}" + (f" for {due_at}." if due_at else ".")

        elif intent == "cv_tailoring":
            reply = (
                "I can tailor the CV through the CV workspace. Paste the job description or select a saved job, "
                "then I will extract keywords, choose projects, and create a rewrite plan before any final LaTeX."
            )

        elif intent == "message_writer":
            reply = (
                "Use the recruiter message workspace with a saved job or pasted context. "
                "Iris drafts only; it will not send messages automatically."
            )

        elif intent == "interview_prep":
            reply = (
                "Use the interview preparation panel with a saved job. "
                "I will generate company, role, STAR, technical, and checklist notes from Saneesh's real evidence."
            )

        elif intent == "track_application":
            job_id = _extract_job_id(cleaned)
            if job_id:
                job = session.get(Job, job_id)
                if job:
                    data = {"job_id": job.id}
                    reply = f"I found job {job.id}: {job.role_title} at {job.company_name}. Use the application tracker to set the exact status."
                else:
                    reply = f"I could not find job {job_id}."
            else:
                reply = "Save the job first or include a job id, then I can track the application status cleanly."

        else:
            reply = (
                "Iris is ready for job search work. Try: find junior AI internships in London, "
                "paste a job description to score it, or ask for today's application priorities."
            )

        write_audit(
            session,
            event_type=f"agent_{intent}",
            user_input=cleaned,
            action_plan=action_plan,
            result={"reply": reply, "data": data},
            risk_level=risk_level,
            requires_approval=approval_required,
        )

    return AgentResponse(
        reply=reply,
        intent=intent,
        action_plan=action_plan,
        risk_level=risk_level,
        approval_required=approval_required,
        data=data,
        spoken_response=reply if voice else None,
    )


@router.post("/chat", response_model=AgentResponse)
def chat(payload: AgentCommandRequest):
    return _handle_message(payload.message, voice=payload.speak)


@router.post("/voice-command", response_model=AgentResponse)
def voice_command(payload: VoiceCommandRequest):
    return _handle_message(payload.transcript, voice=True)

