from fastapi import APIRouter, HTTPException

from iris.agent.message_writer import draft_message
from iris.database import get_session
from iris.models import Job, RecruiterMessage
from iris.schemas import MessageRequest
from iris.services.audit import write_audit
from iris.services.records import as_dict

router = APIRouter(prefix="/api/messages", tags=["messages"])


def _message_context(session, payload: MessageRequest) -> tuple[str, str, int | None]:
    if payload.job_id:
        job = session.get(Job, payload.job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found.")
        return job.company_name, job.role_title, job.id
    return payload.company_name or "the company", payload.role_title or "the role", None


def _create_message(payload: MessageRequest, forced_type: str):
    with get_session() as session:
        company_name, role_title, job_id = _message_context(session, payload)
        draft = draft_message(forced_type, company_name, role_title, payload.recipient_name)
        record = RecruiterMessage(
            job_id=job_id,
            message_type=forced_type,
            subject=draft["subject"],
            body=draft["body"],
            status="Draft",
        )
        session.add(record)
        session.flush()
        write_audit(
            session,
            event_type="message_drafted",
            user_input=f"{forced_type}: {company_name} - {role_title}",
            action_plan=["Draft message only.", "Do not send automatically."],
            result={"message_id": record.id, "status": record.status},
        )
        return {
            "message": as_dict(record),
            "notice": "Draft only. Iris does not send emails or messages automatically.",
        }


@router.post("/recruiter")
def recruiter_message(payload: MessageRequest):
    return _create_message(payload, "recruiter")


@router.post("/follow-up")
def follow_up_message(payload: MessageRequest):
    return _create_message(payload, "follow-up")


@router.post("/thank-you")
def thank_you_message(payload: MessageRequest):
    return _create_message(payload, "thank-you")

