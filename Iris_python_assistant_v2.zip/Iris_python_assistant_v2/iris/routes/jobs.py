from fastapi import APIRouter, HTTPException, Query

from iris.agent.matcher import analyse_and_score_job
from iris.database import get_session, utc_now
from iris.models import Job
from iris.schemas import JobCreateRequest, JobSearchRequest, JobUpdateRequest
from iris.services.audit import write_audit
from iris.services.job_sources import build_search_query, build_source_links
from iris.services.records import apply_job_analysis, as_dict, get_or_create_company, rows_as_dict

router = APIRouter(prefix="/api/jobs", tags=["jobs"])

APPLICATION_STATUSES = {
    "Found",
    "Shortlisted",
    "CV Needed",
    "CV Tailored",
    "Applied",
    "Assessment",
    "Interview",
    "Follow-Up",
    "Rejected",
    "Offer",
    "Archived",
}


def _job_or_404(session, job_id: int) -> Job:
    job = session.get(Job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return job


@router.post("/search")
def search_jobs(payload: JobSearchRequest):
    query_payload = payload.model_dump()
    query = build_search_query(query_payload)
    location = payload.location or "London"
    links = build_source_links(query, location=location, source=payload.source)
    with get_session() as session:
        write_audit(
            session,
            event_type="job_search",
            user_input=query,
            action_plan=[
                "Build source-adapter search links.",
                "Open selected job boards manually.",
                "Paste promising descriptions back into Iris for extraction and scoring.",
            ],
            result={"query": query, "location": location, "links": links},
        )
    return {
        "query": query,
        "location": location,
        "minimum_match_score": payload.minimum_match_score,
        "links": links,
        "message": "Iris does not rely on fragile scraping. Open these searches, then paste promising job descriptions back for scoring and saving.",
    }


@router.post("/add")
def add_job(payload: JobCreateRequest):
    overrides = payload.model_dump(exclude={"description", "notes", "status"})
    analysis = analyse_and_score_job(payload.description, overrides)

    with get_session() as session:
        company = get_or_create_company(session, str(analysis["company_name"]))
        job = Job(
            company_id=company.id,
            company_name=company.name,
            role_title=str(analysis["role_title"]),
            description=payload.description,
            notes=payload.notes,
            status=payload.status if payload.status in APPLICATION_STATUSES else "Found",
        )
        apply_job_analysis(job, analysis)
        session.add(job)
        session.flush()
        write_audit(
            session,
            event_type="job_added",
            user_input=payload.role_title or payload.application_url or analysis["role_title"],
            action_plan=["Extract job data.", "Score match.", "Save job locally."],
            result={"job_id": job.id, "match_score": job.match_score, "status": job.status},
        )
        return {"job": as_dict(job), "recommendation": analysis["recommendation"]}


@router.get("")
def list_jobs(
    show_all: bool = False,
    minimum_match_score: float = Query(7, ge=0, le=10),
    status: str | None = None,
):
    with get_session() as session:
        query = session.query(Job)
        if status:
            query = query.filter(Job.status == status)
        elif not show_all:
            query = query.filter(Job.match_score >= minimum_match_score, Job.status != "Archived")
        rows = query.order_by(Job.match_score.desc(), Job.updated_at.desc()).all()
        return rows_as_dict(rows)


@router.get("/{job_id}")
def get_job(job_id: int):
    with get_session() as session:
        return as_dict(_job_or_404(session, job_id))


@router.patch("/{job_id}")
def update_job(job_id: int, payload: JobUpdateRequest):
    with get_session() as session:
        job = _job_or_404(session, job_id)
        updates = payload.model_dump(exclude_unset=True)
        requested_status = updates.get("status")
        if requested_status in {"Applied", "Archived"} and not payload.approved:
            raise HTTPException(status_code=409, detail="Approval required for this status change.")

        for field, value in updates.items():
            if field == "approved" or value is None:
                continue
            if field == "status" and value not in APPLICATION_STATUSES:
                raise HTTPException(status_code=400, detail="Invalid job status.")
            setattr(job, field, value)

        if payload.description:
            analysis = analyse_and_score_job(payload.description, payload.model_dump())
            apply_job_analysis(job, analysis)

        job.updated_at = utc_now()
        write_audit(
            session,
            event_type="job_updated",
            user_input=f"job:{job_id}",
            action_plan=["Apply approved job field updates.", "Refresh score if description changed."],
            result={"job_id": job.id, "status": job.status},
            requires_approval=bool(requested_status in {"Applied", "Archived"}),
        )
        return as_dict(job)


@router.delete("/{job_id}")
def delete_job(job_id: int, approved: bool = False):
    if not approved:
        raise HTTPException(status_code=409, detail="Approval required before deleting a job record.")
    with get_session() as session:
        job = _job_or_404(session, job_id)
        result = {"job_id": job.id, "role_title": job.role_title, "company_name": job.company_name}
        session.delete(job)
        write_audit(
            session,
            event_type="job_deleted",
            user_input=f"job:{job_id}",
            action_plan=["Delete the approved job record."],
            result=result,
            risk_level="approval_required",
            requires_approval=True,
        )
        return {"deleted": True, **result}


@router.post("/{job_id}/score")
def score_job(job_id: int):
    with get_session() as session:
        job = _job_or_404(session, job_id)
        analysis = analyse_and_score_job(
            job.description or "",
            {
                "company_name": job.company_name,
                "role_title": job.role_title,
                "location": job.location,
                "work_type": job.work_type,
                "salary": job.salary,
                "source": job.source,
                "application_url": job.application_url,
            },
        )
        apply_job_analysis(job, analysis)
        write_audit(
            session,
            event_type="job_scored",
            user_input=f"job:{job_id}",
            action_plan=["Recalculate deterministic match score."],
            result={"job_id": job.id, "match_score": job.match_score, "risk_flags": analysis["risk_flags"]},
        )
        return {"job": as_dict(job), "recommendation": analysis["recommendation"]}


@router.post("/{job_id}/shortlist")
def shortlist_job(job_id: int):
    with get_session() as session:
        job = _job_or_404(session, job_id)
        job.status = "Shortlisted"
        job.updated_at = utc_now()
        write_audit(
            session,
            event_type="job_shortlisted",
            user_input=f"job:{job_id}",
            action_plan=["Move job into shortlisted queue."],
            result={"job_id": job.id, "status": job.status},
        )
        return as_dict(job)


@router.post("/{job_id}/archive")
def archive_job(job_id: int, approved: bool = False):
    if not approved:
        raise HTTPException(status_code=409, detail="Approval required before archiving a job record.")
    with get_session() as session:
        job = _job_or_404(session, job_id)
        job.status = "Archived"
        job.updated_at = utc_now()
        write_audit(
            session,
            event_type="job_archived",
            user_input=f"job:{job_id}",
            action_plan=["Archive the approved job record."],
            result={"job_id": job.id, "status": job.status},
            risk_level="approval_required",
            requires_approval=True,
        )
        return as_dict(job)

