import os
from pathlib import Path

from dotenv import load_dotenv


ROOT_DIR = Path(__file__).resolve().parent.parent
ENV_FILE = ROOT_DIR / ".env"
if os.getenv("IRIS_DISABLE_DOTENV") != "1":
    load_dotenv(dotenv_path=ENV_FILE, override=False)

APP_NAME = os.getenv("APP_NAME", "Iris - AI Job Search Assistant")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")

DEFAULT_LOCATION = os.getenv("IRIS_DEFAULT_LOCATION", "London")
DEFAULT_EMAIL = os.getenv("IRIS_DEFAULT_EMAIL", "saneeshmorais@gmail.com")

_db_path = os.getenv("IRIS_DB_PATH") or os.getenv("DATABASE_PATH") or "./data/iris.db"
DATABASE_FILE = Path(_db_path)
if not DATABASE_FILE.is_absolute():
    DATABASE_FILE = ROOT_DIR / DATABASE_FILE

FRONTEND_DIR = ROOT_DIR / "frontend"
STATIC_DIR = FRONTEND_DIR / "static"
DASHBOARD_FILE = FRONTEND_DIR / "iris-dashboard.html"

USER_PROFILE = {
    "name": "Saneesh Morais",
    "location": "London, UK",
    "email": DEFAULT_EMAIL,
    "education": "Recently completed BSc Computing with Artificial Intelligence Technology at Northumbria University London",
    "expected_result": "First Class Honours",
    "target_roles": [
        "junior AI roles",
        "AI internships",
        "graduate software engineer",
        "junior software developer",
        "data analyst",
        "junior data scientist",
        "technology consultant graduate",
        "AI product analyst",
        "data engineer junior",
        "AI automation analyst",
        "placement roles",
        "internship roles",
    ],
    "preferred_location": "London on-site/hybrid/remote first, UK remote second",
    "skills": [
        "Python",
        "SQL",
        "JavaScript",
        "FastAPI",
        "Flask",
        "REST APIs",
        "pandas",
        "NumPy",
        "NLP",
        "TF-IDF",
        "scikit-learn",
        "Random Forest",
        "XGBoost",
        "Tableau",
        "Power BI",
        "Git",
        "GitHub",
        "data cleaning",
        "data validation",
        "dashboards",
        "reporting",
        "AI prototyping",
        "LLM workflows",
        "prompt engineering",
        "model evaluation",
        "stakeholder communication",
        "documentation",
    ],
    "experience": [
        "Data Analyst Intern, Savant Technologies, London Remote, Jan 2025 to Mar 2025",
        "AI Intern, 3NS.ai, London Hybrid, May 2024 to Aug 2024",
        "Cocktail Bartender, The Hippodrome Casino, London, May 2024 to Present",
    ],
    "project_bank": [
        "ML Audit Engine for Loan Approval Models",
        "AI Financial Document Analyzer API",
        "AI Automation and LLM Workflow Prototype",
        "Data Architecture and Business Process Mapping Prototype",
        "Customer Behaviour and Revenue Insights Dashboard",
        "Business Data Monitoring and Anomaly Analysis Prototype",
        "Reporting Automation and Data Quality Prototype",
        "Financial Services Dashboard and Reporting Prototype",
        "AI Impact OS",
        "Smart Mixologist AI Recommendation App",
        "AI Job Market Intelligence API",
        "Personal AI Agent with Memory",
        "RAG Pipeline from Scratch",
        "AI Code Review Tool",
        "Real Time Dashboard with Live Data",
        "End to End ML Pipeline with MLflow",
        "Browser Extension Powered by AI",
        "Automated Job Application Tracker",
    ],
}
