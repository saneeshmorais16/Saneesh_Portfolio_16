"""Iris local AI job-search assistant."""

