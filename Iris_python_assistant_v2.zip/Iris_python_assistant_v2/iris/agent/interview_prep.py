from typing import Dict, List

from iris.agent.cv_selector import select_projects
from iris.agent.keyword_extractor import extract_skills
from iris.config import USER_PROFILE


def build_interview_prep(company_name: str, role_title: str, job_description: str) -> Dict[str, object]:
    skills = extract_skills(job_description)
    projects = select_projects(job_description)
    company = company_name or "the company"
    role = role_title or "the role"

    sections: Dict[str, object] = {
        "why_this_company": (
            f"Focus on the practical work {company} appears to do, the chance to apply AI/data/software skills, "
            "and the fit with early-career learning in London or UK teams."
        ),
        "why_this_role": (
            f"{role} matches Saneesh's mix of Python, SQL, AI workflow, dashboard, API, and stakeholder communication experience."
        ),
        "tell_me_about_yourself": (
            "I recently completed a BSc in Computing with Artificial Intelligence Technology at Northumbria University London. "
            "I have internship experience in data analysis and AI workflows, plus project work across APIs, ML evaluation, dashboards, and LLM prototypes."
        ),
        "thirty_second_pitch": (
            "I am an early-career AI and software candidate based in London. I have built practical Python, SQL, FastAPI, dashboard, NLP, and LLM workflow projects, "
            "and I am strongest where technical work needs clear business communication."
        ),
        "star_answers": [
            "Savant Technologies: improving validation/reporting discipline and communicating findings clearly.",
            "3NS.ai: supporting AI workflow prototypes and translating experiments into usable notes.",
            "Hippodrome Casino: high-pressure stakeholder service, prioritisation, and communication.",
        ],
        "project_explanations": projects,
        "technical_questions": [
            f"Explain how you would validate data quality for {role}.",
            "How would you design a small FastAPI service for job or document analysis?",
            "How would you evaluate a machine learning model beyond accuracy?",
            "When would you use SQL instead of pandas, and when would you combine both?",
        ],
        "questions_to_ask": [
            "What does success look like in the first three months?",
            "How does the team support junior or graduate engineers and analysts?",
            "Which tools and datasets would this role use most often?",
            "What are the main delivery challenges for this team right now?",
        ],
        "weak_areas_to_prepare": [
            "Any stack terms in the description not already in Saneesh's evidence.",
            "Company-specific domain knowledge.",
            "Clear examples for Python, SQL, dashboards, and model evaluation.",
        ],
        "likely_screening_questions": [
            "Why are you interested in this role?",
            "What relevant project are you most proud of?",
            "Tell us about a time you handled unclear requirements.",
            "What are your salary, location, and start-date preferences?",
        ],
        "preparation_checklist": [
            "Review the job description and mark every must-have requirement.",
            f"Prepare examples for: {', '.join(skills[:8]) if skills else 'Python, SQL, AI, dashboards, and communication'}.",
            "Prepare one concise project walkthrough.",
            "Prepare one question about team workflow and one about success metrics.",
        ],
    }
    return sections

