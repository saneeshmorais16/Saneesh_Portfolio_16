from typing import Dict

from iris.agent.keyword_extractor import extract_job_fields
from iris.agent.scoring import calculate_match


def analyse_and_score_job(description: str, overrides: Dict[str, str | None] | None = None) -> Dict[str, object]:
    extracted = extract_job_fields(description, overrides)
    score = calculate_match(extracted, description)
    return {**extracted, **score}

