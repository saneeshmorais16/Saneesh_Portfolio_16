from typing import Dict

from iris.config import USER_PROFILE


def draft_message(
    message_type: str,
    company_name: str,
    role_title: str,
    recipient_name: str | None = None,
) -> Dict[str, str]:
    greeting = f"Hi {recipient_name}," if recipient_name else "Hi,"
    role = role_title or "the role"
    company = company_name or "your team"
    lower_type = message_type.lower()

    if "follow" in lower_type:
        subject = f"Follow-up on {role}"
        body = (
            f"{greeting}\n\n"
            f"I hope you are well. I wanted to follow up on my application for {role} at {company}. "
            "My background is in Computing with AI, with internship experience across data analysis, AI workflows, Python, SQL, and dashboards. "
            "I am still very interested and would be grateful for any update when available.\n\n"
            "Best regards,\n"
            f"{USER_PROFILE['name']}"
        )
    elif "thank" in lower_type:
        subject = f"Thank you for the {role} interview"
        body = (
            f"{greeting}\n\n"
            f"Thank you for taking the time to speak with me about {role}. "
            "I enjoyed learning more about the team and the work. The mix of practical delivery, problem solving, and clear communication fits my background well.\n\n"
            "Best regards,\n"
            f"{USER_PROFILE['name']}"
        )
    elif "connection" in lower_type or "linkedin" in lower_type:
        subject = "LinkedIn connection note"
        body = (
            f"{greeting} I recently completed a BSc in Computing with AI in London and noticed your work at {company}. "
            f"I am exploring early-career AI, software, and data roles, including {role}. It would be good to connect."
        )
    else:
        subject = f"Interest in {role}"
        body = (
            f"{greeting}\n\n"
            f"I am interested in {role} at {company}. I recently completed a BSc in Computing with AI and have practical experience with Python, SQL, FastAPI, dashboards, NLP, and LLM workflow prototypes. "
            "The role looks close to the kind of early-career AI, software, or data work I am targeting in London.\n\n"
            "I would be grateful if you could point me to the best application route or let me know whether the team is considering graduate or junior candidates.\n\n"
            "Best regards,\n"
            f"{USER_PROFILE['name']}"
        )

    return {"subject": subject, "body": body, "status": "Draft"}

