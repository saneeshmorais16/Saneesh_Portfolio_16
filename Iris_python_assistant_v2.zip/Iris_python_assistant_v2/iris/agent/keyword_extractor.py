import re
from typing import Dict, List

from iris.config import USER_PROFILE


KNOWN_SKILLS = [
    "Python",
    "SQL",
    "JavaScript",
    "FastAPI",
    "Flask",
    "REST APIs",
    "pandas",
    "NumPy",
    "NLP",
    "TF-IDF",
    "scikit-learn",
    "Random Forest",
    "XGBoost",
    "Tableau",
    "Power BI",
    "Git",
    "GitHub",
    "data cleaning",
    "data validation",
    "dashboards",
    "reporting",
    "AI prototyping",
    "LLM workflows",
    "prompt engineering",
    "model evaluation",
    "stakeholder communication",
    "documentation",
    "machine learning",
    "data analysis",
    "automation",
    "APIs",
]

UNSUPPORTED_STACK = [
    "Java only",
    ".NET",
    "C#",
    "SAP",
    "COBOL",
    "mainframe",
    "Salesforce",
    "Dynamics 365",
    "Oracle ERP",
    "Kubernetes",
    "Scala",
    "Rust",
    "Go",
]

PRIORITY_TERMS = [
    "junior",
    "graduate",
    "internship",
    "intern",
    "placement",
    "entry-level",
    "entry level",
    "training provided",
    "Python",
    "SQL",
    "AI",
    "ML",
    "NLP",
    "data analytics",
    "dashboard",
    "FastAPI",
    "REST API",
    "LLM",
    "automation",
    "reporting",
    "stakeholder",
]


def normalise_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def contains_any(text: str, terms: List[str]) -> bool:
    lowered = text.lower()
    return any(term.lower() in lowered for term in terms)


def extract_skills(text: str) -> List[str]:
    lowered = text.lower()
    found = []
    for skill in KNOWN_SKILLS:
        variants = {skill.lower()}
        if skill == "REST APIs":
            variants.update({"rest api", "restful api", "api development"})
        if skill == "scikit-learn":
            variants.add("sklearn")
        if skill == "Power BI":
            variants.add("powerbi")
        if skill == "LLM workflows":
            variants.update({"llm", "large language model", "genai", "generative ai"})
        if skill == "AI prototyping":
            variants.update({"ai prototype", "ai product", "ai automation"})
        if any(variant in lowered for variant in variants):
            found.append(skill)
    return sorted(set(found))


def extract_salary(text: str) -> str | None:
    patterns = [
        r"(?:GBP|£)\s?[\d,]+(?:\s?-\s?(?:GBP|£)?\s?[\d,]+)?(?:\s?(?:per year|pa|annum|yearly))?",
        r"[\d,]+\s?-\s?[\d,]+\s?(?:GBP|pounds|per year|pa|annum)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if match:
            return match.group(0).strip()
    return None


def _extract_labeled_value(text: str, labels: List[str]) -> str | None:
    for label in labels:
        pattern = rf"^\s*{re.escape(label)}\s*[:\-]\s*(.+)$"
        for line in text.splitlines():
            match = re.search(pattern, line, flags=re.IGNORECASE)
            if match:
                return match.group(1).strip()
    return None


def infer_work_type(text: str) -> str | None:
    lowered = text.lower()
    if "hybrid" in lowered:
        return "Hybrid"
    if "remote" in lowered:
        return "Remote"
    if "on-site" in lowered or "onsite" in lowered or "office based" in lowered:
        return "On-site"
    return None


def infer_location(text: str) -> str | None:
    labeled = _extract_labeled_value(text, ["location", "based in"])
    if labeled:
        return labeled
    if re.search(r"\bLondon\b", text, flags=re.IGNORECASE):
        return "London, UK"
    if re.search(r"\bUnited Kingdom\b|\bUK\b", text, flags=re.IGNORECASE):
        return "United Kingdom"
    if re.search(r"\bEurope\b", text, flags=re.IGNORECASE):
        return "Europe"
    return None


def infer_role_title(text: str) -> str:
    labeled = _extract_labeled_value(text, ["role", "title", "job title", "position"])
    if labeled:
        return labeled[:255]

    role_terms = [
        "engineer",
        "developer",
        "analyst",
        "scientist",
        "consultant",
        "intern",
        "placement",
        "graduate",
        "assistant",
    ]
    for raw_line in text.splitlines():
        line = raw_line.strip(" -*\t")
        if 5 <= len(line) <= 120 and contains_any(line, role_terms):
            return line[:255]
    return "Untitled role"


def infer_company(text: str) -> str:
    labeled = _extract_labeled_value(text, ["company", "employer", "organisation", "organization"])
    if labeled:
        return labeled[:255]

    match = re.search(r"\bat\s+([A-Z][A-Za-z0-9&.,' -]{2,60})", text)
    if match:
        candidate = match.group(1).strip(" .,-")
        if not contains_any(candidate, ["London", "Remote", "Hybrid"]):
            return candidate[:255]
    return "Unknown company"


def infer_experience_requirement(text: str) -> str | None:
    match = re.search(r"(\d+)\s*\+?\s*(?:years|yrs)\s+(?:of\s+)?experience", text, flags=re.IGNORECASE)
    if match:
        return f"{match.group(1)}+ years experience"
    if contains_any(text, ["no experience", "training provided", "entry-level", "entry level"]):
        return "Entry-level or training provided"
    return None


def infer_degree_requirement(text: str) -> str | None:
    lowered = text.lower()
    if "computer science" in lowered or "computing" in lowered:
        return "Computing or Computer Science degree preferred"
    if "bachelor" in lowered or "bsc" in lowered or "degree" in lowered:
        return "Degree mentioned"
    if "phd" in lowered or "master's" in lowered or "masters" in lowered:
        return "Postgraduate qualification mentioned"
    return None


def infer_visa_notes(text: str) -> str | None:
    lowered = text.lower()
    if "sponsorship" in lowered or "visa" in lowered or "right to work" in lowered:
        sentences = re.split(r"(?<=[.!?])\s+", text)
        for sentence in sentences:
            if contains_any(sentence, ["sponsorship", "visa", "right to work"]):
                return sentence.strip()[:500]
        return "Visa or sponsorship mentioned"
    return None


def infer_seniority(text: str) -> str:
    lowered = text.lower()
    if contains_any(lowered, ["senior", "lead", "manager", "principal", "staff engineer", "head of"]):
        return "Senior"
    if contains_any(lowered, ["graduate", "junior", "intern", "internship", "placement", "entry-level", "entry level"]):
        return "Early career"
    return "Unclear"


def infer_role_category(text: str) -> str:
    lowered = text.lower()
    if contains_any(lowered, ["ai", "machine learning", "ml", "nlp", "llm", "genai"]):
        return "AI / Machine Learning"
    if contains_any(lowered, ["data analyst", "analytics", "dashboard", "reporting", "power bi", "tableau"]):
        return "Data Analytics"
    if contains_any(lowered, ["software", "developer", "engineer", "api", "backend", "fastapi", "python"]):
        return "Software Engineering"
    if contains_any(lowered, ["product analyst", "product"]):
        return "AI Product"
    return "Technology"


def extract_job_fields(text: str, overrides: Dict[str, str | None] | None = None) -> Dict[str, object]:
    overrides = overrides or {}
    description = normalise_text(text)
    required_skills = extract_skills(description)
    preferred_skills = [
        term for term in PRIORITY_TERMS if term.lower() in description.lower() and term not in required_skills
    ]

    return {
        "company_name": overrides.get("company_name") or infer_company(text),
        "role_title": overrides.get("role_title") or infer_role_title(text),
        "location": overrides.get("location") or infer_location(text),
        "work_type": overrides.get("work_type") or infer_work_type(text),
        "salary": overrides.get("salary") or extract_salary(text),
        "date_posted": overrides.get("date_posted") or _extract_labeled_value(text, ["date posted", "posted"]),
        "deadline": overrides.get("deadline") or _extract_labeled_value(text, ["deadline", "closing date"]),
        "intake_start": overrides.get("intake_start") or _extract_labeled_value(text, ["start date", "intake"]),
        "source": overrides.get("source"),
        "application_url": overrides.get("application_url"),
        "required_skills": required_skills,
        "preferred_skills": sorted(set(preferred_skills)),
        "experience_requirement": infer_experience_requirement(text),
        "degree_requirement": infer_degree_requirement(text),
        "visa_sponsorship": infer_visa_notes(text),
        "seniority_level": infer_seniority(text),
        "role_category": infer_role_category(text),
    }


def classify_cv_keywords(text: str) -> Dict[str, List[str]]:
    known = set(skill.lower() for skill in USER_PROFILE["skills"])
    must_include = []
    can_include = []
    do_not_include = []

    for raw_line in text.splitlines():
        line = raw_line.strip(" -*\t")
        if not line:
            continue
        lowered = line.lower()
        if any(skill in lowered for skill in known):
            must_include.append(line)
        elif contains_any(lowered, [term.lower() for term in PRIORITY_TERMS]):
            can_include.append(line)
        elif contains_any(lowered, [term.lower() for term in UNSUPPORTED_STACK]):
            do_not_include.append(line)

    if not must_include:
        must_include = extract_skills(text)
    return {
        "must_include_with_evidence": must_include[:20],
        "can_include_carefully": can_include[:20],
        "do_not_include_without_evidence": do_not_include[:20],
    }

