from typing import Tuple


MAJOR_ACTION_TERMS = [
    "generate final cv",
    "final latex",
    "mark as applied",
    "archive",
    "delete",
    "change my profile",
    "update my profile",
    "send email",
    "send message",
    "bulk",
]


def classify_risk(message: str, intent: str) -> Tuple[str, bool]:
    text = message.lower()
    if any(term in text for term in MAJOR_ACTION_TERMS):
        return "approval_required", True
    if intent in {"cv_tailoring", "track_application"} and any(term in text for term in ["final", "applied"]):
        return "approval_required", True
    return "low", False

