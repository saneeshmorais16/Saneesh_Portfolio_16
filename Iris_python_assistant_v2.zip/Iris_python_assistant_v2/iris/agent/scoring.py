import re
from typing import Dict, List

from iris.agent.keyword_extractor import UNSUPPORTED_STACK, contains_any
from iris.config import USER_PROFILE


def _experience_years(text: str) -> int | None:
    match = re.search(r"(\d+)\s*\+?\s*(?:years|yrs)", text or "", flags=re.IGNORECASE)
    return int(match.group(1)) if match else None


def score_meaning(score: float) -> str:
    if score >= 9:
        return "Apply immediately"
    if score >= 7:
        return "Strong match, worth tailoring CV"
    if score >= 5:
        return "Partial match"
    return "Do not prioritise"


def calculate_match(extracted: Dict[str, object], description: str) -> Dict[str, object]:
    text = f"{description} {extracted.get('role_title') or ''} {extracted.get('role_category') or ''}".lower()
    score = 2.0
    reasons: List[str] = []
    risk_flags: List[str] = []

    extracted_skills = set(extracted.get("required_skills") or [])
    profile_skills = set(USER_PROFILE["skills"])
    matched_skills = sorted(extracted_skills.intersection(profile_skills))
    skill_points = min(2.4, len(matched_skills) * 0.4)
    score += skill_points
    if matched_skills:
        reasons.append(f"Skill overlap: {', '.join(matched_skills[:8])}.")
    else:
        reasons.append("No strong direct skill overlap found yet.")

    if contains_any(text, ["junior", "graduate", "internship", "intern", "placement", "entry-level", "entry level", "training provided"]):
        score += 1.6
        reasons.append("Seniority fits early-career targets.")
    elif contains_any(text, ["senior", "lead", "manager", "principal", "staff engineer"]):
        score -= 2.4
        risk_flags.append("Seniority appears above target level.")
    else:
        score += 0.5
        reasons.append("Seniority is unclear; review before prioritising.")

    if contains_any(text, ["london", "uk", "united kingdom", "remote", "hybrid"]):
        score += 1.2
        reasons.append("Location appears compatible with London or UK preferences.")
    elif contains_any(text, ["united states", "usa", "canada", "australia", "germany", "france", "india"]):
        score -= 1.8
        risk_flags.append("Location may not be open to UK applicants.")

    if contains_any(text, ["python", "fastapi", "sql", "data", "ai", "machine learning", "nlp", "llm", "dashboard", "analytics", "automation"]):
        score += 1.2
        reasons.append("Role category aligns with AI, software, automation, or analytics targets.")

    years = _experience_years(description)
    if years is None or years <= 2:
        score += 0.9
        if years is not None:
            reasons.append(f"Experience requirement is within reach at {years}+ years.")
    else:
        score -= 2.8
        risk_flags.append(f"Requires {years}+ years experience.")

    degree_requirement = (extracted.get("degree_requirement") or "").lower()
    if "computing" in degree_requirement or "computer science" in degree_requirement:
        score += 0.9
        reasons.append("Computing or CS degree requirement fits Saneesh's background.")
    elif "phd" in degree_requirement or "postgraduate" in degree_requirement:
        score -= 1.5
        risk_flags.append("Postgraduate qualification may be required.")
    else:
        score += 0.3

    if contains_any(text, ["financial", "document", "dashboard", "rag", "llm", "api", "automation", "job market", "mlflow"]):
        score += 0.8
        reasons.append("Project bank has relevant evidence for this role.")

    if contains_any(text, [term.lower() for term in UNSUPPORTED_STACK]):
        score -= 1.8
        risk_flags.append("Unsupported or low-priority tech stack mentioned.")

    if contains_any(text, ["sponsorship not available", "no visa sponsorship", "must already have right to work"]):
        risk_flags.append("Right-to-work or sponsorship constraint needs review.")

    seniority = extracted.get("seniority_level")
    if seniority == "Senior":
        score = min(score, 4.8)
    if years and years >= 3:
        score = min(score, 4.9)
    if any("Location" in flag for flag in risk_flags):
        score = min(score, 5.5)

    final_score = round(max(0.0, min(10.0, score)), 1)
    return {
        "match_score": final_score,
        "match_reason": " ".join(reasons),
        "risk_flags": risk_flags,
        "recommendation": score_meaning(final_score),
        "matched_skills": matched_skills,
    }

