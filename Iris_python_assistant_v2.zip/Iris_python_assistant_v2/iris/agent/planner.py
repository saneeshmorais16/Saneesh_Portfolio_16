from typing import Dict, List


def clean_wake_word(message: str) -> str:
    text = message.strip()
    lowered = text.lower()
    if lowered.startswith("iris,"):
        return text[5:].strip()
    if lowered.startswith("iris "):
        return text[5:].strip()
    return text


def detect_intent(message: str) -> str:
    text = message.lower()
    role_terms = [
        "internship",
        "intern",
        "placement",
        "graduate",
        "junior",
        "software role",
        "developer role",
        "data analyst",
        "data scientist",
        "ai role",
        "roles",
    ]
    if (
        "apply today" in text
        or "jobs i should apply" in text
        or ("apply" in text and "today" in text and "job" in text)
        or "prioritise today" in text
        or "prioritize today" in text
        or ("show" in text and "follow" in text and ("application" in text or "follow-up" in text))
    ):
        return "daily_priority"
    if any(term in text for term in ["find", "search"]) and ("job" in text or any(term in text for term in role_terms)):
        return "search_jobs"
    if any(term in text for term in ["score", "match", "check"]) and "job" in text:
        return "score_job"
    if any(term in text for term in ["save this job", "track this application", "track application"]):
        return "track_application"
    if "tailor" in text and ("cv" in text or "resume" in text):
        return "cv_tailoring"
    if "recruiter" in text or "linkedin" in text or "follow-up" in text or "follow up" in text:
        return "message_writer"
    if "interview" in text or "prepare me" in text:
        return "interview_prep"
    if "remind" in text:
        return "reminder"
    return "general"


def create_action_plan(intent: str) -> List[str]:
    plans: Dict[str, List[str]] = {
        "search_jobs": [
            "Parse search filters from the instruction.",
            "Build safe source-adapter search links.",
            "Use saved job scoring rules once descriptions are pasted or added.",
        ],
        "score_job": [
            "Read the job description.",
            "Extract role, company, skills, requirements, and risk signals.",
            "Calculate a local match score out of 10.",
        ],
        "track_application": [
            "Confirm the job record.",
            "Create or update the application status.",
            "Log the tracking change.",
        ],
        "cv_tailoring": [
            "Extract CV keywords line by line.",
            "Classify keywords by evidence strength.",
            "Select three relevant projects and create a rewrite plan.",
            "Wait for approval before generating final LaTeX.",
        ],
        "message_writer": [
            "Identify message purpose and role context.",
            "Draft a concise message only.",
            "Store the draft without sending anything.",
        ],
        "interview_prep": [
            "Use the role context and Saneesh's real evidence.",
            "Prepare role, company, STAR, technical, and checklist sections.",
        ],
        "reminder": [
            "Extract the reminder title and due timing.",
            "Create a local reminder when the instruction is specific.",
            "Log the change.",
        ],
        "daily_priority": [
            "Read saved jobs and applications.",
            "Prioritise high-score jobs and dated follow-ups.",
            "Show clear next actions.",
        ],
        "general": [
            "Identify whether the instruction maps to a local job-search workflow.",
            "Answer directly or ask for the missing job description/link.",
        ],
    }
    return plans[intent]
