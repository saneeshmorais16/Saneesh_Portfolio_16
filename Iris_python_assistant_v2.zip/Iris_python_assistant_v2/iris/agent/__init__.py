"""Deterministic local agent components for Iris."""

