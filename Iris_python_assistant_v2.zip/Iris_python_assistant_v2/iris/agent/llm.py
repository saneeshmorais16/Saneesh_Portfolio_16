from typing import Optional

from iris.config import GEMINI_API_KEY, GEMINI_MODEL, OPENAI_API_KEY, OPENAI_MODEL


def improve_text(prompt: str) -> Optional[str]:
    if GEMINI_API_KEY:
        try:
            from google import genai

            client = genai.Client(api_key=GEMINI_API_KEY)
            response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
            return getattr(response, "text", None)
        except Exception:
            return None

    if OPENAI_API_KEY:
        try:
            from openai import OpenAI

            client = OpenAI(api_key=OPENAI_API_KEY)
            response = client.responses.create(model=OPENAI_MODEL, input=prompt)
            return getattr(response, "output_text", None)
        except Exception:
            return None

    return None

