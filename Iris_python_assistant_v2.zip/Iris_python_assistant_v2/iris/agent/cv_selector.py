from typing import Dict, List

from iris.agent.keyword_extractor import extract_skills
from iris.config import USER_PROFILE


PROJECT_KEYWORDS = {
    "ML Audit Engine for Loan Approval Models": ["machine learning", "model evaluation", "Random Forest", "XGBoost", "audit"],
    "AI Financial Document Analyzer API": ["FastAPI", "REST APIs", "NLP", "documentation", "financial"],
    "AI Automation and LLM Workflow Prototype": ["LLM workflows", "automation", "prompt engineering", "AI prototyping"],
    "Data Architecture and Business Process Mapping Prototype": ["SQL", "data validation", "documentation", "stakeholder communication"],
    "Customer Behaviour and Revenue Insights Dashboard": ["Tableau", "Power BI", "dashboards", "reporting", "data analysis"],
    "Business Data Monitoring and Anomaly Analysis Prototype": ["Python", "pandas", "NumPy", "data validation", "reporting"],
    "Reporting Automation and Data Quality Prototype": ["automation", "reporting", "data cleaning", "SQL"],
    "Financial Services Dashboard and Reporting Prototype": ["dashboards", "Power BI", "financial", "reporting"],
    "AI Impact OS": ["AI product", "stakeholder communication", "documentation"],
    "Smart Mixologist AI Recommendation App": ["Python", "recommendation", "AI prototyping"],
    "AI Job Market Intelligence API": ["FastAPI", "REST APIs", "job market", "Python"],
    "Personal AI Agent with Memory": ["LLM workflows", "agent", "memory", "prompt engineering"],
    "RAG Pipeline from Scratch": ["RAG", "NLP", "LLM workflows", "Python"],
    "AI Code Review Tool": ["GitHub", "LLM workflows", "documentation"],
    "Real Time Dashboard with Live Data": ["dashboards", "JavaScript", "reporting"],
    "End to End ML Pipeline with MLflow": ["machine learning", "model evaluation", "Python"],
    "Browser Extension Powered by AI": ["JavaScript", "AI prototyping", "automation"],
    "Automated Job Application Tracker": ["FastAPI", "SQLite", "automation", "job search"],
}


def select_projects(job_description: str) -> List[Dict[str, str]]:
    text = job_description.lower()
    extracted_skills = {skill.lower() for skill in extract_skills(job_description)}
    ranked = []

    for project in USER_PROFILE["project_bank"]:
        keywords = PROJECT_KEYWORDS.get(project, [])
        overlap = [keyword for keyword in keywords if keyword.lower() in text or keyword.lower() in extracted_skills]
        ranked.append((len(overlap), project, overlap or keywords[:2]))

    ranked.sort(key=lambda item: item[0], reverse=True)
    selected = []
    for _, project, overlap in ranked[:3]:
        evidence = ", ".join(overlap)
        selected.append(
            {
                "project": project,
                "justification": f"Use this project because it gives evidence for {evidence}.",
            }
        )
    return selected

