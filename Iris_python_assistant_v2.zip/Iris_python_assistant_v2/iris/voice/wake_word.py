def clean_push_to_talk_transcript(transcript: str) -> str:
    lowered = transcript.lower().strip()
    if lowered.startswith("iris,"):
        return transcript.strip()[5:].strip()
    if lowered.startswith("iris "):
        return transcript.strip()[5:].strip()
    return transcript.strip()

