"""Voice capability helpers for browser-based push-to-talk."""
