def availability() -> dict:
    return {"provider": "browser SpeechSynthesis", "server_dependency": False}

