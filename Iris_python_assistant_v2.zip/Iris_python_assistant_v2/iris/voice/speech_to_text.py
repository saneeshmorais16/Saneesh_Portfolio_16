def availability() -> dict:
    return {"provider": "browser Web Speech API", "server_dependency": False}

