import json
from typing import Any, Iterable

from sqlalchemy.orm import Session

from iris.database import utc_now
from iris.models import Company, Job


JSON_FIELDS = {"required_skills", "preferred_skills", "risk_flags"}


def as_dict(row: Any) -> dict:
    data = {column.name: getattr(row, column.name) for column in row.__table__.columns}
    for key in JSON_FIELDS:
        if key in data:
            try:
                data[key] = json.loads(data[key] or "[]")
            except json.JSONDecodeError:
                data[key] = []
    return data


def rows_as_dict(rows: Iterable[Any]) -> list[dict]:
    return [as_dict(row) for row in rows]


def get_or_create_company(session: Session, company_name: str) -> Company:
    name = (company_name or "Unknown company").strip() or "Unknown company"
    company = session.query(Company).filter(Company.name == name).one_or_none()
    if not company:
        company = Company(name=name)
        session.add(company)
        session.flush()
    return company


def apply_job_analysis(job: Job, analysis: dict) -> None:
    for field in [
        "company_name",
        "role_title",
        "location",
        "work_type",
        "salary",
        "date_posted",
        "deadline",
        "intake_start",
        "source",
        "application_url",
        "experience_requirement",
        "degree_requirement",
        "visa_sponsorship",
        "seniority_level",
        "role_category",
        "match_score",
        "match_reason",
    ]:
        if field in analysis and analysis[field] is not None:
            setattr(job, field, analysis[field])
    job.required_skills = json.dumps(analysis.get("required_skills") or [])
    job.preferred_skills = json.dumps(analysis.get("preferred_skills") or [])
    job.risk_flags = json.dumps(analysis.get("risk_flags") or [])
    job.updated_at = utc_now()

