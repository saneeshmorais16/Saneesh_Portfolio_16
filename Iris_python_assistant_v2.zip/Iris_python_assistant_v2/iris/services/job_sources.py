from urllib.parse import urlencode


SOURCES = {
    "LinkedIn Jobs": "https://www.linkedin.com/jobs/search/",
    "Indeed UK": "https://uk.indeed.com/jobs",
    "Glassdoor UK": "https://www.glassdoor.co.uk/Job/jobs.htm",
    "Gradcracker": "https://www.gradcracker.com/search/computing-technology/jobs",
    "Bright Network": "https://www.brightnetwork.co.uk/graduate-jobs/",
    "Milkround": "https://www.milkround.com/jobs",
    "RateMyPlacement": "https://www.ratemyplacement.co.uk/search/jobs",
    "Wellfound": "https://wellfound.com/jobs",
    "WorkInStartups": "https://www.workinstartups.com/job-board/jobs",
    "Otta": "https://app.otta.com/jobs",
    "Company careers pages": "https://www.google.com/search",
}


def build_source_links(query: str, location: str = "London", source: str | None = None) -> list[dict[str, str]]:
    selected = [source] if source and source in SOURCES else list(SOURCES.keys())
    links = []
    for name in selected:
        base = SOURCES[name]
        if name == "LinkedIn Jobs":
            params = {"keywords": query, "location": location}
        elif name == "Indeed UK":
            params = {"q": query, "l": location}
        elif name == "Glassdoor UK":
            params = {"sc.keyword": query, "locT": "C", "locId": "2671300"}
        elif name == "Company careers pages":
            params = {"q": f"{query} {location} careers graduate junior internship"}
        else:
            params = {"q": query, "location": location}
        links.append(
            {
                "source": name,
                "url": f"{base}?{urlencode(params)}",
                "note": "Open this search, paste relevant job descriptions back into Iris for extraction and scoring.",
            }
        )
    return links


def build_search_query(payload: dict) -> str:
    terms = [
        payload.get("query"),
        payload.get("role_type"),
        payload.get("start_date"),
        payload.get("work_type"),
        " ".join(payload.get("skills") or []),
    ]
    return " ".join(term for term in terms if term).strip() or "junior AI graduate software data roles"

