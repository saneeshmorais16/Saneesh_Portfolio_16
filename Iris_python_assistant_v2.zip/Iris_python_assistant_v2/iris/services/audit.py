import json
from typing import Any, List

from sqlalchemy.orm import Session

from iris.models import AuditLog


def write_audit(
    session: Session,
    event_type: str,
    user_input: str | None,
    action_plan: List[str] | None,
    result: Any,
    risk_level: str = "low",
    requires_approval: bool = False,
) -> AuditLog:
    log = AuditLog(
        event_type=event_type,
        user_input=user_input,
        action_plan=json.dumps(action_plan or []),
        result=result if isinstance(result, str) else json.dumps(result),
        risk_level=risk_level,
        requires_approval=requires_approval,
    )
    session.add(log)
    session.flush()
    return log

