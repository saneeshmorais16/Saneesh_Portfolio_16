from sqlalchemy import Boolean, Column, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from iris.database import Base, utc_now


class Company(Base):
    __tablename__ = "companies"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), unique=True, nullable=False, index=True)
    website = Column(String(1000))
    notes = Column(Text)
    created_at = Column(String(64), default=utc_now, nullable=False)

    jobs = relationship("Job", back_populates="company")


class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"))
    company_name = Column(String(255), default="Unknown company", nullable=False)
    role_title = Column(String(255), default="Untitled role", nullable=False)
    location = Column(String(255))
    work_type = Column(String(100))
    salary = Column(String(255))
    date_posted = Column(String(255))
    deadline = Column(String(255))
    intake_start = Column(String(255))
    source = Column(String(255))
    application_url = Column(String(1000))
    description = Column(Text)
    required_skills = Column(Text, default="[]")
    preferred_skills = Column(Text, default="[]")
    experience_requirement = Column(String(255))
    degree_requirement = Column(String(255))
    visa_sponsorship = Column(String(500))
    seniority_level = Column(String(100))
    role_category = Column(String(120))
    match_score = Column(Float, default=0.0)
    match_reason = Column(Text)
    risk_flags = Column(Text, default="[]")
    status = Column(String(80), default="Found", nullable=False)
    notes = Column(Text)
    created_at = Column(String(64), default=utc_now, nullable=False)
    updated_at = Column(String(64), default=utc_now, nullable=False)

    company = relationship("Company", back_populates="jobs")
    applications = relationship("Application", back_populates="job")


class Application(Base):
    __tablename__ = "applications"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"))
    company_name = Column(String(255), nullable=False)
    role_title = Column(String(255), nullable=False)
    status = Column(String(80), default="Found", nullable=False)
    stage_notes = Column(Text)
    applied_at = Column(String(255))
    follow_up_at = Column(String(255))
    created_at = Column(String(64), default=utc_now, nullable=False)
    updated_at = Column(String(64), default=utc_now, nullable=False)

    job = relationship("Job", back_populates="applications")


class Contact(Base):
    __tablename__ = "contacts"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"))
    name = Column(String(255), nullable=False)
    role = Column(String(255))
    email = Column(String(255))
    linkedin_url = Column(String(1000))
    notes = Column(Text)
    created_at = Column(String(64), default=utc_now, nullable=False)


class CVVersion(Base):
    __tablename__ = "cv_versions"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"))
    name = Column(String(255), nullable=False)
    rewrite_plan = Column(Text, nullable=False)
    content_latex = Column(Text)
    status = Column(String(80), default="Plan Ready", nullable=False)
    created_at = Column(String(64), default=utc_now, nullable=False)


class RecruiterMessage(Base):
    __tablename__ = "recruiter_messages"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"))
    message_type = Column(String(120), nullable=False)
    subject = Column(String(255))
    body = Column(Text, nullable=False)
    status = Column(String(80), default="Draft", nullable=False)
    created_at = Column(String(64), default=utc_now, nullable=False)
    updated_at = Column(String(64), default=utc_now, nullable=False)


class InterviewNote(Base):
    __tablename__ = "interview_notes"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"))
    content = Column(Text, nullable=False)
    created_at = Column(String(64), default=utc_now, nullable=False)


class Reminder(Base):
    __tablename__ = "reminders"

    id = Column(Integer, primary_key=True, index=True)
    job_id = Column(Integer, ForeignKey("jobs.id"))
    application_id = Column(Integer, ForeignKey("applications.id"))
    title = Column(String(500), nullable=False)
    due_at = Column(String(255))
    status = Column(String(80), default="Pending", nullable=False)
    created_at = Column(String(64), default=utc_now, nullable=False)
    updated_at = Column(String(64), default=utc_now, nullable=False)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    event_type = Column(String(120), nullable=False)
    user_input = Column(Text)
    action_plan = Column(Text, default="[]")
    result = Column(Text)
    risk_level = Column(String(80), default="low", nullable=False)
    requires_approval = Column(Boolean, default=False, nullable=False)
    created_at = Column(String(64), default=utc_now, nullable=False)


class UserPreference(Base):
    __tablename__ = "user_preferences"

    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(255), unique=True, nullable=False)
    value = Column(Text, nullable=False)
    updated_at = Column(String(64), default=utc_now, nullable=False)

