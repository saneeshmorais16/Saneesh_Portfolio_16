from typing import Optional, List
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=3000)


class ChatResponse(BaseModel):
    reply: str
    category: str
    tool_used: Optional[str] = None
    response_time_ms: int


class TaskCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=500)
    due_date: Optional[str] = None
    priority: str = "normal"


class TaskUpdate(BaseModel):
    status: str


class Task(BaseModel):
    id: int
    title: str
    due_date: Optional[str] = None
    priority: str
    status: str
    created_at: str
    completed_at: Optional[str] = None
