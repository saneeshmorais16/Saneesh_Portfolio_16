import time
from typing import Dict, Any, Optional

from backend.config import GEMINI_API_KEY, GEMINI_MODEL
from backend.database import get_connection, utc_now
from backend.tools.task_tool import create_task, list_tasks, simple_task_from_command

SYSTEM_INSTRUCTION = """
You are Iris Python Assistant, a practical AI productivity assistant for Saneesh.

Your role:
- Help with coding, job applications, interview preparation, data analysis learning and productivity.
- Teach data analyst skills using simple examples.
- When useful, explain concepts with SQL, Python pandas, KPIs or dashboard examples.
- Do not pretend to access Gmail, Calendar or files unless a real tool is connected.
- For sensitive actions, explain that human approval is required.

Tone:
- Clear, supportive and honest.
- Avoid exaggerated claims.
- Give realistic next steps.
"""


def detect_category(message: str) -> str:
    text = message.lower()

    if any(word in text for word in ["sql", "excel", "pandas", "dashboard", "chart", "data analyst", "data analysis", "kpi"]):
        return "data_analytics"

    if any(word in text for word in ["task", "remind", "todo", "to-do"]):
        return "task_management"

    if any(word in text for word in ["interview", "cv", "resume", "job", "application", "linkedin"]):
        return "career"

    if any(word in text for word in ["python", "fastapi", "html", "css", "javascript", "bug", "code"]):
        return "coding"

    if any(word in text for word in ["email", "calendar", "meeting"]):
        return "workflow"

    return "general"


def log_interaction(
    user_command: str,
    assistant_response: str,
    command_category: str,
    tool_used: Optional[str],
    response_time_ms: int,
    success: bool,
    error_message: Optional[str] = None,
) -> None:
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO assistant_logs
            (timestamp, user_command, assistant_response, command_category, tool_used, response_time_ms, success, error_message)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                utc_now(),
                user_command,
                assistant_response,
                command_category,
                tool_used,
                response_time_ms,
                1 if success else 0,
                error_message,
            ),
        )
        conn.commit()


def build_fallback_reply(category: str) -> str:
    if not GEMINI_API_KEY:
        return (
            "I am running in fallback mode because no Gemini API key is configured. "
            "Add your GEMINI_API_KEY in the .env file, save it, and restart the server."
        )

    if category == "data_analytics":
        return (
            "I could not reach the Gemini model, but here is the data analyst direction: "
            "start by defining the business question, collect the right data, clean it, analyse it, "
            "then explain the insight with evidence."
        )

    return (
        "I could not reach the Gemini model. Check your API key, internet connection, model name, "
        "and terminal error message."
    )


def call_gemini(message: str) -> str:
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is not configured.")

    from google import genai

    client = genai.Client(api_key=GEMINI_API_KEY)

    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=f"{SYSTEM_INSTRUCTION}\n\nUser message:\n{message}",
    )

    text = getattr(response, "text", None)

    if not text:
        return "I received a response, but it did not include text. Try rephrasing your question."

    return text


def handle_chat(message: str) -> Dict[str, Any]:
    start_time = time.perf_counter()
    category = detect_category(message)
    tool_used = None

    try:
        cleaned_message = message.strip()
        task_title = simple_task_from_command(cleaned_message)

        if task_title:
            task = create_task(title=task_title)
            reply = f"Task added: {task['title']}"
            tool_used = "task_tool.create_task"

        elif "show my tasks" in cleaned_message.lower() or "list my tasks" in cleaned_message.lower():
            tasks = list_tasks(status="pending")
            tool_used = "task_tool.list_tasks"

            if not tasks:
                reply = "You have no pending tasks."
            else:
                task_lines = [
                    f"{index + 1}. {task['title']} ({task['status']})"
                    for index, task in enumerate(tasks)
                ]
                reply = "Here are your pending tasks:\n" + "\n".join(task_lines)

        else:
            try:
                reply = call_gemini(cleaned_message)
            except Exception as exc:
                print("Gemini error:", exc)
                reply = build_fallback_reply(category)

        response_time_ms = int((time.perf_counter() - start_time) * 1000)

        log_interaction(
            user_command=message,
            assistant_response=reply,
            command_category=category,
            tool_used=tool_used,
            response_time_ms=response_time_ms,
            success=True,
        )

        return {
            "reply": reply,
            "category": category,
            "tool_used": tool_used,
            "response_time_ms": response_time_ms,
        }

    except Exception as exc:
        response_time_ms = int((time.perf_counter() - start_time) * 1000)
        error_reply = "Something went wrong while processing your command."

        log_interaction(
            user_command=message,
            assistant_response=error_reply,
            command_category=category,
            tool_used=tool_used,
            response_time_ms=response_time_ms,
            success=False,
            error_message=str(exc),
        )

        return {
            "reply": error_reply,
            "category": category,
            "tool_used": tool_used,
            "response_time_ms": response_time_ms,
        }
