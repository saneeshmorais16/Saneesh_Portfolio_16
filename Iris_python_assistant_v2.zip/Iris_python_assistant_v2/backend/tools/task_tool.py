from typing import Optional, List, Dict, Any

from backend.database import get_connection, utc_now


def create_task(title: str, due_date: Optional[str] = None, priority: str = "normal") -> Dict[str, Any]:
    title = title.strip()

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO tasks (title, due_date, priority, status, created_at)
            VALUES (?, ?, ?, 'pending', ?)
            """,
            (title, due_date, priority, utc_now()),
        )
        conn.commit()
        task_id = cursor.lastrowid

    return {
        "id": task_id,
        "title": title,
        "due_date": due_date,
        "priority": priority,
        "status": "pending",
    }


def list_tasks(status: Optional[str] = None) -> List[Dict[str, Any]]:
    with get_connection() as conn:
        cursor = conn.cursor()

        if status:
            rows = cursor.execute(
                "SELECT * FROM tasks WHERE status = ? ORDER BY created_at DESC",
                (status,),
            ).fetchall()
        else:
            rows = cursor.execute(
                "SELECT * FROM tasks ORDER BY created_at DESC"
            ).fetchall()

    return [dict(row) for row in rows]


def update_task_status(task_id: int, status: str) -> Optional[Dict[str, Any]]:
    completed_at = utc_now() if status == "completed" else None

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            UPDATE tasks
            SET status = ?, completed_at = ?
            WHERE id = ?
            """,
            (status, completed_at, task_id),
        )
        conn.commit()

        row = cursor.execute(
            "SELECT * FROM tasks WHERE id = ?",
            (task_id,),
        ).fetchone()

    return dict(row) if row else None


def simple_task_from_command(command: str) -> Optional[str]:
    text = command.strip()
    lowered = text.lower()

    prefixes = [
        "add task",
        "create task",
        "new task",
        "remind me to",
        "task:",
    ]

    for prefix in prefixes:
        if lowered.startswith(prefix):
            return text[len(prefix):].strip(" :,-")

    return None
