from pathlib import Path
from dotenv import load_dotenv
import os

ROOT_DIR = Path(__file__).resolve().parent.parent

# Load .env from the exact project root, not from a random terminal location.
ENV_FILE = ROOT_DIR / ".env"
load_dotenv(dotenv_path=ENV_FILE, override=True)

APP_NAME = os.getenv("APP_NAME", "Iris Python Assistant")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

DATABASE_PATH = os.getenv("DATABASE_PATH", "data/iris.db")
DATABASE_FILE = ROOT_DIR / DATABASE_PATH

FRONTEND_DIR = ROOT_DIR / "frontend"
STATIC_DIR = FRONTEND_DIR / "static"
