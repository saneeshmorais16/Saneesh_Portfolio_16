import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from backend.config import DATABASE_FILE


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_database() -> None:
    DATABASE_FILE.parent.mkdir(parents=True, exist_ok=True)

    with sqlite3.connect(DATABASE_FILE) as conn:
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                due_date TEXT,
                priority TEXT DEFAULT 'normal',
                status TEXT DEFAULT 'pending',
                created_at TEXT NOT NULL,
                completed_at TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS assistant_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                user_command TEXT NOT NULL,
                assistant_response TEXT NOT NULL,
                command_category TEXT NOT NULL,
                tool_used TEXT,
                response_time_ms INTEGER NOT NULL,
                success INTEGER NOT NULL,
                error_message TEXT
            )
        """)

        conn.commit()


@contextmanager
def get_connection():
    ensure_database()
    conn = sqlite3.connect(DATABASE_FILE)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()
