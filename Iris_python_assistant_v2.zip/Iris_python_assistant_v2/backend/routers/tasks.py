from typing import List

from fastapi import APIRouter, HTTPException

from backend.schemas import TaskCreate, TaskUpdate, Task
from backend.tools.task_tool import create_task, list_tasks, update_task_status

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


@router.get("", response_model=List[Task])
def get_tasks():
    return list_tasks()


@router.post("", response_model=dict)
def add_task(task: TaskCreate):
    return create_task(
        title=task.title,
        due_date=task.due_date,
        priority=task.priority,
    )


@router.patch("/{task_id}", response_model=Task)
def update_task(task_id: int, update: TaskUpdate):
    if update.status not in {"pending", "completed"}:
        raise HTTPException(
            status_code=400,
            detail="Status must be 'pending' or 'completed'.",
        )

    updated = update_task_status(task_id, update.status)

    if not updated:
        raise HTTPException(status_code=404, detail="Task not found.")

    return updated
