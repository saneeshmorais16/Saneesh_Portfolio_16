from fastapi import APIRouter

from backend.database import get_connection

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/summary")
def analytics_summary():
    with get_connection() as conn:
        total_commands = conn.execute(
            "SELECT COUNT(*) AS count FROM assistant_logs"
        ).fetchone()["count"]

        successful_commands = conn.execute(
            "SELECT COUNT(*) AS count FROM assistant_logs WHERE success = 1"
        ).fetchone()["count"]

        failed_commands = conn.execute(
            "SELECT COUNT(*) AS count FROM assistant_logs WHERE success = 0"
        ).fetchone()["count"]

        avg_row = conn.execute(
            "SELECT AVG(response_time_ms) AS avg_time FROM assistant_logs"
        ).fetchone()

        category_row = conn.execute(
            """
            SELECT command_category, COUNT(*) AS count
            FROM assistant_logs
            GROUP BY command_category
            ORDER BY count DESC
            LIMIT 1
            """
        ).fetchone()

        pending_tasks = conn.execute(
            "SELECT COUNT(*) AS count FROM tasks WHERE status = 'pending'"
        ).fetchone()["count"]

        completed_tasks = conn.execute(
            "SELECT COUNT(*) AS count FROM tasks WHERE status = 'completed'"
        ).fetchone()["count"]

    return {
        "total_commands": total_commands,
        "successful_commands": successful_commands,
        "failed_commands": failed_commands,
        "average_response_time_ms": round(avg_row["avg_time"] or 0, 2),
        "most_used_category": category_row["command_category"] if category_row else None,
        "pending_tasks": pending_tasks,
        "completed_tasks": completed_tasks,
    }


@router.get("/logs")
def get_logs(limit: int = 50):
    limit = min(max(limit, 1), 200)

    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT *
            FROM assistant_logs
            ORDER BY timestamp DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()

    return [dict(row) for row in rows]


@router.get("/category-counts")
def category_counts():
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT command_category, COUNT(*) AS total
            FROM assistant_logs
            GROUP BY command_category
            ORDER BY total DESC
            """
        ).fetchall()

    return [dict(row) for row in rows]
