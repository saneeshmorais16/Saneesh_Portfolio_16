from fastapi import APIRouter

from backend.schemas import ChatRequest, ChatResponse
from backend.services.ai_service import handle_chat

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
def chat(request: ChatRequest):
    return handle_chat(request.message)
