# CMD run commands

```cmd
cd "C:\Users\sanee\AppData\Local\Programs\Python\Python313\Iris_python_assistant_v2"
python -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
copy .env.example .env
notepad .env
python -c "from backend.config import GEMINI_API_KEY; print('CONFIG KEY LOADED' if GEMINI_API_KEY else 'CONFIG NO KEY')"
uvicorn backend.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```
