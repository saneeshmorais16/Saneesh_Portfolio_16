const state = {
  jobs: [],
  applications: [],
  reminders: [],
  audit: [],
  memory: null,
};

const statusOrder = [
  "Found",
  "Shortlisted",
  "CV Needed",
  "CV Tailored",
  "Applied",
  "Assessment",
  "Interview",
  "Follow-Up",
  "Rejected",
  "Offer",
  "Archived",
];

const $ = (id) => document.getElementById(id);

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function pretty(value) {
  return JSON.stringify(value, null, 2);
}

function compactText(value, fallback = "-") {
  const text = String(value ?? "").trim();
  return text || fallback;
}

async function fetchJSON(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.detail || response.statusText || "Request failed");
  }
  return data;
}

function setNotice(element, message, hidden = false) {
  element.textContent = message;
  element.classList.toggle("hidden", hidden);
}

function addMessage(text, sender = "assistant") {
  const node = document.createElement("div");
  node.className = `message ${sender}`;
  node.textContent = text;
  $("chatWindow").appendChild(node);
  $("chatWindow").scrollTop = $("chatWindow").scrollHeight;
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-GB";
  utterance.rate = 1;
  window.speechSynthesis.speak(utterance);
}

function scoreClass(score) {
  if (score >= 7) return "good";
  if (score >= 5) return "warn";
  return "danger";
}

function pill(text, score) {
  return `<span class="pill ${scoreClass(Number(score) || 0)}">${escapeHtml(text)}</span>`;
}

async function checkHealth() {
  try {
    const health = await fetchJSON("/health");
    $("apiStatus").textContent = "Online";
    $("assistantMode").textContent = health.mode || "Local";
  } catch (error) {
    $("apiStatus").textContent = "Offline";
  }
}

async function loadVoiceCapabilities() {
  const target = $("voiceCapability");
  try {
    const data = await fetchJSON("/api/voice/capabilities");
    target.textContent = `${data.speech_to_text}; ${data.text_to_speech}.`;
  } catch (error) {
    target.textContent = "Voice status could not be checked. Text chat still works.";
  }
}

async function sendAgentCommand(message, viaVoice = false) {
  const clean = message.trim();
  if (!clean) return;
  addMessage(clean, "user");
  $("commandInput").value = "";
  try {
    const url = viaVoice ? "/api/agent/voice-command" : "/api/agent/chat";
    const body = viaVoice ? { transcript: clean } : { message: clean };
    const result = await fetchJSON(url, { method: "POST", body: JSON.stringify(body) });
    addMessage(result.reply, "assistant");
    if (viaVoice) speak(result.spoken_response || result.reply);
    if (result.data && result.data.links) {
      renderSearchLinks({ links: result.data.links, message: result.reply });
    }
    await refreshAll();
  } catch (error) {
    addMessage(`I could not process that command: ${error.message}`, "assistant");
  }
}

function startVoiceCapture() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const notice = $("voiceNotice");
  if (!SpeechRecognition) {
    const message = "Voice input is unavailable in this browser. Text chat is still available.";
    setNotice(notice, message);
    $("voiceCapability").textContent = message;
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = "en-GB";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  $("voiceState").textContent = "Listening";
  $("voiceState").className = "pill good";
  setNotice(notice, "Listening...", false);

  recognition.onresult = async (event) => {
    const transcript = event.results[0][0].transcript;
    $("voiceTranscript").value = transcript;
    $("voiceState").textContent = "Processing";
    await sendAgentCommand(transcript, true);
  };

  recognition.onerror = () => {
    $("voiceState").textContent = "Idle";
    $("voiceState").className = "pill neutral";
    setNotice(notice, "Voice input failed. Type the command instead.", false);
  };

  recognition.onend = () => {
    $("voiceState").textContent = "Idle";
    $("voiceState").className = "pill neutral";
  };

  recognition.start();
}

function formObject(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  Object.keys(data).forEach((key) => {
    if (typeof data[key] === "string") data[key] = data[key].trim();
    if (data[key] === "") delete data[key];
  });
  return data;
}

function renderSearchLinks(data) {
  const target = $("searchResults");
  if (!data.links || !data.links.length) {
    target.className = "result-list empty-state";
    target.textContent = "No source links returned.";
    return;
  }
  target.className = "result-list";
  target.innerHTML = data.links
    .map(
      (link) => `
      <div class="result-item">
        <strong>${escapeHtml(link.source)}</strong>
        <a href="${escapeHtml(link.url)}" target="_blank" rel="noreferrer">Open search</a>
        <p>${escapeHtml(link.note)}</p>
      </div>`
    )
    .join("");
}

async function handleSearch(event) {
  event.preventDefault();
  const payload = formObject(event.currentTarget);
  payload.skills = payload.skills ? payload.skills.split(",").map((item) => item.trim()).filter(Boolean) : [];
  payload.minimum_match_score = Number(payload.minimum_match_score || 7);
  try {
    const data = await fetchJSON("/api/jobs/search", { method: "POST", body: JSON.stringify(payload) });
    renderSearchLinks(data);
    await loadAudit();
  } catch (error) {
    $("searchResults").className = "result-list empty-state";
    $("searchResults").textContent = error.message;
  }
}

async function handleJobSave(event) {
  event.preventDefault();
  const payload = formObject(event.currentTarget);
  if (!payload.description) {
    $("scoreResult").textContent = "Paste a job description before saving.";
    return;
  }
  try {
    const data = await fetchJSON("/api/jobs/add", { method: "POST", body: JSON.stringify(payload) });
    renderScoreResult(data);
    event.currentTarget.reset();
    await refreshAll();
  } catch (error) {
    $("scoreResult").textContent = error.message;
  }
}

function renderScoreResult(data) {
  const job = data.job;
  $("scoreResult").className = "score-output";
  $("scoreResult").innerHTML = `
    <div class="job-card">
      <div class="job-card-top">
        <div>
          <strong>${escapeHtml(job.role_title)}</strong>
          <span>${escapeHtml(job.company_name)} - ${escapeHtml(job.location || "Location not extracted")}</span>
        </div>
        <div class="score-badge">${Number(job.match_score || 0).toFixed(1)}</div>
      </div>
      <div>${pill(data.recommendation || "Scored", job.match_score)}</div>
      <p>${escapeHtml(job.match_reason || "No match reason available.")}</p>
    </div>`;
}

async function loadJobs() {
  const showAll = $("showAllJobs").checked;
  state.jobs = await fetchJSON(`/api/jobs${showAll ? "?show_all=true" : ""}`);
  renderJobs();
  renderJobSelects();
  renderQueues();
}

function renderJobs() {
  const cards = $("scoreCards");
  const table = $("jobsTable");
  if (!state.jobs.length) {
    cards.innerHTML = `<div class="empty-state">No saved jobs scoring 7+ yet. Paste a job description to create the first scored record.</div>`;
    table.innerHTML = `<tr><td colspan="6">No saved jobs to show.</td></tr>`;
    return;
  }

  cards.innerHTML = state.jobs
    .slice(0, 4)
    .map(
      (job) => `
      <article class="job-card">
        <div class="job-card-top">
          <div>
            <strong>${escapeHtml(job.role_title)}</strong>
            <span>${escapeHtml(job.company_name)}</span>
          </div>
          <div class="score-badge">${Number(job.match_score || 0).toFixed(1)}</div>
        </div>
        <div>${pill(job.status, job.match_score)}</div>
        <p>${escapeHtml(job.match_reason || "Score ready.")}</p>
      </article>`
    )
    .join("");

  table.innerHTML = state.jobs
    .map(
      (job) => `
      <tr>
        <td>${pill(Number(job.match_score || 0).toFixed(1), job.match_score)}</td>
        <td>${escapeHtml(job.role_title)}</td>
        <td>${escapeHtml(job.company_name)}</td>
        <td>${escapeHtml(job.location || "-")}</td>
        <td>${escapeHtml(job.status)}</td>
        <td>
          <div class="row-actions">
            <button class="secondary" data-action="score" data-job="${job.id}" type="button">Score</button>
            <button class="secondary" data-action="shortlist" data-job="${job.id}" type="button">Shortlist</button>
            <button class="secondary" data-action="track" data-job="${job.id}" type="button">Track</button>
            <button class="secondary" data-action="archive" data-job="${job.id}" type="button">Archive</button>
          </div>
        </td>
      </tr>`
    )
    .join("");
}

async function handleJobAction(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const jobId = Number(button.dataset.job);
  const action = button.dataset.action;
  try {
    if (action === "score") {
      await fetchJSON(`/api/jobs/${jobId}/score`, { method: "POST" });
    }
    if (action === "shortlist") {
      await fetchJSON(`/api/jobs/${jobId}/shortlist`, { method: "POST" });
    }
    if (action === "track") {
      await fetchJSON("/api/applications", {
        method: "POST",
        body: JSON.stringify({ job_id: jobId, status: "Found" }),
      });
    }
    if (action === "archive") {
      const approved = window.confirm("Archive this job record?");
      if (!approved) return;
      await fetchJSON(`/api/jobs/${jobId}/archive?approved=true`, { method: "POST" });
    }
    await refreshAll();
  } catch (error) {
    addMessage(error.message, "assistant");
  }
}

async function loadApplications() {
  state.applications = await fetchJSON("/api/applications");
  renderPipeline();
  renderQueues();
}

function renderPipeline() {
  const board = $("pipelineBoard");
  const columns = statusOrder.filter((status) => status !== "Archived");
  board.innerHTML = columns
    .map((status) => {
      const applications = state.applications.filter((app) => app.status === status);
      const cards = applications.length
        ? applications
            .map(
              (app) => `
            <div class="pipeline-card">
              <strong>${escapeHtml(app.role_title)}</strong>
              <span>${escapeHtml(app.company_name)}</span>
            </div>`
            )
            .join("")
        : `<div class="empty-state">Empty</div>`;
      return `<section class="pipeline-column"><h4>${escapeHtml(status)}</h4>${cards}</section>`;
    })
    .join("");
}

function renderJobSelects() {
  const options = [`<option value="">Use pasted description or generic context</option>`]
    .concat(
      state.jobs.map(
        (job) => `<option value="${job.id}">${escapeHtml(job.role_title)} - ${escapeHtml(job.company_name)}</option>`
      )
    )
    .join("");
  ["cvJobSelect", "messageJobSelect", "interviewJobSelect"].forEach((id) => {
    $(id).innerHTML = options;
  });
}

function cvPayload() {
  const jobId = $("cvJobSelect").value;
  const text = $("cvJobDescription").value.trim();
  if (jobId) return { job_id: Number(jobId) };
  if (text) return { job_description: text };
  return null;
}

async function handleCv(endpoint) {
  const payload = cvPayload();
  if (!payload) {
    $("cvOutput").textContent = "Select a saved job or paste a job description.";
    return;
  }
  if (endpoint === "generate-latex") {
    payload.approved = $("cvApproved").checked;
  }
  try {
    const data = await fetchJSON(`/api/cv/${endpoint}`, { method: "POST", body: JSON.stringify(payload) });
    $("cvOutput").textContent = data.latex || pretty(data);
    await loadAudit();
  } catch (error) {
    $("cvOutput").textContent = error.message;
  }
}

async function handleMessageDraft() {
  const type = $("messageType").value;
  const endpoint = type === "follow-up" ? "follow-up" : type === "thank-you" ? "thank-you" : "recruiter";
  const jobId = $("messageJobSelect").value;
  const payload = {
    message_type: type,
    recipient_name: $("recipientName").value.trim() || null,
  };
  if (jobId) payload.job_id = Number(jobId);
  try {
    const data = await fetchJSON(`/api/messages/${endpoint}`, { method: "POST", body: JSON.stringify(payload) });
    $("messageOutput").textContent = `${data.message.subject}\n\n${data.message.body}\n\n${data.notice}`;
    await loadAudit();
  } catch (error) {
    $("messageOutput").textContent = error.message;
  }
}

async function handleInterviewPrep() {
  const jobId = $("interviewJobSelect").value;
  const payload = {};
  if (jobId) payload.job_id = Number(jobId);
  const text = $("interviewDescription").value.trim();
  if (text) payload.job_description = text;
  try {
    const data = await fetchJSON("/api/interviews/prepare", { method: "POST", body: JSON.stringify(payload) });
    $("interviewOutput").textContent = pretty(data.prep);
    await loadAudit();
  } catch (error) {
    $("interviewOutput").textContent = error.message;
  }
}

async function loadReminders() {
  state.reminders = await fetchJSON("/api/reminders");
  renderReminders();
  renderQueues();
}

function renderReminders() {
  const list = $("reminderList");
  if (!state.reminders.length) {
    list.innerHTML = `<div class="empty-state">No reminders saved.</div>`;
    return;
  }
  list.innerHTML = state.reminders
    .map(
      (reminder) => `
      <div class="result-item">
        <strong>${escapeHtml(reminder.title)}</strong>
        <span>${escapeHtml(reminder.due_at || "No date")} - ${escapeHtml(reminder.status)}</span>
        <div class="row-actions">
          <button class="secondary" data-reminder="${reminder.id}" type="button">Complete</button>
        </div>
      </div>`
    )
    .join("");
}

async function handleReminderCreate(event) {
  event.preventDefault();
  const payload = formObject(event.currentTarget);
  if (!payload.title) return;
  try {
    await fetchJSON("/api/reminders", { method: "POST", body: JSON.stringify(payload) });
    event.currentTarget.reset();
    await refreshAll();
  } catch (error) {
    addMessage(error.message, "assistant");
  }
}

async function handleReminderComplete(event) {
  const button = event.target.closest("button[data-reminder]");
  if (!button) return;
  await fetchJSON(`/api/reminders/${button.dataset.reminder}`, {
    method: "PATCH",
    body: JSON.stringify({ status: "Completed" }),
  });
  await refreshAll();
}

function renderQueues() {
  const apply = state.jobs.filter((job) => job.match_score >= 7 && ["Found", "Shortlisted"].includes(job.status));
  const needsCv = state.jobs.filter((job) => job.match_score >= 7 && ["Found", "Shortlisted", "CV Needed"].includes(job.status));
  const followUps = [
    ...state.applications.filter((app) => ["Applied", "Follow-Up"].includes(app.status)),
    ...state.reminders.filter((reminder) => reminder.status !== "Completed"),
  ];
  const interviews = state.applications.filter((app) => app.status === "Interview");
  renderMiniList("applyQueue", apply, "No high-score jobs waiting.");
  renderMiniList("cvQueue", needsCv, "No CV queue items.");
  renderMiniList("followUpQueue", followUps, "No follow-ups due.");
  if ($("interviewQueue")) renderMiniList("interviewQueue", interviews, "No interview prep queue items.");
}

function renderMiniList(id, rows, emptyText) {
  const target = $(id);
  if (!target) return;
  if (!rows.length) {
    target.innerHTML = `<div class="empty-state">${escapeHtml(emptyText)}</div>`;
    return;
  }
  target.innerHTML = rows
    .slice(0, 6)
    .map((row) => {
      const title = row.role_title || row.title;
      const sub = row.company_name || row.due_at || row.status;
      return `<div class="mini-item"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(compactText(sub))}</span></div>`;
    })
    .join("");
}

async function loadAudit() {
  state.audit = await fetchJSON("/api/audit");
  const target = $("auditTimeline");
  if (!state.audit.length) {
    target.innerHTML = `<div class="empty-state">No audit events yet.</div>`;
    return;
  }
  target.innerHTML = state.audit
    .map(
      (item) => `
      <div class="timeline-item">
        <strong>${escapeHtml(item.event_type)}</strong>
        <span>${escapeHtml(item.created_at)}</span>
        <p>${escapeHtml(item.result || "")}</p>
      </div>`
    )
    .join("");
}

async function loadMemory() {
  state.memory = await fetchJSON("/api/memory");
  const profile = state.memory.profile;
  const target = $("memoryPanel");
  target.innerHTML = `
    <div><strong>${escapeHtml(profile.name)}</strong> - ${escapeHtml(profile.location)}</div>
    <div>${escapeHtml(profile.email)}</div>
    <div>${escapeHtml(profile.education)}</div>
    <div><strong>Targets:</strong> ${escapeHtml(profile.target_roles.slice(0, 6).join(", "))}</div>
    <div><strong>Saved preferences:</strong> ${escapeHtml(Object.keys(state.memory.preferences).join(", ") || "None")}</div>
  `;
}

async function handlePreferenceSave(event) {
  event.preventDefault();
  const payload = formObject(event.currentTarget);
  if (!payload.key || !payload.value) return;
  const approved = window.confirm("Save this preference to Iris memory?");
  if (!approved) return;
  try {
    await fetchJSON("/api/memory/preferences", {
      method: "PATCH",
      body: JSON.stringify({ preferences: { [payload.key]: payload.value }, approved: true }),
    });
    event.currentTarget.reset();
    await refreshAll();
  } catch (error) {
    addMessage(error.message, "assistant");
  }
}

async function refreshAll() {
  await Promise.allSettled([loadJobs(), loadApplications(), loadReminders(), loadAudit(), loadMemory()]);
}

function wireEvents() {
  $("commandSend").addEventListener("click", () => sendAgentCommand($("commandInput").value));
  $("commandInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter") sendAgentCommand($("commandInput").value);
  });
  $("talkButton").addEventListener("click", startVoiceCapture);
  $("voicePanelButton").addEventListener("click", startVoiceCapture);
  $("clearChat").addEventListener("click", () => {
    $("chatWindow").innerHTML = "";
    addMessage("Chat cleared. What job-search task should Iris handle now?", "assistant");
  });
  $("themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("light");
    $("themeToggle").textContent = document.body.classList.contains("light") ? "Dark mode" : "Light mode";
  });
  $("searchForm").addEventListener("submit", handleSearch);
  $("jobForm").addEventListener("submit", handleJobSave);
  $("showAllJobs").addEventListener("change", loadJobs);
  $("jobsTable").addEventListener("click", handleJobAction);
  $("cvAnalyse").addEventListener("click", () => handleCv("analyse-job"));
  $("cvPlan").addEventListener("click", () => handleCv("rewrite-plan"));
  $("cvLatex").addEventListener("click", () => handleCv("generate-latex"));
  $("draftMessage").addEventListener("click", handleMessageDraft);
  $("prepareInterview").addEventListener("click", handleInterviewPrep);
  $("reminderForm").addEventListener("submit", handleReminderCreate);
  $("reminderList").addEventListener("click", handleReminderComplete);
  $("preferenceForm").addEventListener("submit", handlePreferenceSave);
  $("refreshAudit").addEventListener("click", loadAudit);
}

wireEvents();
checkHealth();
loadVoiceCapabilities();
refreshAll();
