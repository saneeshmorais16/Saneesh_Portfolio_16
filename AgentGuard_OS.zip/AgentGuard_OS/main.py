from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.core.database import Base, SessionLocal, engine, ensure_sqlite_schema
from app.models import agent, api_request, approval, audit_event, policy, tool
from app.routes import agents, approvals, dashboard, policies, reports, requests, simulation, tools
from seed import seed_database


BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(
    title=settings.APP_NAME,
    description="AI agent security and API governance command centre.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(bind=engine)
    ensure_sqlite_schema()
    db = SessionLocal()
    try:
        seed_database(db, reset=False)
    finally:
        db.close()


app.include_router(dashboard.router, prefix="/api", tags=["dashboard"])
app.include_router(agents.router, prefix="/api/agents", tags=["agents"])
app.include_router(tools.router, prefix="/api/tools", tags=["tools"])
app.include_router(requests.router, prefix="/api/requests", tags=["requests"])
app.include_router(policies.router, prefix="/api/policies", tags=["policies"])
app.include_router(approvals.router, prefix="/api/approvals", tags=["approvals"])
app.include_router(simulation.router, prefix="/api", tags=["simulation"])
app.include_router(reports.router, prefix="/api/reports", tags=["reports"])


@app.get("/")
def root() -> FileResponse:
    return FileResponse(STATIC_DIR / "dashboard.html")


@app.get("/dashboard")
def dashboard_page() -> FileResponse:
    return FileResponse(STATIC_DIR / "dashboard.html")
