from pydantic import BaseModel


class DashboardMetric(BaseModel):
    label: str
    value: int | float | str
    detail: str | None = None


class DashboardSummary(BaseModel):
    metrics: dict[str, int | float]
    decision_breakdown: dict[str, int]
    risk_band_breakdown: dict[str, int]
    top_risky_agents: list[dict]
    top_sensitive_tools: list[dict]
    recent_blocked_requests: list[dict]
    common_detected_signals: list[dict]
    latest_audit_events: list[dict]
