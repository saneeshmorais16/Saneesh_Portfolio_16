from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


class ApprovalDecision(BaseModel):
    approver: str = "Security Director"
    decision_reason: str


class ApprovalRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    request_id: int
    status: Literal["pending", "approved", "rejected"]
    approver: str | None = None
    decision_reason: str | None = None
    decided_at: datetime | None = None
    created_at: datetime
