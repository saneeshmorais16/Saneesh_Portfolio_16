from pydantic import BaseModel


class DirectorReport(BaseModel):
    executive_summary: str
    key_risk_findings: list[str]
    ai_agent_activity_overview: str
    total_agent_activity: str
    top_risks: list[str]
    blocked_unsafe_actions: str
    blocked_attack_attempts: str
    governance_coverage: str
    sensitive_tool_usage: str
    most_exposed_tools_apis: str
    approval_bottlenecks: str
    estimated_cost_visibility: str
    business_value_metrics: dict
    policy_recommendations: list[str]
    recommended_next_policies: list[str]
    business_value_summary: str
    thirty_day_improvement_plan: list[str]
    next_actions_for_leadership: list[str]
