from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class SimulationRequest(BaseModel):
    agent_id: int
    tool_id: int
    user_prompt: str
    action_summary: str
    request_method: Literal["GET", "POST", "PATCH", "DELETE"]
    endpoint: str
    data_accessed: str
    environment: Literal["sandbox", "staging", "production"]


class AutoAgentRunRequest(BaseModel):
    user_input: str = Field(..., min_length=3, max_length=2000)


class APIRequestRead(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    agent_id: int
    tool_id: int
    user_prompt: str
    action_summary: str
    data_accessed: str
    request_method: str
    endpoint: str
    environment: str
    risk_score: int
    risk_band: str
    policy_decision: str
    reason: str
    detected_signals: list[str]
    estimated_cost: float
    latency_ms: int
    execution_status: str
    execution_summary: str
    simulated_output: str
    business_impact: str
    evidence_created: str
    next_step: str
    executed_at: datetime | None = None
    timestamp: datetime
