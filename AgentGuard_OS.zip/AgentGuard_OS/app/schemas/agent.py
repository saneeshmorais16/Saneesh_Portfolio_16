from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


class AgentBase(BaseModel):
    name: str
    owner_team: str
    purpose: str
    environment: Literal["sandbox", "staging", "production"] = "sandbox"
    trust_level: Literal["low", "medium", "high"] = "medium"
    status: Literal["active", "blocked", "under_review"] = "active"


class AgentCreate(AgentBase):
    pass


class AgentRead(AgentBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
