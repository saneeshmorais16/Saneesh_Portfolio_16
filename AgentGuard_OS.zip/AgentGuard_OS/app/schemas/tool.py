from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


class ToolBase(BaseModel):
    name: str
    category: Literal[
        "CRM",
        "payments",
        "customer_support",
        "analytics",
        "internal_docs",
        "email",
        "finance",
        "admin",
    ]
    protocol: Literal["REST", "event", "MCP-style tool", "A2A"]
    sensitivity: Literal["low", "medium", "high", "critical"] = "medium"
    owner_team: str
    status: str = "active"


class ToolCreate(ToolBase):
    pass


class ToolRead(ToolBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
