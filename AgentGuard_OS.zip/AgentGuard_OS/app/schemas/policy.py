from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


class PolicyBase(BaseModel):
    name: str
    description: str
    applies_to_tool_category: str = "all"
    max_sensitivity_allowed: Literal["low", "medium", "high", "critical"] = "high"
    requires_human_approval: bool = False
    blocked_keywords: str = ""
    active: bool = True


class PolicyCreate(PolicyBase):
    pass


class PolicyRead(PolicyBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    created_at: datetime
