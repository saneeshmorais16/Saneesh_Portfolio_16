from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(Integer, ForeignKey("api_requests.id"), nullable=False, index=True)
    event_type = Column(String(80), nullable=False)
    message = Column(Text, nullable=False)
    actor = Column(String(120), nullable=False, default="system")
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    request = relationship("APIRequest", back_populates="audit_events")
