from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, String
from sqlalchemy.orm import relationship

from app.core.database import Base


class Tool(Base):
    __tablename__ = "tools"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(160), nullable=False, index=True)
    category = Column(String(80), nullable=False, index=True)
    protocol = Column(String(80), nullable=False)
    sensitivity = Column(String(40), nullable=False, default="medium")
    owner_team = Column(String(120), nullable=False)
    status = Column(String(40), nullable=False, default="active")
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    requests = relationship("APIRequest", back_populates="tool")
