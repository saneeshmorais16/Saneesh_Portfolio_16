from datetime import datetime

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class APIRequest(Base):
    __tablename__ = "api_requests"

    id = Column(Integer, primary_key=True, index=True)
    agent_id = Column(Integer, ForeignKey("agents.id"), nullable=False, index=True)
    tool_id = Column(Integer, ForeignKey("tools.id"), nullable=False, index=True)
    user_prompt = Column(Text, nullable=False)
    action_summary = Column(Text, nullable=False)
    data_accessed = Column(Text, nullable=False)
    request_method = Column(String(20), nullable=False)
    endpoint = Column(String(240), nullable=False)
    environment = Column(String(40), nullable=False, default="sandbox")
    risk_score = Column(Integer, nullable=False)
    risk_band = Column(String(40), nullable=False)
    policy_decision = Column(String(40), nullable=False)
    reason = Column(Text, nullable=False)
    detected_signals = Column(Text, nullable=False, default="[]")
    estimated_cost = Column(Float, nullable=False, default=0.0)
    latency_ms = Column(Integer, nullable=False, default=0)
    execution_status = Column(String(60), nullable=False, default="not_started")
    execution_summary = Column(Text, nullable=False, default="")
    simulated_output = Column(Text, nullable=False, default="")
    business_impact = Column(Text, nullable=False, default="")
    evidence_created = Column(Text, nullable=False, default="")
    next_step = Column(Text, nullable=False, default="")
    executed_at = Column(DateTime, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    agent = relationship("Agent", back_populates="requests")
    tool = relationship("Tool", back_populates="requests")
    audit_events = relationship("AuditEvent", back_populates="request", cascade="all, delete-orphan")
    approval = relationship("Approval", back_populates="request", uselist=False, cascade="all, delete-orphan")
