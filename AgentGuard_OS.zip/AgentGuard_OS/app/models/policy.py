from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Integer, String, Text

from app.core.database import Base


class Policy(Base):
    __tablename__ = "policies"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(180), nullable=False, index=True)
    description = Column(Text, nullable=False)
    applies_to_tool_category = Column(String(80), nullable=False, default="all")
    max_sensitivity_allowed = Column(String(40), nullable=False, default="high")
    requires_human_approval = Column(Boolean, nullable=False, default=False)
    blocked_keywords = Column(Text, nullable=False, default="")
    active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
