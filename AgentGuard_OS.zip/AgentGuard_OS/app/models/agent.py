from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, String, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class Agent(Base):
    __tablename__ = "agents"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(160), nullable=False, index=True)
    owner_team = Column(String(120), nullable=False)
    purpose = Column(Text, nullable=False)
    environment = Column(String(40), nullable=False, default="sandbox")
    trust_level = Column(String(40), nullable=False, default="medium")
    status = Column(String(40), nullable=False, default="active")
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    requests = relationship("APIRequest", back_populates="agent")
