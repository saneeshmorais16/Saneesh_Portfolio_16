from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.tool import Tool
from app.routes.serializers import tool_to_dict
from app.schemas.tool import ToolCreate


router = APIRouter()


@router.get("")
def list_tools(db: Session = Depends(get_db)):
    tools = db.query(Tool).order_by(Tool.category.asc(), Tool.name.asc()).all()
    return [tool_to_dict(tool) for tool in tools]


@router.post("", status_code=status.HTTP_201_CREATED)
def create_tool(payload: ToolCreate, db: Session = Depends(get_db)):
    tool = Tool(**payload.model_dump())
    db.add(tool)
    db.commit()
    db.refresh(tool)
    return tool_to_dict(tool)
