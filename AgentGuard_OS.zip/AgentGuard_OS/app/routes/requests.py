from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload

from app.core.database import get_db
from app.models.api_request import APIRequest
from app.routes.serializers import audit_event_to_dict, request_to_dict
from app.services.sandbox_executor import run_sandbox_execution


router = APIRouter()


@router.get("")
def list_requests(limit: int = 100, db: Session = Depends(get_db)):
    requests = (
        db.query(APIRequest)
        .options(joinedload(APIRequest.agent), joinedload(APIRequest.tool), joinedload(APIRequest.approval))
        .order_by(APIRequest.timestamp.desc())
        .limit(min(limit, 300))
        .all()
    )
    return [request_to_dict(request) for request in requests]


@router.get("/{request_id}")
def get_request(request_id: int, db: Session = Depends(get_db)):
    request = (
        db.query(APIRequest)
        .options(joinedload(APIRequest.agent), joinedload(APIRequest.tool), joinedload(APIRequest.approval))
        .filter(APIRequest.id == request_id)
        .first()
    )
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    return request_to_dict(request)


@router.post("/{request_id}/execute-approved")
def execute_approved_request(request_id: int, db: Session = Depends(get_db)):
    request = (
        db.query(APIRequest)
        .options(
            joinedload(APIRequest.agent),
            joinedload(APIRequest.tool),
            joinedload(APIRequest.approval),
            joinedload(APIRequest.audit_events),
        )
        .filter(APIRequest.id == request_id)
        .first()
    )
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")
    if not request.approval:
        raise HTTPException(status_code=409, detail="This request does not have a human approval record")
    if request.approval.status == "rejected":
        raise HTTPException(status_code=409, detail="Rejected requests cannot be executed")
    if request.approval.status != "approved":
        raise HTTPException(status_code=409, detail="Only approved requests can be executed")
    if request.policy_decision == "blocked" or request.execution_status in {"blocked", "rejected"}:
        raise HTTPException(status_code=409, detail="Blocked or rejected requests cannot be executed")
    if request.execution_status == "executed":
        raise HTTPException(status_code=409, detail="This request has already been executed in the sandbox")

    run_sandbox_execution(
        db,
        request,
        request.agent,
        request.tool,
        request.policy_decision,
        request.risk_score,
        request.user_prompt,
        approved_execution=True,
    )
    db.commit()
    db.refresh(request)
    return request_to_dict(request)


@router.get("/{request_id}/lineage")
def get_request_lineage(request_id: int, db: Session = Depends(get_db)):
    request = (
        db.query(APIRequest)
        .options(
            joinedload(APIRequest.agent),
            joinedload(APIRequest.tool),
            joinedload(APIRequest.approval),
            joinedload(APIRequest.audit_events),
        )
        .filter(APIRequest.id == request_id)
        .first()
    )
    if not request:
        raise HTTPException(status_code=404, detail="Request not found")

    signals = request_to_dict(request)["detected_signals"]
    sorted_events = sorted(request.audit_events, key=lambda item: item.timestamp)
    intent_event = next((event for event in sorted_events if event.event_type == "intent_routed"), None)
    approval_detail = (
        f"Approval status: {request.approval.status}" if request.approval else "No human approval record required"
    )
    execution_status = request.execution_status or "not_started"
    if execution_status == "executed":
        final_outcome = "Executed safely in the local sandbox. No external systems were contacted."
    elif execution_status == "blocked":
        final_outcome = "Blocked before sandbox execution"
    elif execution_status == "awaiting_approval":
        final_outcome = "Waiting for human approval before sandbox execution"
    elif execution_status == "approved_pending_execution":
        final_outcome = "Approved and waiting for explicit sandbox execution"
    elif execution_status == "rejected":
        final_outcome = "Rejected by human reviewer; sandbox execution is not allowed"
    elif request.policy_decision == "blocked":
        final_outcome = "Blocked before execution"
    elif request.policy_decision == "approval_required":
        final_outcome = "Waiting for human approval"
    else:
        final_outcome = "Allowed by runtime controls"

    steps = [
        {
            "key": "prompt",
            "title": "User Input" if intent_event else "Human Prompt",
            "status": "captured",
            "detail": request.user_prompt,
            "meta": request.environment,
        },
    ]
    if intent_event:
        steps.append(
            {
                "key": "intent_router",
                "title": "Intent Router",
                "status": "routed",
                "detail": intent_event.message,
                "meta": "Automatic agent and tool/API selection from natural language input",
            }
        )

    steps.extend(
        [
            {
                "key": "agent",
                "title": "Agent Identity",
                "status": request.agent.status,
                "detail": request.agent.name,
                "meta": f"{request.agent.owner_team} / {request.agent.trust_level} trust",
            },
        {
            "key": "tool",
            "title": "Tool/API Access",
            "status": request.tool.sensitivity,
            "detail": request.tool.name,
            "meta": f"{request.request_method} {request.endpoint}",
        },
        {
            "key": "data",
            "title": "Data Accessed",
            "status": request.tool.sensitivity,
            "detail": request.data_accessed,
            "meta": "Data context included in risk and policy evaluation",
        },
        {
            "key": "detector",
            "title": "Prompt Attack Detector",
            "status": "signal" if signals else "clear",
            "detail": ", ".join(signals) if signals else "No risky prompt signals detected",
            "meta": "Rule-based prompt and control-signal scan",
        },
        {
            "key": "policy",
            "title": "Policy Check",
            "status": request.policy_decision,
            "detail": request.reason,
            "meta": "Runtime policy enforcement",
        },
        {
            "key": "risk",
            "title": "Risk Score",
            "status": request.risk_band,
            "detail": f"{request.risk_score}/100",
            "meta": f"Estimated cost ${request.estimated_cost:.4f}, latency {request.latency_ms}ms",
        },
        {
            "key": "approval",
            "title": "Human Approval",
            "status": request.approval.status if request.approval else "not_required",
            "detail": approval_detail,
            "meta": request.approval.decision_reason if request.approval else "Automated decision path",
        },
        {
            "key": "sandbox",
            "title": "Sandbox Execution",
            "status": execution_status,
            "detail": request.execution_summary or "Sandbox execution has not started.",
            "meta": request.simulated_output or "No sandbox output has been produced.",
        },
        {
            "key": "evidence",
            "title": "Evidence Created",
            "status": "recorded" if request.evidence_created else "not_started",
            "detail": request.evidence_created or "No execution evidence has been created yet.",
            "meta": request.business_impact or request.next_step or "Business impact will appear after sandbox control state is set.",
        },
        {
            "key": "outcome",
            "title": "Final Outcome",
            "status": execution_status if execution_status != "not_started" else request.policy_decision,
            "detail": final_outcome,
            "meta": request.next_step or "Business outcome recorded for governance review",
        },
        {
            "key": "audit",
            "title": "Audit Trail",
            "status": "recorded",
            "detail": f"{len(request.audit_events)} event(s) recorded",
            "meta": "Immutable control narrative for review",
        },
        ]
    )

    return {
        "request": request_to_dict(request),
        "final_outcome": final_outcome,
        "steps": steps,
        "audit_events": [audit_event_to_dict(event) for event in sorted_events],
    }
