from types import SimpleNamespace

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.agent import Agent
from app.models.audit_event import AuditEvent
from app.models.tool import Tool
from app.routes.serializers import approval_to_dict, audit_event_to_dict, request_to_dict
from app.schemas.api_request import AutoAgentRunRequest, SimulationRequest
from app.services.intent_router import classify_intent
from app.services.simulation_engine import simulate_agent_request


router = APIRouter()


@router.post("/simulate-request")
def simulate_request(payload: SimulationRequest, db: Session = Depends(get_db)):
    result = simulate_agent_request(db, payload)
    return {
        "request": request_to_dict(result["request"]),
        "agent": {
            "id": result["agent"].id,
            "name": result["agent"].name,
            "trust_level": result["agent"].trust_level,
            "owner_team": result["agent"].owner_team,
        },
        "tool": {
            "id": result["tool"].id,
            "name": result["tool"].name,
            "category": result["tool"].category,
            "sensitivity": result["tool"].sensitivity,
        },
        "detector": result["detector"],
        "risk": result["risk"],
        "policy": result["policy"],
        "execution": result["execution"],
        "approval": approval_to_dict(result["approval"]) if result["approval"] else None,
        "lineage_url": f"/api/requests/{result['request'].id}/lineage",
    }


@router.post("/auto-agent-run")
def auto_agent_run(payload: AutoAgentRunRequest, db: Session = Depends(get_db)):
    routing = classify_intent(payload.user_input)
    agent = db.query(Agent).filter(Agent.name == routing["agent_name"]).first()
    tool = db.query(Tool).filter(Tool.name == routing["tool_name"]).first()

    if not agent:
        raise HTTPException(status_code=404, detail=f"Inferred agent not found: {routing['agent_name']}")
    if not tool:
        raise HTTPException(status_code=404, detail=f"Inferred tool/API not found: {routing['tool_name']}")

    simulation_payload = SimpleNamespace(
        agent_id=agent.id,
        tool_id=tool.id,
        user_prompt=payload.user_input,
        action_summary=routing["action_summary"],
        request_method=routing["request_method"],
        endpoint=routing["endpoint"],
        data_accessed=routing["data_accessed"],
        environment=routing["environment"],
    )
    result = simulate_agent_request(
        db,
        simulation_payload,
        auto_context={
            "user_input": payload.user_input,
            "intent_category": routing["intent_category"],
            "confidence_score": routing["confidence_score"],
        },
    )

    request = result["request"]
    audit_events = (
        db.query(AuditEvent)
        .filter(AuditEvent.request_id == request.id)
        .order_by(AuditEvent.timestamp.asc())
        .all()
    )
    approval_required = result["policy"]["decision"] == "approval_required"
    director_summary_line = (
        f"AgentGuard OS routed this input to {agent.name} and {tool.name}, assigned {result['risk']['band']} risk, "
        f"returned a {result['policy']['decision']} decision, and set sandbox execution to {request.execution_status}."
    )

    return {
        "user_input": payload.user_input,
        "inferred_agent": {
            "id": agent.id,
            "name": agent.name,
            "owner_team": agent.owner_team,
            "trust_level": agent.trust_level,
        },
        "inferred_tool": {
            "id": tool.id,
            "name": tool.name,
            "category": tool.category,
            "sensitivity": tool.sensitivity,
            "protocol": tool.protocol,
        },
        "inferred_method": routing["request_method"],
        "inferred_endpoint": routing["endpoint"],
        "inferred_data_accessed": routing["data_accessed"],
        "inferred_environment": routing["environment"],
        "intent_category": routing["intent_category"],
        "confidence_score": routing["confidence_score"],
        "detected_signals": result["detector"]["matched_signals"],
        "risk_score": result["risk"]["score"],
        "risk_band": result["risk"]["band"],
        "policy_decision": result["policy"]["decision"],
        "reason": result["policy"]["reason"],
        "execution_status": request.execution_status,
        "execution_summary": request.execution_summary,
        "simulated_output": request.simulated_output,
        "business_impact": request.business_impact,
        "evidence_created": request.evidence_created,
        "next_step": request.next_step,
        "executed_at": request.executed_at.isoformat() if request.executed_at else None,
        "execution": result["execution"],
        "approval_required": approval_required,
        "approval": approval_to_dict(result["approval"]) if result["approval"] else None,
        "request_id": request.id,
        "request": request_to_dict(request),
        "audit_events": [audit_event_to_dict(event) for event in audit_events],
        "lineage_url_or_id": f"/api/requests/{request.id}/lineage",
        "director_summary_line": director_summary_line,
    }
