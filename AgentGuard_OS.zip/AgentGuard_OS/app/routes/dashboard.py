import json
from collections import Counter, defaultdict

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session, joinedload

from app.core.database import get_db
from app.core.security import governance_status
from app.models.agent import Agent
from app.models.api_request import APIRequest
from app.models.approval import Approval
from app.models.audit_event import AuditEvent
from app.models.tool import Tool
from app.routes.serializers import audit_event_to_dict, request_to_dict, tool_to_dict
from app.services.business_metrics import calculate_business_metrics
from seed import seed_database


router = APIRouter()


def _count_by(db: Session, model_field, keys: list[str]) -> dict[str, int]:
    counts = {key: 0 for key in keys}
    rows = db.query(model_field, func.count(APIRequest.id)).group_by(model_field).all()
    for key, count in rows:
        counts[key or "unknown"] = count
    return counts


@router.get("/dashboard/summary")
def dashboard_summary(db: Session = Depends(get_db)):
    total_requests = db.query(APIRequest).count()
    allowed_requests = db.query(APIRequest).filter(APIRequest.policy_decision == "allowed").count()
    blocked_requests = db.query(APIRequest).filter(APIRequest.policy_decision == "blocked").count()
    approval_required = db.query(APIRequest).filter(APIRequest.policy_decision == "approval_required").count()
    pending_approvals = db.query(Approval).filter(Approval.status == "pending").count()
    high_risk = db.query(APIRequest).filter(APIRequest.risk_band == "high").count()
    critical_risk = db.query(APIRequest).filter(APIRequest.risk_band == "critical").count()
    total_cost = db.query(func.sum(APIRequest.estimated_cost)).scalar() or 0
    average_risk = db.query(func.avg(APIRequest.risk_score)).scalar() or 0

    recent_blocked = (
        db.query(APIRequest)
        .options(joinedload(APIRequest.agent), joinedload(APIRequest.tool), joinedload(APIRequest.approval))
        .filter((APIRequest.policy_decision == "blocked") | (APIRequest.risk_band.in_(["high", "critical"])))
        .order_by(APIRequest.timestamp.desc())
        .limit(8)
        .all()
    )

    agent_scores = defaultdict(lambda: {"request_count": 0, "risk_total": 0, "blocked": 0, "critical": 0})
    requests = db.query(APIRequest).options(joinedload(APIRequest.agent), joinedload(APIRequest.tool)).all()
    signal_counter = Counter()
    tool_stats = defaultdict(lambda: {"request_count": 0, "max_risk": 0, "risk_total": 0, "tool": None})

    for request in requests:
        if request.agent:
            row = agent_scores[request.agent.name]
            row["request_count"] += 1
            row["risk_total"] += request.risk_score
            row["blocked"] += 1 if request.policy_decision == "blocked" else 0
            row["critical"] += 1 if request.risk_band == "critical" else 0
        if request.tool:
            tool_row = tool_stats[request.tool.id]
            tool_row["request_count"] += 1
            tool_row["risk_total"] += request.risk_score
            tool_row["max_risk"] = max(tool_row["max_risk"], request.risk_score)
            tool_row["tool"] = request.tool
        try:
            signal_counter.update(json.loads(request.detected_signals or "[]"))
        except json.JSONDecodeError:
            pass

    top_risky_agents = [
        {
            "agent_name": agent_name,
            "request_count": stats["request_count"],
            "average_risk": round(stats["risk_total"] / stats["request_count"], 1),
            "blocked": stats["blocked"],
            "critical": stats["critical"],
        }
        for agent_name, stats in agent_scores.items()
        if stats["request_count"]
    ]
    top_risky_agents.sort(key=lambda item: (item["average_risk"], item["blocked"], item["critical"]), reverse=True)

    top_sensitive_tools = []
    for stats in tool_stats.values():
        tool = stats["tool"]
        if not tool:
            continue
        top_sensitive_tools.append(
            {
                **tool_to_dict(tool),
                "request_count": stats["request_count"],
                "average_risk": round(stats["risk_total"] / stats["request_count"], 1),
                "max_risk": stats["max_risk"],
            }
        )
    top_sensitive_tools.sort(
        key=lambda item: (
            {"critical": 4, "high": 3, "medium": 2, "low": 1}.get(item["sensitivity"], 0),
            item["max_risk"],
        ),
        reverse=True,
    )

    latest_audit_events = (
        db.query(AuditEvent)
        .order_by(AuditEvent.timestamp.desc())
        .limit(10)
        .all()
    )
    business_metrics = calculate_business_metrics(db)
    most_common_signal = signal_counter.most_common(1)[0][0] if signal_counter else "None detected"
    highest_risk_agent = top_risky_agents[0]["agent_name"] if top_risky_agents else "No agent activity"
    most_sensitive_tool = top_sensitive_tools[0]["name"] if top_sensitive_tools else "No tool activity"

    return {
        "system_status": governance_status(),
        "metrics": {
            "total_agent_requests": total_requests,
            "allowed_requests": allowed_requests,
            "blocked_requests": blocked_requests,
            "approval_required_requests": approval_required,
            "pending_approvals": pending_approvals,
            "high_risk_actions": high_risk,
            "critical_risk_actions": critical_risk,
            "estimated_ai_api_cost": round(total_cost, 4),
            "average_risk_score": round(float(average_risk), 1),
            "active_agents": db.query(Agent).filter(Agent.status == "active").count(),
            "governed_tools": db.query(Tool).count(),
            "most_common_intent_category": business_metrics["most_common_intent_category"],
            "most_common_detected_signal": most_common_signal,
            "highest_risk_agent": highest_risk_agent,
            "most_sensitive_tool_api": most_sensitive_tool,
            "executed_sandbox_actions": business_metrics["executed_sandbox_actions"],
            "blocked_before_execution": business_metrics["blocked_before_execution"],
            "awaiting_approval_execution": business_metrics["awaiting_approval_execution"],
            "approved_pending_execution": business_metrics["approved_pending_execution"],
        },
        "decision_breakdown": _count_by(db, APIRequest.policy_decision, ["allowed", "blocked", "approval_required"]),
        "risk_band_breakdown": _count_by(db, APIRequest.risk_band, ["low", "medium", "high", "critical"]),
        "top_risky_agents": top_risky_agents[:6],
        "top_sensitive_tools": top_sensitive_tools[:6],
        "recent_blocked_requests": [request_to_dict(request, include_prompt=False) for request in recent_blocked],
        "common_detected_signals": [
            {"signal": signal, "count": count} for signal, count in signal_counter.most_common(8)
        ],
        "latest_audit_events": [audit_event_to_dict(event) for event in latest_audit_events],
        "business_value_metrics": business_metrics,
    }


@router.post("/seed")
def seed_endpoint(reset: bool = False, db: Session = Depends(get_db)):
    return seed_database(db, reset=reset)
