import json


def isoformat(value):
    return value.isoformat() if value else None


def parse_signals(value: str | None) -> list[str]:
    if not value:
        return []
    try:
        parsed = json.loads(value)
        return parsed if isinstance(parsed, list) else []
    except json.JSONDecodeError:
        return []


def agent_to_dict(agent) -> dict:
    return {
        "id": agent.id,
        "name": agent.name,
        "owner_team": agent.owner_team,
        "purpose": agent.purpose,
        "environment": agent.environment,
        "trust_level": agent.trust_level,
        "status": agent.status,
        "created_at": isoformat(agent.created_at),
    }


def tool_to_dict(tool) -> dict:
    return {
        "id": tool.id,
        "name": tool.name,
        "category": tool.category,
        "protocol": tool.protocol,
        "sensitivity": tool.sensitivity,
        "owner_team": tool.owner_team,
        "status": tool.status,
        "created_at": isoformat(tool.created_at),
    }


def request_to_dict(request, include_prompt: bool = True) -> dict:
    data = {
        "id": request.id,
        "agent_id": request.agent_id,
        "tool_id": request.tool_id,
        "agent_name": request.agent.name if request.agent else None,
        "tool_name": request.tool.name if request.tool else None,
        "tool_category": request.tool.category if request.tool else None,
        "tool_sensitivity": request.tool.sensitivity if request.tool else None,
        "action_summary": request.action_summary,
        "data_accessed": request.data_accessed,
        "request_method": request.request_method,
        "endpoint": request.endpoint,
        "environment": request.environment,
        "risk_score": request.risk_score,
        "risk_band": request.risk_band,
        "policy_decision": request.policy_decision,
        "reason": request.reason,
        "detected_signals": parse_signals(request.detected_signals),
        "estimated_cost": request.estimated_cost,
        "latency_ms": request.latency_ms,
        "execution_status": request.execution_status,
        "execution_summary": request.execution_summary,
        "simulated_output": request.simulated_output,
        "business_impact": request.business_impact,
        "evidence_created": request.evidence_created,
        "next_step": request.next_step,
        "executed_at": isoformat(request.executed_at),
        "timestamp": isoformat(request.timestamp),
        "approval_status": request.approval.status if request.approval else None,
    }
    if include_prompt:
        data["user_prompt"] = request.user_prompt
    return data


def policy_to_dict(policy) -> dict:
    return {
        "id": policy.id,
        "name": policy.name,
        "description": policy.description,
        "applies_to_tool_category": policy.applies_to_tool_category,
        "max_sensitivity_allowed": policy.max_sensitivity_allowed,
        "requires_human_approval": policy.requires_human_approval,
        "blocked_keywords": policy.blocked_keywords,
        "active": policy.active,
        "created_at": isoformat(policy.created_at),
    }


def audit_event_to_dict(event) -> dict:
    return {
        "id": event.id,
        "request_id": event.request_id,
        "event_type": event.event_type,
        "message": event.message,
        "actor": event.actor,
        "timestamp": isoformat(event.timestamp),
    }


def approval_to_dict(approval) -> dict:
    return {
        "id": approval.id,
        "request_id": approval.request_id,
        "status": approval.status,
        "approver": approval.approver,
        "decision_reason": approval.decision_reason,
        "decided_at": isoformat(approval.decided_at),
        "created_at": isoformat(approval.created_at),
        "request": request_to_dict(approval.request) if approval.request else None,
    }
