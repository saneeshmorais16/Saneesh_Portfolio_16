from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.agent import Agent
from app.routes.serializers import agent_to_dict
from app.schemas.agent import AgentCreate


router = APIRouter()


@router.get("")
def list_agents(db: Session = Depends(get_db)):
    agents = db.query(Agent).order_by(Agent.name.asc()).all()
    return [agent_to_dict(agent) for agent in agents]


@router.post("", status_code=status.HTTP_201_CREATED)
def create_agent(payload: AgentCreate, db: Session = Depends(get_db)):
    agent = Agent(**payload.model_dump())
    db.add(agent)
    db.commit()
    db.refresh(agent)
    return agent_to_dict(agent)
