from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.policy import Policy
from app.routes.serializers import policy_to_dict
from app.schemas.policy import PolicyCreate


router = APIRouter()


@router.get("")
def list_policies(db: Session = Depends(get_db)):
    policies = db.query(Policy).order_by(Policy.active.desc(), Policy.name.asc()).all()
    return [policy_to_dict(policy) for policy in policies]


@router.post("", status_code=status.HTTP_201_CREATED)
def create_policy(payload: PolicyCreate, db: Session = Depends(get_db)):
    policy = Policy(**payload.model_dump())
    db.add(policy)
    db.commit()
    db.refresh(policy)
    return policy_to_dict(policy)
