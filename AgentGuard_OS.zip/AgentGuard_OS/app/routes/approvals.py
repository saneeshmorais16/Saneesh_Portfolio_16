from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload

from app.core.database import get_db
from app.models.approval import Approval
from app.routes.serializers import approval_to_dict
from app.schemas.approval import ApprovalDecision
from app.services.audit_service import create_audit_event
from app.services.sandbox_executor import mark_approved_pending_execution, mark_rejected_execution


router = APIRouter()


@router.get("")
def list_approvals(db: Session = Depends(get_db)):
    approvals = (
        db.query(Approval)
        .options(joinedload(Approval.request))
        .order_by(Approval.status.asc(), Approval.created_at.desc())
        .all()
    )
    return [approval_to_dict(approval) for approval in approvals]


@router.post("/{approval_id}/approve")
def approve_request(approval_id: int, payload: ApprovalDecision, db: Session = Depends(get_db)):
    approval = db.query(Approval).filter(Approval.id == approval_id).first()
    if not approval:
        raise HTTPException(status_code=404, detail="Approval not found")
    if approval.status != "pending":
        raise HTTPException(status_code=409, detail="Only pending approvals can be approved")

    approval.status = "approved"
    approval.approver = payload.approver
    approval.decision_reason = payload.decision_reason
    approval.decided_at = datetime.utcnow()
    mark_approved_pending_execution(db, approval.request, payload.approver)

    create_audit_event(
        db,
        approval.request_id,
        "approval_approved",
        f"Approval approved by {payload.approver} with reason recorded: {payload.decision_reason}",
        actor=payload.approver,
    )
    create_audit_event(
        db,
        approval.request_id,
        "final_outcome",
        "Human approval granted. Sandbox execution is ready but still requires an explicit execution action.",
        actor="approval-service",
    )
    db.commit()
    db.refresh(approval)
    return approval_to_dict(approval)


@router.post("/{approval_id}/reject")
def reject_request(approval_id: int, payload: ApprovalDecision, db: Session = Depends(get_db)):
    approval = db.query(Approval).filter(Approval.id == approval_id).first()
    if not approval:
        raise HTTPException(status_code=404, detail="Approval not found")
    if approval.status != "pending":
        raise HTTPException(status_code=409, detail="Only pending approvals can be rejected")

    approval.status = "rejected"
    approval.approver = payload.approver
    approval.decision_reason = payload.decision_reason
    approval.decided_at = datetime.utcnow()
    mark_rejected_execution(db, approval.request, payload.approver)

    create_audit_event(
        db,
        approval.request_id,
        "approval_rejected",
        f"Approval rejected by {payload.approver} with reason recorded: {payload.decision_reason}",
        actor=payload.approver,
    )
    create_audit_event(
        db,
        approval.request_id,
        "final_outcome",
        "Human approval rejected. Agent action remains blocked from sandbox execution.",
        actor="approval-service",
    )
    db.commit()
    db.refresh(approval)
    return approval_to_dict(approval)
