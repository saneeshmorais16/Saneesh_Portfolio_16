from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.services.report_service import generate_director_summary, generate_presentation_mode


router = APIRouter()


@router.get("/director-summary")
def director_summary(db: Session = Depends(get_db)):
    return generate_director_summary(db)


@router.get("/presentation-mode")
def presentation_mode(db: Session = Depends(get_db)):
    return generate_presentation_mode(db)
