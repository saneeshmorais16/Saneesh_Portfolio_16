from datetime import datetime

from app.models.approval import Approval
from app.services.audit_service import create_audit_event


def _tool_output(request, agent, tool) -> dict:
    text = f"{request.user_prompt} {request.action_summary} {request.data_accessed}".lower()

    if tool.name == "Customer Profile API":
        return {
            "summary": "Sandbox customer profile lookup completed with masked data only.",
            "output": "Customer C-1042 | Name: A**** R**** | Email: a***@example.test | Tier: Enterprise | Open cases: 1",
            "impact": "Support team can review customer context without exposing raw personal data.",
            "evidence": "Masked customer profile snapshot and CRM access decision recorded.",
            "next": "Use masked profile context only; request approval for bulk export or sensitive fields.",
        }
    if tool.name == "Refund API":
        if "status" in text and request.request_method == "GET":
            return {
                "summary": "Sandbox refund status lookup completed.",
                "output": "Refund RF-8821 | Status: pending review | Amount: GBP 950 | Customer: C-2221 | SLA: 2 business days",
                "impact": "Operations can answer the customer without initiating payment movement.",
                "evidence": "Refund status evidence packet created with masked customer and invoice references.",
                "next": "Share status update; do not issue funds without approval.",
            }
        return {
            "summary": "Sandbox refund action prepared but not sent to a payment processor.",
            "output": "Draft refund instruction RF-SANDBOX-950 | Amount: GBP 950 | Status: held for approval | Processor call: not executed",
            "impact": "High-value refund risk is contained before money movement.",
            "evidence": "Refund approval dossier created with invoice, amount, customer, and risk rationale.",
            "next": "Route to Security/Finance approval before sandbox execution can complete.",
        }
    if tool.name == "Payment Status API":
        return {
            "summary": "Sandbox payment status lookup completed.",
            "output": "Transaction TX-SBX-2042 | Amount: GBP 950 | Status: settled | Payment method: masked card | Settlement: T+1",
            "impact": "Finance can reconcile payment state without touching live payment systems.",
            "evidence": "Payment status lookup receipt recorded in audit trail.",
            "next": "Use status evidence for reconciliation or customer response.",
        }
    if tool.name == "Internal Docs Search":
        return {
            "summary": "Sandbox internal documentation search completed.",
            "output": "1. API Gateway onboarding requires owner approval. 2. Refund exceptions require Finance sign-off. 3. Agent tool access must be logged.",
            "impact": "Team receives approved policy context without accessing restricted systems.",
            "evidence": "Three internal policy snippets captured with source category metadata.",
            "next": "Use approved policy snippets for guidance; escalate if live system changes are needed.",
        }
    if tool.name == "Email Sender Tool":
        return {
            "summary": "Sandbox email draft generated. No email was sent.",
            "output": "Draft: 'We are sorry for the delayed delivery. Your case is being reviewed and we will update you within 24 hours.'",
            "impact": "Customer communication can be reviewed safely before delivery.",
            "evidence": "Email draft preview and recipient masking evidence recorded.",
            "next": "Review and approve content before any real messaging integration.",
        }
    if tool.name == "Revenue Analytics API":
        return {
            "summary": "Sandbox KPI summary generated.",
            "output": "Weekly renewal conversion: 42%; refund volume: +8%; enterprise retention: 96%; flagged anomalies: 2.",
            "impact": "Leadership gets analytics insight without exposing raw customer records.",
            "evidence": "Aggregated KPI evidence summary recorded.",
            "next": "Use aggregate insight for reporting; request data team review for anomalies.",
        }
    if tool.name == "Support Ticket API":
        return {
            "summary": "Sandbox support ticket lookup completed.",
            "output": "Ticket ST-1042 | Status: open | Priority: high | Suggested response: acknowledge delay and offer update window.",
            "impact": "Support can triage safely without modifying customer records.",
            "evidence": "Ticket status and suggested response evidence recorded.",
            "next": "Use suggested response or route to support owner.",
        }
    if tool.name == "Admin User Management API":
        return {
            "summary": "Sandbox admin action staged only. No real user was changed or deleted.",
            "output": "Admin action plan: DELETE inactive-admin-sbx | Status: staged | Live directory call: not executed",
            "impact": "Privileged access risk is controlled before identity changes occur.",
            "evidence": "Admin change evidence packet created with role, target, reason, and approval requirement.",
            "next": "Require human approval and change-ticket evidence before execution.",
        }
    if tool.name == "Finance Ledger API":
        return {
            "summary": "Sandbox finance reconciliation summary generated.",
            "output": "Ledger mismatch: GL-SBX-2039 | Difference: GBP 950 | Likely cause: refund timing offset | Recommended action: finance review.",
            "impact": "Finance can investigate without posting ledger changes.",
            "evidence": "Ledger reconciliation evidence packet recorded.",
            "next": "Route ledger update through Finance approval before posting changes.",
        }

    return {
        "summary": "Sandbox tool action simulated.",
        "output": "Generic sandbox output generated. No external system was contacted.",
        "impact": "Workflow remains contained inside local demonstration data.",
        "evidence": "Generic sandbox evidence record created.",
        "next": "Review governance decision before real integration.",
    }


def _apply_result(request, result: dict) -> dict:
    request.execution_status = result["execution_status"]
    request.execution_summary = result["execution_summary"]
    request.simulated_output = result["simulated_output"]
    request.business_impact = result["business_impact"]
    request.evidence_created = result["evidence_created"]
    request.next_step = result["next_step"]
    request.executed_at = result.get("executed_at")
    return result


def run_sandbox_execution(db, request, agent, tool, policy_decision: str, risk_score: int, user_input: str, approved_execution: bool = False) -> dict:
    if policy_decision == "blocked":
        result = {
            "execution_status": "blocked",
            "execution_summary": "Sandbox execution prevented by governance policy.",
            "simulated_output": "No sandbox tool output generated because the action was blocked before execution.",
            "business_impact": "Unsafe or policy-violating action was stopped before it could affect business systems.",
            "evidence_created": "Blocked execution evidence recorded with prompt, risk, policy decision, and tool context.",
            "next_step": "Review the audit trail and tune policy if this was expected business activity.",
            "executed_at": None,
        }
        _apply_result(request, result)
        create_audit_event(db, request.id, "sandbox_execution_prevented", "Sandbox execution was prevented because the request was blocked before execution.", actor="sandbox-executor")
        return result

    if policy_decision == "approval_required" and not approved_execution:
        existing_approval = db.query(Approval).filter(Approval.request_id == request.id).first()
        if not existing_approval:
            db.add(Approval(request_id=request.id, status="pending"))
            db.flush()
        result = {
            "execution_status": "awaiting_approval",
            "execution_summary": "Sandbox execution paused pending human approval.",
            "simulated_output": "No sandbox tool output generated yet. The action is waiting in the approval queue.",
            "business_impact": "Sensitive action is contained until a human approves or rejects the request.",
            "evidence_created": "Approval evidence packet created with risk score, tool sensitivity, and policy rationale.",
            "next_step": "Review this request in the Approval Queue.",
            "executed_at": None,
        }
        _apply_result(request, result)
        create_audit_event(db, request.id, "sandbox_execution_paused", "Sandbox execution paused pending human approval.", actor="sandbox-executor")
        return result

    output = _tool_output(request, agent, tool)
    result = {
        "execution_status": "executed",
        "execution_summary": output["summary"],
        "simulated_output": output["output"],
        "business_impact": output["impact"],
        "evidence_created": output["evidence"],
        "next_step": output["next"],
        "executed_at": datetime.utcnow(),
    }
    _apply_result(request, result)
    create_audit_event(db, request.id, "sandbox_execution_completed", f"Sandbox execution completed for {tool.name}. No external systems were contacted.", actor="sandbox-executor")
    return result


def mark_approved_pending_execution(db, request, approver: str) -> dict:
    result = {
        "execution_status": "approved_pending_execution",
        "execution_summary": "Human approval granted. Sandbox execution is ready but has not run yet.",
        "simulated_output": "No sandbox output generated after approval until Execute Approved Sandbox Action is selected.",
        "business_impact": "Approval risk is controlled; execution remains explicit and auditable.",
        "evidence_created": "Approval decision evidence recorded with approver and reason.",
        "next_step": "Execute Approved Sandbox Action from the Approval Queue.",
        "executed_at": None,
    }
    _apply_result(request, result)
    create_audit_event(db, request.id, "sandbox_execution_ready", f"Request approved by {approver}; sandbox execution is ready and awaiting explicit execution.", actor="sandbox-executor")
    return result


def mark_rejected_execution(db, request, approver: str) -> dict:
    result = {
        "execution_status": "rejected",
        "execution_summary": "Human approval rejected. Sandbox execution is not allowed.",
        "simulated_output": "No sandbox output generated because the approval was rejected.",
        "business_impact": "Sensitive action remains contained after human review.",
        "evidence_created": "Rejection evidence recorded with reviewer and reason.",
        "next_step": "Review the rejection rationale and submit a new request if needed.",
        "executed_at": None,
    }
    _apply_result(request, result)
    create_audit_event(db, request.id, "sandbox_execution_rejected", f"Sandbox execution rejected by {approver}; no execution allowed.", actor="sandbox-executor")
    return result
