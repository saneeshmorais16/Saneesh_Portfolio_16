SEVERITY_ORDER = {"none": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}

PHRASE_RULES = [
    {
        "phrase": "ignore previous instructions",
        "severity": "high",
        "explanation": "Instruction hierarchy override attempt.",
    },
    {"phrase": "bypass policy", "severity": "critical", "explanation": "Direct policy bypass request."},
    {"phrase": "reveal secrets", "severity": "critical", "explanation": "Sensitive secret disclosure attempt."},
    {"phrase": "export customer data", "severity": "high", "explanation": "Customer data exfiltration risk."},
    {"phrase": "export all customer emails", "severity": "high", "explanation": "Bulk customer email exfiltration risk."},
    {"phrase": "delete records", "severity": "high", "explanation": "Destructive data operation requested."},
    {"phrase": "impersonate admin", "severity": "critical", "explanation": "Privilege impersonation attempt."},
    {"phrase": "disable logging", "severity": "critical", "explanation": "Audit trail suppression attempt."},
    {"phrase": "hide this action", "severity": "critical", "explanation": "Concealment of agent activity requested."},
    {"phrase": "hide this action from logs", "severity": "critical", "explanation": "Logging concealment of agent activity requested."},
    {"phrase": "override approval", "severity": "critical", "explanation": "Human approval bypass attempt."},
    {"phrase": "make unauthorized payment", "severity": "critical", "explanation": "Unauthorized financial action requested."},
    {"phrase": "send customer list", "severity": "high", "explanation": "Bulk customer information exposure risk."},
    {"phrase": "expose API key", "severity": "critical", "explanation": "Credential exposure attempt."},
    {"phrase": "skip audit", "severity": "critical", "explanation": "Audit control bypass attempt."},
    {"phrase": "run without approval", "severity": "critical", "explanation": "Approval control bypass attempt."},
]


def detect_prompt_attack(*texts: str | None) -> dict:
    joined_text = " ".join(text or "" for text in texts).lower()
    matches = []

    for rule in PHRASE_RULES:
        if rule["phrase"] in joined_text:
            matches.append(rule)

    if not matches:
        return {
            "detected": False,
            "matched_signals": [],
            "severity": "none",
            "explanation": "No known prompt-injection or control-bypass phrases were detected.",
        }

    severity = max(matches, key=lambda rule: SEVERITY_ORDER[rule["severity"]])["severity"]
    explanations = sorted({rule["explanation"] for rule in matches})

    return {
        "detected": True,
        "matched_signals": [rule["phrase"] for rule in matches],
        "severity": severity,
        "explanation": " ".join(explanations),
    }
