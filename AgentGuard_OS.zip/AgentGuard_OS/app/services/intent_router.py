import re


def _customer_token(text: str) -> str:
    match = re.search(r"\bC-\d+\b", text, flags=re.IGNORECASE)
    return match.group(0).upper() if match else "inferred-customer"


def _refund_amount(text: str) -> str | None:
    match = re.search(r"(?:£|\$)?\s?(\d{3,7})(?:\.\d{2})?", text)
    return match.group(1) if match else None


def _internal_docs_route(confidence: float = 0.92) -> dict:
    return {
        "agent_name": "Internal Knowledge Agent",
        "tool_name": "Internal Docs Search",
        "request_method": "GET",
        "endpoint": "/mcp/internal-docs/search",
        "data_accessed": "Approved internal documentation, onboarding policy, and API gateway operating procedures",
        "environment": "sandbox",
        "intent_category": "internal_knowledge_search",
        "confidence_score": confidence,
        "action_summary": "Search approved internal documentation for policy or onboarding guidance.",
    }


def classify_intent(user_input: str) -> dict:
    text = user_input.lower().strip()
    customer = _customer_token(user_input)
    amount = _refund_amount(user_input)
    production = "production" in text or "prod" in text

    if any(term in text for term in ["delete user", "admin user", "admin account", "permissions", "inactive admin"]):
        return {
            "agent_name": "Admin Operations Agent",
            "tool_name": "Admin User Management API",
            "request_method": "DELETE" if "delete" in text else "PATCH",
            "endpoint": "/api/admin/users/inferred-account",
            "data_accessed": "Admin user account, permissions, role metadata, and production access controls",
            "environment": "production" if production or "delete" in text else "staging",
            "intent_category": "admin_access_control",
            "confidence_score": 0.94,
            "action_summary": "Route an admin account or permission change through governance controls.",
        }

    if any(term in text for term in ["internal knowledge", "knowledge base", "internal docs", "approved internal", "procedure", "policy", "api gateway", "onboarding"]):
        return _internal_docs_route()

    if any(term in text for term in ["finance ledger", "ledger", "mismatch", "reconciliation"]):
        return {
            "agent_name": "Finance Reconciliation Agent",
            "tool_name": "Finance Ledger API",
            "request_method": "GET" if any(term in text for term in ["check", "find", "status"]) else "PATCH",
            "endpoint": "/api/ledger/reconciliation-checks?scope=recent-refunds",
            "data_accessed": "Finance ledger entries, refund reconciliation records, payment status, and mismatch metadata",
            "environment": "production",
            "intent_category": "finance_reconciliation",
            "confidence_score": 0.93,
            "action_summary": "Investigate finance ledger mismatch and reconciliation status.",
        }

    if any(term in text for term in ["refund", "return money", "refund status"]):
        issuing_refund = any(term in text for term in ["issue", "create", "send", "pay", "return money"])
        high_value = amount is not None and int(amount) >= 500
        return {
            "agent_name": "Refund Processing Agent",
            "tool_name": "Refund API",
            "request_method": "POST" if issuing_refund else "GET",
            "endpoint": "/api/refunds/high-value" if high_value or issuing_refund else f"/api/refunds/status?customer={customer}",
            "data_accessed": (
                "Customer payment record, refund amount, invoice, finance approval context, and refund status"
                if issuing_refund
                else "Refund status, customer reference, support case, and payment metadata"
            ),
            "environment": "production" if issuing_refund or high_value else "staging",
            "intent_category": "refund_workflow",
            "confidence_score": 0.94 if issuing_refund else 0.88,
            "action_summary": (
                f"Attempt high-value refund workflow for {customer}."
                if issuing_refund
                else f"Find refund status for {customer}."
            ),
        }

    if any(term in text for term in ["payment", "transaction", "payment status"]):
        return {
            "agent_name": "Finance Reconciliation Agent",
            "tool_name": "Payment Status API",
            "request_method": "GET",
            "endpoint": "/api/payments/status?reference=inferred",
            "data_accessed": "Payment status, transaction metadata, customer payment reference, and settlement state",
            "environment": "production" if production else "staging",
            "intent_category": "payment_status",
            "confidence_score": 0.88,
            "action_summary": "Check payment or transaction status through governed payment API access.",
        }

    if any(term in text for term in ["send email", "notify customer", "customer update email", "email about"]):
        return {
            "agent_name": "Customer Support Agent",
            "tool_name": "Email Sender Tool",
            "request_method": "POST",
            "endpoint": "/mcp/email/send",
            "data_accessed": "Customer email address, approved support message, delivery context, and case summary",
            "environment": "sandbox" if "draft" in text else "production",
            "intent_category": "customer_communication",
            "confidence_score": 0.9,
            "action_summary": "Prepare and send a governed customer communication.",
        }

    if any(term in text for term in ["customer", "profile", "customer list", "customer emails", "export all customer"]):
        export_request = any(term in text for term in ["export", "all customer", "customer list", "emails"])
        return {
            "agent_name": "Customer Support Agent",
            "tool_name": "Customer Profile API",
            "request_method": "GET",
            "endpoint": "/api/customers/export?segment=inferred" if export_request else f"/api/customers/{customer}/profile",
            "data_accessed": (
                "Customer personal data, email addresses, account notes, renewal value, and support metadata"
                if export_request
                else "Customer profile, support context, account metadata, and contact information"
            ),
            "environment": "production",
            "intent_category": "customer_data_access",
            "confidence_score": 0.91,
            "action_summary": "Access customer profile or customer data through governed CRM API access.",
        }

    if any(term in text for term in ["docs", "policy", "onboarding", "knowledge", "internal docs", "api gateway"]):
        return _internal_docs_route()

    if any(term in text for term in ["revenue", "analytics", "report", "kpi", "dashboard"]):
        return {
            "agent_name": "Analytics Insight Agent",
            "tool_name": "Revenue Analytics API",
            "request_method": "GET",
            "endpoint": "/api/analytics/revenue/inferred-report",
            "data_accessed": "Aggregated revenue analytics, KPI summaries, and reporting metadata",
            "environment": "staging",
            "intent_category": "analytics_reporting",
            "confidence_score": 0.86,
            "action_summary": "Retrieve analytics insight for governed reporting.",
        }

    return {
        "agent_name": "Internal Knowledge Agent",
        "tool_name": "Internal Docs Search",
        "request_method": "GET",
        "endpoint": "/mcp/internal-docs/search",
        "data_accessed": "General internal knowledge base content and approved documentation",
        "environment": "sandbox",
        "intent_category": "general_governance_query",
        "confidence_score": 0.55,
        "action_summary": "Route general user instruction to internal knowledge search for safe handling.",
    }
