from app.models.api_request import APIRequest


SENSITIVITY_POINTS = {"low": 8, "medium": 18, "high": 34, "critical": 52}
SENSITIVITY_RANK = {"low": 1, "medium": 2, "high": 3, "critical": 4}
TRUST_POINTS = {"high": 0, "medium": 9, "low": 20}
ENVIRONMENT_POINTS = {"sandbox": 0, "staging": 7, "production": 16}
METHOD_POINTS = {"GET": 0, "POST": 8, "PATCH": 11, "DELETE": 22}
SEVERITY_POINTS = {"none": 0, "low": 4, "medium": 12, "high": 22, "critical": 32}

PURPOSE_CATEGORY_MAP = {
    "customer": {"customer_support", "CRM", "email", "internal_docs"},
    "support": {"customer_support", "CRM", "email", "internal_docs"},
    "finance": {"finance", "payments", "analytics"},
    "reconciliation": {"finance", "payments", "analytics"},
    "sales": {"CRM", "analytics", "email"},
    "crm": {"CRM", "analytics", "email"},
    "knowledge": {"internal_docs", "customer_support"},
    "docs": {"internal_docs"},
    "refund": {"payments", "customer_support", "finance"},
    "analytics": {"analytics", "finance", "CRM"},
    "admin": {"admin", "internal_docs"},
    "operations": {"admin", "analytics", "internal_docs"},
}

DATA_RISK_TERMS = {
    "customer": 12,
    "personal": 12,
    "pii": 15,
    "email": 8,
    "phone": 8,
    "financial": 18,
    "payment": 18,
    "card": 18,
    "bank": 18,
    "ledger": 16,
    "admin": 15,
    "root": 18,
    "user management": 16,
}

CONTROL_BYPASS_TERMS = ["disable logging", "bypass policy", "skip audit", "hide this action", "run without approval"]


def risk_band(score: int) -> str:
    if score <= 30:
        return "low"
    if score <= 60:
        return "medium"
    if score <= 80:
        return "high"
    return "critical"


def purpose_aligned(agent, tool) -> bool:
    purpose_text = f"{agent.name} {agent.purpose}".lower()
    allowed_categories = set()
    for keyword, categories in PURPOSE_CATEGORY_MAP.items():
        if keyword in purpose_text:
            allowed_categories.update(categories)

    if not allowed_categories:
        return tool.category.lower() in purpose_text

    return tool.category in allowed_categories or tool.category.lower() in {category.lower() for category in allowed_categories}


def calculate_estimated_cost(payload, tool, score: int) -> float:
    text_size = len(payload.user_prompt) + len(payload.action_summary) + len(payload.data_accessed)
    sensitivity_multiplier = SENSITIVITY_RANK.get(tool.sensitivity, 2)
    method_multiplier = 1.4 if payload.request_method in {"POST", "PATCH", "DELETE"} else 1.0
    cost = 0.008 + (text_size / 1000) * 0.015 + sensitivity_multiplier * 0.006 + (score / 1000) * method_multiplier
    return round(cost, 4)


def calculate_latency_ms(payload, score: int) -> int:
    return 110 + (score * 5) + (len(payload.user_prompt) % 90)


def calculate_risk(db, agent, tool, payload, detector_result: dict) -> dict:
    score = 5
    reasons = []

    sensitivity_score = SENSITIVITY_POINTS.get(tool.sensitivity, 18)
    score += sensitivity_score
    reasons.append(f"{tool.sensitivity.title()} sensitivity tool adds {sensitivity_score} points")

    trust_score = TRUST_POINTS.get(agent.trust_level, 9)
    score += trust_score
    if trust_score:
        reasons.append(f"{agent.trust_level.title()} trust agent increases runtime risk")

    environment_score = ENVIRONMENT_POINTS.get(payload.environment, 0)
    score += environment_score
    if environment_score:
        reasons.append(f"{payload.environment.title()} environment raises operational impact")

    method_score = METHOD_POINTS.get(payload.request_method, 0)
    score += method_score
    if method_score:
        reasons.append(f"{payload.request_method} request carries write/destructive risk")

    detector_score = SEVERITY_POINTS.get(detector_result.get("severity", "none"), 0)
    score += detector_score
    if detector_score:
        reasons.append(f"{detector_result['severity'].title()} prompt risk signal detected")

    combined_text = f"{payload.user_prompt} {payload.action_summary} {payload.data_accessed} {payload.endpoint}".lower()
    for term, points in DATA_RISK_TERMS.items():
        if term in combined_text:
            score += points
            reasons.append(f"Sensitive data term '{term}' adds {points} points")

    if not purpose_aligned(agent, tool):
        score += 15
        reasons.append("Tool category is outside the agent's declared operating purpose")

    blocked_attempts = (
        db.query(APIRequest)
        .filter(APIRequest.agent_id == agent.id, APIRequest.policy_decision == "blocked")
        .count()
    )
    if blocked_attempts:
        repeated_points = min(blocked_attempts * 5, 20)
        score += repeated_points
        reasons.append(f"{blocked_attempts} previous blocked attempt(s) increase repeat-risk scoring")

    if any(term in combined_text for term in CONTROL_BYPASS_TERMS):
        score += 25
        reasons.append("Control-bypass language targets logging, policy, audit, or approval controls")

    score = min(100, score)

    return {
        "score": score,
        "band": risk_band(score),
        "reasons": reasons,
        "estimated_cost": calculate_estimated_cost(payload, tool, score),
        "latency_ms": calculate_latency_ms(payload, score),
        "purpose_aligned": purpose_aligned(agent, tool),
        "previous_blocked_attempts": blocked_attempts,
    }
