import json
from collections import Counter

from sqlalchemy import func

from app.models.api_request import APIRequest
from app.models.approval import Approval
from app.models.audit_event import AuditEvent
from app.models.tool import Tool
from app.services.business_metrics import calculate_business_metrics


def generate_director_summary(db) -> dict:
    total = db.query(APIRequest).count()
    allowed = db.query(APIRequest).filter(APIRequest.policy_decision == "allowed").count()
    blocked = db.query(APIRequest).filter(APIRequest.policy_decision == "blocked").count()
    approval_required = db.query(APIRequest).filter(APIRequest.policy_decision == "approval_required").count()
    pending_approvals = db.query(Approval).filter(Approval.status == "pending").count()
    critical = db.query(APIRequest).filter(APIRequest.risk_band == "critical").count()
    high = db.query(APIRequest).filter(APIRequest.risk_band == "high").count()
    avg_risk = db.query(func.avg(APIRequest.risk_score)).scalar() or 0
    total_cost = db.query(func.sum(APIRequest.estimated_cost)).scalar() or 0
    business_metrics = calculate_business_metrics(db)

    signal_counter = Counter()
    for row in db.query(APIRequest.detected_signals).all():
        try:
            signal_counter.update(json.loads(row[0] or "[]"))
        except json.JSONDecodeError:
            continue

    sensitive_usage = (
        db.query(Tool.name, Tool.sensitivity, func.count(APIRequest.id).label("count"))
        .join(APIRequest, APIRequest.tool_id == Tool.id)
        .filter(Tool.sensitivity.in_(["high", "critical"]))
        .group_by(Tool.id)
        .order_by(func.count(APIRequest.id).desc())
        .limit(5)
        .all()
    )

    latest_control_event = db.query(AuditEvent).order_by(AuditEvent.timestamp.desc()).first()

    executive_summary = (
        f"AgentGuard OS reviewed {total} agent-to-tool actions and applied runtime governance before API execution. "
        f"{blocked} actions were blocked, {approval_required} required human approval, {allowed} were allowed under policy, "
        f"and {business_metrics['executed_sandbox_actions']} were executed safely inside the local sandbox."
    )
    if total == 0:
        executive_summary = (
            "AgentGuard OS is ready to monitor agent-to-tool activity, but no governed requests have been recorded yet."
        )

    top_risks = []
    if critical:
        top_risks.append(f"{critical} critical-risk action(s) were detected and require leadership visibility.")
    if high:
        top_risks.append(f"{high} high-risk action(s) indicate meaningful operational exposure.")
    if signal_counter:
        signal, count = signal_counter.most_common(1)[0]
        top_risks.append(f"The most common runtime risk signal was '{signal}', seen {count} time(s).")
    if pending_approvals:
        top_risks.append(f"{pending_approvals} approval item(s) are waiting for a human decision.")
    if not top_risks:
        top_risks.append("Current activity is low risk, with no critical or high-risk backlog.")

    key_risk_findings = [
        f"{critical + high} high or critical risk action(s) were seen across governed AI agent workflows.",
        f"{business_metrics['risky_request_stopped_count']} risky request(s) were stopped or routed before execution.",
        f"The most common risk category is {business_metrics['most_common_risk_category'].lower()}.",
        f"The top policy trigger is {business_metrics['top_policy_trigger'].lower()}.",
    ]
    if signal_counter:
        signal, count = signal_counter.most_common(1)[0]
        key_risk_findings.append(f"Prompt attack signal '{signal}' appeared {count} time(s).")

    sensitive_tool_sentence = "No sensitive high or critical tool usage has been recorded."
    if sensitive_usage:
        parts = [f"{name} ({sensitivity}, {count} call(s))" for name, sensitivity, count in sensitive_usage]
        sensitive_tool_sentence = "Sensitive API usage is concentrated in " + "; ".join(parts) + "."

    latest_event_sentence = "No audit events have been created yet."
    if latest_control_event:
        latest_event_sentence = (
            f"Latest audit event: {latest_control_event.event_type} by {latest_control_event.actor}."
        )

    return {
        "executive_summary": executive_summary,
        "key_risk_findings": key_risk_findings,
        "ai_agent_activity_overview": (
            f"{total} governed action(s) were processed across active agents and tools. "
            f"Average risk score is {avg_risk:.1f}; {business_metrics['governance_coverage_percentage']}% of requests have audit coverage."
        ),
        "total_agent_activity": (
            f"{total} governed agent action(s) processed, with an average risk score of {avg_risk:.1f}."
        ),
        "top_risks": top_risks,
        "blocked_unsafe_actions": (
            f"{blocked} unsafe action(s) were blocked before execution. "
            f"{sum(signal_counter.values())} prompt or control-bypass signal(s) were recorded."
        ),
        "sandbox_execution_control": (
            f"{business_metrics['executed_sandbox_actions']} action(s) executed safely in the sandbox, "
            f"{business_metrics['blocked_before_execution']} were blocked before sandbox execution, "
            f"{business_metrics['awaiting_approval_execution']} are paused for approval, and "
            f"{business_metrics['approved_pending_execution']} are approved but still waiting for explicit execution."
        ),
        "execution_evidence": (
            f"{business_metrics['evidence_records_created']} request(s) have execution evidence showing simulated output, "
            "business impact, next step, and proof that no external system was contacted."
        ),
        "blocked_attack_attempts": (
            f"{blocked} request(s) were blocked before tool execution. "
            f"Detected attack/control signals: {sum(signal_counter.values())}."
        ),
        "governance_coverage": (
            "Every simulated action is evaluated through agent identity, prompt signal detection, risk scoring, "
            "policy enforcement, audit logging, and approval routing when required."
        ),
        "sensitive_tool_usage": sensitive_tool_sentence,
        "most_exposed_tools_apis": sensitive_tool_sentence,
        "approval_bottlenecks": (
            f"{pending_approvals} pending approval(s) are waiting for review; "
            f"{business_metrics['approval_records_created']} total request(s) entered the human approval path."
        ),
        "estimated_cost_visibility": (
            f"Estimated AI/API usage cost currently tracked across governed actions is ${total_cost:.4f}."
        ),
        "business_value_metrics": business_metrics,
        "policy_recommendations": [
            "Keep critical tools behind human approval until production trust levels are proven.",
            "Review repeated blocked attempts by the same agent before expanding its scope.",
            "Treat customer export, payment, finance, and admin workflows as board-visible control points.",
            "Use audit events to evidence who approved or blocked risky agentic workflow actions.",
        ],
        "recommended_next_policies": [
            "Create explicit high-value refund approval thresholds.",
            "Require approval for production DELETE actions across admin tools.",
            "Add stronger customer data export controls for CRM and support systems.",
            "Track repeated blocked attempts by agent identity and owner team.",
        ],
        "business_value_summary": (
            f"AgentGuard OS makes agent identity, sensitive API access, policy decisions, approval status, and auditability visible before systems are affected. "
            f"It stopped or routed {business_metrics['risky_requests_stopped_percentage']}% of risky requests before execution, "
            f"kept {business_metrics['execution_prevention_rate']}% of activity from executing until controls were satisfied, "
            f"and saved an estimated {business_metrics['estimated_manual_review_time_saved_hours']} hours of manual review effort."
        ),
        "thirty_day_improvement_plan": [
            "Week 1: classify the top 20 APIs by sensitivity and owner team.",
            "Week 2: define approval thresholds for finance, refunds, admin actions, and customer data export.",
            "Week 3: onboard agent identities into runtime policy enforcement and audit logging.",
            "Week 4: review blocked attempts, tune policies, and present governance coverage to leadership.",
        ],
        "next_actions_for_leadership": [
            "Define which APIs are critical enough to require approval by default.",
            "Assign owners for high-risk agents and sensitive tool categories.",
            "Set approval service-level expectations for finance, payments, admin, and customer data workflows.",
            f"Use the audit trail for governance review. {latest_event_sentence}",
        ],
    }


def generate_presentation_mode(db) -> dict:
    business_metrics = calculate_business_metrics(db)
    summary = generate_director_summary(db)

    return {
        "product_pitch": "AgentGuard OS governs every AI agent action before it becomes business risk.",
        "problem": (
            "AI agents can now call APIs, tools, and business systems. Leadership needs proof of which agent touched which system, "
            "why it was allowed, what risk it created, and where a human decision was required."
        ),
        "solution": (
            "AgentGuard OS acts as a runtime governance layer for agent-to-tool access. It checks prompt signals, risk, policy, "
            "sensitive API access, approval status, sandbox execution, and audit evidence before external systems are affected."
        ),
        "why_now": (
            "Agentic workflows are moving from experiments into operations. API governance needs to extend from human and application traffic "
            "to AI agents before sensitive systems are exposed."
        ),
        "business_value": summary["business_value_summary"],
        "demo_flow": [
            "Open the dashboard and show live agent, API, risk, approval, and audit metrics.",
            "Run the safe internal knowledge scenario and show policy allow plus safe sandbox output.",
            "Run the prompt-injection scenario and show blocked signals with no sandbox execution.",
            "Run finance, production DELETE, or high-value refund scenarios and show approval routing.",
            "Approve one request, execute the approved sandbox action, then close with lineage, audit trail, and the director report.",
        ],
        "execution_lifecycle": [
            "Allowed requests execute only inside the local sandbox and produce evidence.",
            "Blocked requests never execute and record prevention evidence.",
            "Approval-required requests pause before sandbox execution.",
            "Human approval moves the request to approved pending execution.",
            "Execution remains a separate auditable action after approval.",
        ],
        "cv_bullet": (
            "Built AgentGuard OS, a FastAPI and SQLite AI Agent Security and API Governance platform that simulates agent-to-tool access, "
            "detects prompt-injection signals, scores runtime risk, enforces policies, routes human approvals, executes approved actions in a sandbox, and creates audit trails for agentic workflows."
        ),
        "interview_explanation": (
            "The project demonstrates how I think about AI governance as a product and backend problem: model the core entities, keep decisioning in services, "
            "derive every metric from backend data, and make the UI tell a clear risk and business-value story."
        ),
        "business_metrics": business_metrics,
    }
