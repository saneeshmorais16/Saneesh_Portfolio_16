from app.models.policy import Policy
from app.services.risk_engine import SENSITIVITY_RANK, purpose_aligned


BLOCK_ON_ATTACK_SIGNALS = {
    "ignore previous instructions",
    "bypass policy",
    "reveal secrets",
    "impersonate admin",
    "disable logging",
    "hide this action",
    "override approval",
    "make unauthorized payment",
    "expose API key",
    "skip audit",
    "run without approval",
}

HIGH_CONTROL_CATEGORIES = {"finance", "payments", "admin", "customer_support", "CRM"}


def _combined_text(payload) -> str:
    return f"{payload.user_prompt} {payload.action_summary} {payload.data_accessed} {payload.endpoint}".lower()


def _category_matches(policy: Policy, tool) -> bool:
    policy_category = policy.applies_to_tool_category.lower()
    return policy_category == "all" or policy_category == tool.category.lower()


def _active_policy_decision(db, tool, payload) -> dict | None:
    policies = db.query(Policy).filter(Policy.active.is_(True)).all()
    combined_text = _combined_text(payload)

    for policy in policies:
        if not _category_matches(policy, tool):
            continue

        blocked_keywords = [word.strip().lower() for word in policy.blocked_keywords.split(",") if word.strip()]
        matched_keywords = [word for word in blocked_keywords if word in combined_text]
        if matched_keywords:
            return {
                "decision": "blocked",
                "reason": f"Policy '{policy.name}' blocked keyword(s): {', '.join(matched_keywords)}.",
            }

        allowed_rank = SENSITIVITY_RANK.get(policy.max_sensitivity_allowed, 3)
        tool_rank = SENSITIVITY_RANK.get(tool.sensitivity, 2)
        if tool_rank > allowed_rank:
            if policy.requires_human_approval:
                return {
                    "decision": "approval_required",
                    "reason": f"Policy '{policy.name}' requires human approval for {tool.sensitivity} sensitivity access.",
                }
            return {
                "decision": "blocked",
                "reason": f"Policy '{policy.name}' blocks {tool.sensitivity} sensitivity access.",
            }

    return None


def evaluate_policy(db, agent, tool, payload, risk_result: dict, detector_result: dict) -> dict:
    score = risk_result["score"]
    combined_text = _combined_text(payload)
    signals = set(detector_result.get("matched_signals", []))

    if agent.status != "active":
        return {
            "decision": "blocked",
            "reason": f"Agent status is {agent.status}; inactive or reviewed agents cannot invoke governed tools.",
        }

    if tool.status != "active":
        return {
            "decision": "blocked",
            "reason": f"Tool status is {tool.status}; inactive tools are not available for runtime access.",
        }

    if signals & BLOCK_ON_ATTACK_SIGNALS:
        return {
            "decision": "blocked",
            "reason": "Prompt attack detector identified a control-bypass or credential-exposure signal.",
        }

    if detector_result.get("detected") and score >= 70:
        return {
            "decision": "blocked",
            "reason": "Prompt-injection signal combined with high risk exceeded the blocking threshold.",
        }

    policy_decision = _active_policy_decision(db, tool, payload)
    if policy_decision:
        return policy_decision

    if agent.trust_level == "low" and tool.category in HIGH_CONTROL_CATEGORIES:
        return {
            "decision": "blocked",
            "reason": "Low trust agents cannot access finance, payments, admin, CRM, or customer data tools.",
        }

    if "export" in combined_text and "customer" in combined_text:
        if score >= 75 or agent.trust_level == "low":
            return {
                "decision": "blocked",
                "reason": "Customer data export request is too risky for automated execution.",
            }
        return {
            "decision": "approval_required",
            "reason": "Customer data export requires human approval and audit review.",
        }

    if tool.sensitivity == "critical":
        return {
            "decision": "approval_required",
            "reason": "Critical sensitivity tools require human approval before execution.",
        }

    if tool.category == "payments" and ("refund" in combined_text or "payment" in combined_text) and score > 60:
        return {
            "decision": "approval_required",
            "reason": "High-risk payment or refund activity requires human approval before execution.",
        }

    if payload.environment == "production" and payload.request_method == "DELETE":
        return {
            "decision": "approval_required",
            "reason": "Production DELETE requests require human approval.",
        }

    if tool.category == "finance" and score > 60:
        return {
            "decision": "approval_required",
            "reason": "Finance-related actions above medium risk require human approval.",
        }

    if tool.category == "admin" and agent.trust_level != "high":
        return {
            "decision": "approval_required",
            "reason": "Admin actions require approval unless the agent has high trust.",
        }

    if not purpose_aligned(agent, tool):
        if score >= 60:
            return {
                "decision": "blocked",
                "reason": "Agent attempted to access a tool outside its declared purpose at elevated risk.",
            }
        return {
            "decision": "approval_required",
            "reason": "Agent purpose and tool category are not aligned; human approval is required.",
        }

    if score >= 85:
        return {"decision": "blocked", "reason": "Risk score crossed the critical blocking threshold."}

    if score >= 61:
        return {"decision": "approval_required", "reason": "High runtime risk requires human approval."}

    return {
        "decision": "allowed",
        "reason": "Request passed prompt, risk, purpose, sensitivity, and policy checks.",
    }
