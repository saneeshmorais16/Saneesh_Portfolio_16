import json
from collections import Counter

from sqlalchemy import distinct, func
from sqlalchemy.orm import joinedload

from app.models.api_request import APIRequest
from app.models.approval import Approval
from app.models.audit_event import AuditEvent


def _signals_for_request(request: APIRequest) -> list[str]:
    try:
        parsed = json.loads(request.detected_signals or "[]")
        return parsed if isinstance(parsed, list) else []
    except json.JSONDecodeError:
        return []


def _risk_category(request: APIRequest) -> str:
    text = f"{request.user_prompt} {request.action_summary} {request.data_accessed} {request.endpoint}".lower()
    signals = _signals_for_request(request)

    if signals:
        return "Prompt-injection or control bypass"
    if request.environment == "production" and request.request_method == "DELETE":
        return "Production destructive action"
    if request.tool and request.tool.category in {"finance", "payments"}:
        return "Finance or payment exposure"
    if request.tool and request.tool.sensitivity in {"high", "critical"}:
        return "Sensitive API access"
    if "customer" in text or "personal" in text or "pii" in text:
        return "Customer data access"
    return "Standard governed activity"


def _policy_trigger(request: APIRequest) -> str:
    reason = (request.reason or "").lower()
    if "prompt attack" in reason or "control-bypass" in reason or "credential" in reason:
        return "Prompt attack guardrail"
    if "critical sensitivity" in reason or "critical tool" in reason:
        return "Critical tool approval"
    if "payment or refund" in reason:
        return "High-value payment or refund review"
    if "high runtime risk" in reason:
        return "High-risk approval threshold"
    if "production delete" in reason:
        return "Production DELETE approval"
    if "low trust" in reason:
        return "Low trust access restriction"
    if "customer data export" in reason:
        return "Customer data export control"
    if "finance" in reason:
        return "Finance elevated review"
    if "admin" in reason:
        return "Admin action approval"
    if "outside" in reason or "purpose" in reason:
        return "Agent purpose alignment"
    if request.policy_decision == "allowed":
        return "Automated allow decision"
    return "General runtime policy"


def _intent_from_event_message(message: str) -> str | None:
    marker = "Intent category:"
    if marker not in message:
        return None
    category = message.split(marker, 1)[1].split(".", 1)[0].strip()
    return category or None


def calculate_business_metrics(db) -> dict:
    requests = (
        db.query(APIRequest)
        .options(joinedload(APIRequest.tool), joinedload(APIRequest.approval))
        .all()
    )
    total = len(requests)
    total_cost = db.query(func.sum(APIRequest.estimated_cost)).scalar() or 0
    audited_requests = db.query(func.count(distinct(AuditEvent.request_id))).scalar() or 0

    risky_requests = [request for request in requests if request.risk_band in {"high", "critical"}]
    stopped_risky = [
        request
        for request in risky_requests
        if request.policy_decision in {"blocked", "approval_required"}
        or request.approval is not None
    ]
    approvals_for_risky = [
        approval
        for approval in db.query(Approval).join(APIRequest).all()
        if approval.request and approval.request.risk_band in {"high", "critical"}
    ]

    category_counter = Counter(_risk_category(request) for request in requests)
    trigger_counter = Counter(_policy_trigger(request) for request in requests)
    intent_counter = Counter(
        category
        for category in (
            _intent_from_event_message(event.message)
            for event in db.query(AuditEvent).filter(AuditEvent.event_type == "intent_routed").all()
        )
        if category
    )

    blocked = len([request for request in requests if request.policy_decision == "blocked"])
    allowed = len([request for request in requests if request.policy_decision == "allowed"])
    approval_count = db.query(Approval).count()
    executed_sandbox_actions = len([request for request in requests if request.execution_status == "executed"])
    blocked_before_execution = len([request for request in requests if request.execution_status == "blocked"])
    awaiting_approval_execution = len([request for request in requests if request.execution_status == "awaiting_approval"])
    approved_pending_execution = len(
        [request for request in requests if request.execution_status == "approved_pending_execution"]
    )
    rejected_execution = len([request for request in requests if request.execution_status == "rejected"])
    evidence_records_created = len([request for request in requests if request.evidence_created])

    stopped_percentage = round((len(stopped_risky) / len(risky_requests)) * 100, 1) if risky_requests else 0
    coverage_percentage = round((audited_requests / total) * 100, 1) if total else 0
    execution_prevention_count = blocked_before_execution + awaiting_approval_execution + rejected_execution
    execution_prevention_rate = round((execution_prevention_count / total) * 100, 1) if total else 0

    return {
        "risky_requests_stopped_percentage": stopped_percentage,
        "high_risk_actions_needing_approval": len(approvals_for_risky),
        "estimated_manual_review_time_saved_minutes": blocked * 12 + allowed * 6,
        "estimated_manual_review_time_saved_hours": round((blocked * 12 + allowed * 6) / 60, 1),
        "governance_coverage_percentage": coverage_percentage,
        "most_common_intent_category": intent_counter.most_common(1)[0][0] if intent_counter else "No auto-agent runs yet",
        "most_common_risk_category": category_counter.most_common(1)[0][0] if category_counter else "No activity yet",
        "top_policy_trigger": trigger_counter.most_common(1)[0][0] if trigger_counter else "No policy trigger yet",
        "estimated_cost_visibility": round(total_cost, 4),
        "estimated_cost_visibility_label": f"${total_cost:.4f} tracked across {total} governed action(s)",
        "approval_records_created": approval_count,
        "audited_request_count": audited_requests,
        "risky_request_count": len(risky_requests),
        "risky_request_stopped_count": len(stopped_risky),
        "executed_sandbox_actions": executed_sandbox_actions,
        "blocked_before_execution": blocked_before_execution,
        "awaiting_approval_execution": awaiting_approval_execution,
        "approved_pending_execution": approved_pending_execution,
        "rejected_execution": rejected_execution,
        "evidence_records_created": evidence_records_created,
        "execution_prevention_count": execution_prevention_count,
        "execution_prevention_rate": execution_prevention_rate,
    }
