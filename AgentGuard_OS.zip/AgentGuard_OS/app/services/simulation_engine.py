import json

from fastapi import HTTPException

from app.models.agent import Agent
from app.models.api_request import APIRequest
from app.models.approval import Approval
from app.models.tool import Tool
from app.services.audit_service import create_audit_event
from app.services.policy_engine import evaluate_policy
from app.services.prompt_attack_detector import detect_prompt_attack
from app.services.risk_engine import calculate_risk
from app.services.sandbox_executor import run_sandbox_execution


def simulate_agent_request(db, payload, auto_context: dict | None = None) -> dict:
    agent = db.query(Agent).filter(Agent.id == payload.agent_id).first()
    tool = db.query(Tool).filter(Tool.id == payload.tool_id).first()

    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    if not tool:
        raise HTTPException(status_code=404, detail="Tool/API not found")

    detector_result = detect_prompt_attack(
        payload.user_prompt,
        payload.action_summary,
        payload.data_accessed,
        payload.endpoint,
    )
    risk_result = calculate_risk(db, agent, tool, payload, detector_result)
    policy_result = evaluate_policy(db, agent, tool, payload, risk_result, detector_result)

    api_request = APIRequest(
        agent_id=agent.id,
        tool_id=tool.id,
        user_prompt=payload.user_prompt,
        action_summary=payload.action_summary,
        data_accessed=payload.data_accessed,
        request_method=payload.request_method,
        endpoint=payload.endpoint,
        environment=payload.environment,
        risk_score=risk_result["score"],
        risk_band=risk_result["band"],
        policy_decision=policy_result["decision"],
        reason=policy_result["reason"],
        detected_signals=json.dumps(detector_result["matched_signals"]),
        estimated_cost=risk_result["estimated_cost"],
        latency_ms=risk_result["latency_ms"],
    )
    db.add(api_request)
    db.flush()

    if auto_context:
        create_audit_event(
            db,
            api_request.id,
            "auto_input_received",
            f"Natural language input received: {auto_context['user_input']}",
            actor="auto-agent-mode",
        )
        create_audit_event(
            db,
            api_request.id,
            "intent_routed",
            (
                f"Intent Router selected {agent.name} and {tool.name}. "
                f"Intent category: {auto_context['intent_category']}. "
                f"Confidence: {auto_context['confidence_score']:.2f}."
            ),
            actor="intent-router",
        )

    signal_count = len(detector_result["matched_signals"])
    prompt_scan_message = (
        f"Prompt Attack Detector identified {signal_count} unsafe instruction pattern(s): "
        f"{', '.join(detector_result['matched_signals'])}."
        if signal_count
        else "Prompt Attack Detector found no unsafe instruction patterns in the prompt, action, endpoint, or data description."
    )

    create_audit_event(
        db,
        api_request.id,
        "request_received",
        f"Governance intake recorded {agent.name} requesting {payload.request_method} {payload.endpoint} through {tool.name} in {payload.environment}.",
        actor=agent.name,
    )
    create_audit_event(
        db,
        api_request.id,
        "prompt_attack_scan",
        prompt_scan_message,
        actor="prompt-attack-detector",
    )
    create_audit_event(
        db,
        api_request.id,
        "risk_scored",
        f"Risk Engine assigned {risk_result['score']}/100 as {risk_result['band']} risk using tool sensitivity, agent trust, environment, method, data, and previous blocked attempts.",
        actor="risk-engine",
    )
    create_audit_event(
        db,
        api_request.id,
        "policy_decision",
        f"Policy Engine evaluated request against sensitive API access rules. Decision: {policy_result['decision']}. {policy_result['reason']}",
        actor="policy-engine",
    )

    approval = None
    if policy_result["decision"] == "approval_required":
        approval = Approval(request_id=api_request.id, status="pending")
        db.add(approval)
        db.flush()
        create_audit_event(
            db,
            api_request.id,
            "approval_created",
            f"Request moved to human approval due to {risk_result['band']} risk, {tool.sensitivity} tool sensitivity, or policy requirements.",
            actor="approval-service",
        )
    else:
        outcome_message = (
            "Agent action blocked before execution."
            if policy_result["decision"] == "blocked"
            else "Agent action allowed by runtime governance controls."
        )
        create_audit_event(
            db,
            api_request.id,
            "final_outcome",
            outcome_message,
            actor="governance-engine",
        )

    if auto_context:
        create_audit_event(
            db,
            api_request.id,
            "request_saved",
            "Request saved to governance history with audit and lineage evidence for director review.",
            actor="governance-engine",
        )

    execution_result = run_sandbox_execution(
        db,
        api_request,
        agent,
        tool,
        policy_result["decision"],
        risk_result["score"],
        payload.user_prompt,
    )

    db.commit()
    db.refresh(api_request)
    if approval:
        db.refresh(approval)

    return {
        "request": api_request,
        "agent": agent,
        "tool": tool,
        "detector": detector_result,
        "risk": risk_result,
        "policy": policy_result,
        "approval": approval,
        "execution": execution_result,
    }
