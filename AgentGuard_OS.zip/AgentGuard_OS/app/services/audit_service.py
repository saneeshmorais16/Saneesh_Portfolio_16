from app.models.audit_event import AuditEvent


def create_audit_event(db, request_id: int, event_type: str, message: str, actor: str = "governance-engine") -> AuditEvent:
    event = AuditEvent(
        request_id=request_id,
        event_type=event_type,
        message=message,
        actor=actor,
    )
    db.add(event)
    db.flush()
    return event
