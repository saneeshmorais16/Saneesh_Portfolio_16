from sqlalchemy import create_engine, text
from sqlalchemy.orm import declarative_base, sessionmaker

from app.core.config import settings


connect_args = {"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(settings.DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def ensure_sqlite_schema() -> None:
    if not settings.DATABASE_URL.startswith("sqlite"):
        return

    columns = {
        "execution_status": "VARCHAR(60) NOT NULL DEFAULT 'not_started'",
        "execution_summary": "TEXT NOT NULL DEFAULT ''",
        "simulated_output": "TEXT NOT NULL DEFAULT ''",
        "business_impact": "TEXT NOT NULL DEFAULT ''",
        "evidence_created": "TEXT NOT NULL DEFAULT ''",
        "next_step": "TEXT NOT NULL DEFAULT ''",
        "executed_at": "DATETIME",
    }

    with engine.begin() as connection:
        existing = {
            row[1]
            for row in connection.execute(text("PRAGMA table_info(api_requests)")).fetchall()
        }
        for column_name, column_definition in columns.items():
            if column_name not in existing:
                connection.execute(
                    text(f"ALTER TABLE api_requests ADD COLUMN {column_name} {column_definition}")
                )
