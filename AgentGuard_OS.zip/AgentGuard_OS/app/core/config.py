from pathlib import Path

from pydantic import BaseModel


PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseModel):
    APP_NAME: str = "AgentGuard OS"
    DATABASE_URL: str = f"sqlite:///{PROJECT_ROOT / 'agentguard_os.db'}"
    AUTO_SEED: bool = True


settings = Settings()
