# LD6051 Student Performance Prediction Project

This is a VS Code/local-machine project structure for the LD6051 Machine Learning on Cloud group project.

## Folder structure

```text
LD6051_Student_Performance_Project/
├── data/
│   └── data.csv              # Put the UCI dataset CSV here
├── student_performance_outputs/
│   └── generated outputs will appear here
├── main.py
├── requirements.txt
└── README.md
```

## Dataset

Use the UCI dataset: **Predict Students' Dropout and Academic Success**.

Download it from:
https://archive.ics.uci.edu/dataset/697/predict+students+dropout+and+academic+success

After downloading and extracting the dataset, put the CSV file into the `data` folder and rename it to:

```text
data.csv
```

The code expects this exact path:

```text
./data/data.csv
```

## How to run in VS Code

Open the project folder in VS Code.

Open the terminal and run:

```bash
pip install -r requirements.txt
```

Then run:

```bash
python main.py
```

## Outputs

The script will create outputs inside:

```text
student_performance_outputs/
```

It will generate:

- EDA charts
- dataset summaries
- preprocessing summaries
- feature engineering table
- model comparison tables
- confusion matrices
- ROC curves
- precision-recall curves
- feature importance chart
- fairness audit files
- final model recommendation

## Target mapping for the report

```text
Dropout  -> Low Performance / At-Risk
Enrolled -> Medium Performance
Graduate -> High Performance / Successful
```

## Important note

Do not change this line unless your CSV format is different:

```python
pd.read_csv(path, sep=";")
```

The UCI dataset uses semicolon separators.
