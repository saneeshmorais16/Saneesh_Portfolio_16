# ============================================================
# LD6051 - STUDENT PERFORMANCE CLASSIFICATION
# VS CODE / LAPTOP VERSION
# Focus:
#   - model comparison
#   - model evaluation
#   - visualisation
#
# MODELS:
#   - Logistic Regression
#   - Random Forest
#   - SVM
#   - XGBoost
#
# EXPERIMENTS:
#   - Full features, no SMOTE
#   - Full features, with SMOTE
#   - Reduced features, no SMOTE
#   - Reduced features, with SMOTE
# ============================================================

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, label_binarize
from sklearn.svm import SVC
from xgboost import XGBClassifier


# ============================================================
# SETTINGS
# ============================================================
RANDOM_STATE = 42
CLASS_ORDER = ["Dropout", "Enrolled", "Graduate"]

BASE_DIR = Path(r"C:\Users\sanee\AppData\Local\Programs\Python\Python313\LD6051_Student_Performance_Project")
DATA_PATH = BASE_DIR / "data" / "data.csv"
OUTPUT_ROOT = BASE_DIR / "student_performance_outputs"

sns.set_theme(style="whitegrid")
plt.rcParams["figure.figsize"] = (8, 5)

CATEGORICAL_CODED_COLS = [
    "Marital status",
    "Application mode",
    "Application order",
    "Course",
    "Daytime/evening attendance",
    "Previous qualification",
    "Nacionality",
    "Mother's qualification",
    "Father's qualification",
    "Mother's occupation",
    "Father's occupation",
    "Displaced",
    "Educational special needs",
    "Debtor",
    "Tuition fees up to date",
    "Gender",
    "Scholarship holder",
    "International",
]

REDUCED_FEATURE_DROP_COLS = [
    "Curricular units 1st sem (approved)",
    "Curricular units 1st sem (grade)",
    "Curricular units 2nd sem (approved)",
    "Curricular units 2nd sem (grade)",
]


# ============================================================
# RESULT CONTAINER
# ============================================================
@dataclass
class ExperimentResult:
    experiment_name: str
    model_name: str
    best_estimator: object
    best_params: Dict
    cv_accuracy: float
    cv_f1_weighted: float
    test_accuracy: float
    test_precision_weighted: float
    test_recall_weighted: float
    test_f1_weighted: float
    test_roc_auc_ovr_weighted: float
    classification_rep: str
    confusion_mat: np.ndarray
    y_test: pd.Series
    y_pred: np.ndarray
    y_prob: np.ndarray
    fit_time_seconds: float
    predict_time_seconds: float


# ============================================================
# HELPERS
# ============================================================
def make_dirs(root: Path) -> Dict[str, Path]:
    dirs = {
        "root": root,
        "comparisons": root / "model_comparison",
        "evaluation": root / "model_evaluation",
        "figures": root / "visualisations",
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found at: {path}")

    df = pd.read_csv(path, sep=";")

    if "Daytime/evening attendance\t" in df.columns:
        df = df.rename(columns={"Daytime/evening attendance\t": "Daytime/evening attendance"})

    return df


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """
    Adds explainable engineered features.
    Can optionally drop strong direct progression features
    for a reduced-feature comparison.
    """

    def __init__(self, reduced_feature_mode: bool = False):
        self.reduced_feature_mode = reduced_feature_mode

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = X.copy()

        if {
            "Curricular units 1st sem (approved)",
            "Curricular units 2nd sem (approved)"
        }.issubset(X.columns):
            X["approved_progression_delta"] = (
                X["Curricular units 2nd sem (approved)"] -
                X["Curricular units 1st sem (approved)"]
            )

        if {
            "Curricular units 1st sem (grade)",
            "Curricular units 2nd sem (grade)"
        }.issubset(X.columns):
            X["grade_progression_delta"] = (
                X["Curricular units 2nd sem (grade)"] -
                X["Curricular units 1st sem (grade)"]
            )
            X["mean_semester_grade"] = (
                X["Curricular units 1st sem (grade)"] +
                X["Curricular units 2nd sem (grade)"]
            ) / 2

        if {
            "Curricular units 1st sem (approved)",
            "Curricular units 1st sem (enrolled)"
        }.issubset(X.columns):
            X["approval_ratio_1st_sem"] = (
                X["Curricular units 1st sem (approved)"] /
                (X["Curricular units 1st sem (enrolled)"] + 1)
            )

        if {
            "Curricular units 2nd sem (approved)",
            "Curricular units 2nd sem (enrolled)"
        }.issubset(X.columns):
            X["approval_ratio_2nd_sem"] = (
                X["Curricular units 2nd sem (approved)"] /
                (X["Curricular units 2nd sem (enrolled)"] + 1)
            )

        if {
            "Curricular units 1st sem (approved)",
            "Curricular units 1st sem (evaluations)"
        }.issubset(X.columns):
            X["evaluation_efficiency_1st"] = (
                X["Curricular units 1st sem (approved)"] /
                (X["Curricular units 1st sem (evaluations)"] + 1)
            )

        if {
            "Curricular units 2nd sem (approved)",
            "Curricular units 2nd sem (evaluations)"
        }.issubset(X.columns):
            X["evaluation_efficiency_2nd"] = (
                X["Curricular units 2nd sem (approved)"] /
                (X["Curricular units 2nd sem (evaluations)"] + 1)
            )

        if {"Debtor", "Tuition fees up to date", "Scholarship holder"}.issubset(X.columns):
            X["financial_risk_score"] = (
                X["Debtor"].astype(float)
                + (1 - X["Tuition fees up to date"].astype(float))
                + (1 - X["Scholarship holder"].astype(float))
            )

        if {"Admission grade", "mean_semester_grade"}.issubset(X.columns):
            X["grade_vs_admission_ratio"] = X["mean_semester_grade"] / (X["Admission grade"] + 1)

        if {"approval_ratio_1st_sem", "approval_ratio_2nd_sem"}.issubset(X.columns):
            X["approval_stability"] = np.abs(
                X["approval_ratio_2nd_sem"] - X["approval_ratio_1st_sem"]
            )

        if self.reduced_feature_mode:
            X = X.drop(
                columns=[c for c in REDUCED_FEATURE_DROP_COLS if c in X.columns],
                errors="ignore"
            )

        return X


def build_preprocessor(X_sample: pd.DataFrame) -> ColumnTransformer:
    categorical_cols = [c for c in CATEGORICAL_CODED_COLS if c in X_sample.columns]
    numeric_cols = [c for c in X_sample.columns if c not in categorical_cols]

    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    return ColumnTransformer([
        ("num", numeric_pipe, numeric_cols),
        ("cat", categorical_pipe, categorical_cols),
    ])


def make_pipeline(
    estimator,
    preprocessor: ColumnTransformer,
    reduced_feature_mode: bool = False,
    use_smote: bool = False,
):
    steps = [
        ("features", FeatureEngineer(reduced_feature_mode=reduced_feature_mode)),
        ("preprocessor", preprocessor),
    ]

    if use_smote:
        steps.append(("smote", SMOTE(random_state=RANDOM_STATE, k_neighbors=3)))

    steps.append(("model", estimator))
    return ImbPipeline(steps=steps)


# ============================================================
# MODEL CONFIGURATION
# ============================================================
MODEL_CONFIGS = {
    "Logistic Regression": (
        LogisticRegression(max_iter=3000, class_weight="balanced", random_state=RANDOM_STATE),
        {
            "model__C": [0.1, 0.5, 1, 5, 10],
            "model__solver": ["lbfgs"],
        },
    ),
    "Random Forest": (
        RandomForestClassifier(random_state=RANDOM_STATE),
        {
            "model__n_estimators": [200, 400],
            "model__max_depth": [10, 15, None],
            "model__min_samples_split": [2, 5],
            "model__min_samples_leaf": [1, 2],
            "model__max_features": ["sqrt", "log2"],
        },
    ),
    "SVM": (
        SVC(probability=True, class_weight="balanced", random_state=RANDOM_STATE),
        {
            "model__C": [1, 3, 10],
            "model__kernel": ["rbf"],
            "model__gamma": ["scale", "auto"],
        },
    ),
    "XGBoost": (
        XGBClassifier(
            objective="multi:softprob",
            num_class=3,
            eval_metric="mlogloss",
            random_state=RANDOM_STATE,
            tree_method="hist",
        ),
        {
            "model__n_estimators": [200, 400],
            "model__max_depth": [4, 6],
            "model__learning_rate": [0.03, 0.1],
            "model__subsample": [0.8, 1.0],
            "model__colsample_bytree": [0.8, 1.0],
        },
    ),
}


# ============================================================
# EVALUATION
# ============================================================
def evaluate_model(
    experiment_name: str,
    model_name: str,
    estimator,
    param_grid: Dict,
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.Series,
    y_test: pd.Series,
    reduced_feature_mode: bool,
    use_smote: bool,
) -> ExperimentResult:
    fe = FeatureEngineer(reduced_feature_mode=reduced_feature_mode)
    X_train_fe = fe.fit_transform(X_train)
    preprocessor = build_preprocessor(X_train_fe)

    pipeline = make_pipeline(
        estimator=estimator,
        preprocessor=preprocessor,
        reduced_feature_mode=reduced_feature_mode,
        use_smote=use_smote,
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    search = GridSearchCV(
        estimator=pipeline,
        param_grid=param_grid,
        scoring={"acc": "accuracy", "f1": "f1_weighted"},
        refit="acc",
        cv=cv,
        n_jobs=1,  # IMPORTANT: keeps it stable on your Windows setup
    )

    fit_start = time.perf_counter()
    search.fit(X_train, y_train)
    fit_time = time.perf_counter() - fit_start

    pred_start = time.perf_counter()
    y_pred = search.predict(X_test)
    y_prob = search.predict_proba(X_test)
    predict_time = time.perf_counter() - pred_start

    test_accuracy = accuracy_score(y_test, y_pred)
    test_precision = precision_score(y_test, y_pred, average="weighted", zero_division=0)
    test_recall = recall_score(y_test, y_pred, average="weighted", zero_division=0)
    test_f1 = f1_score(y_test, y_pred, average="weighted", zero_division=0)

    y_test_bin = label_binarize(y_test, classes=CLASS_ORDER)
    test_auc = roc_auc_score(y_test_bin, y_prob, multi_class="ovr", average="weighted")

    cv_results = pd.DataFrame(search.cv_results_)
    best_row = cv_results.loc[search.best_index_]

    return ExperimentResult(
        experiment_name=experiment_name,
        model_name=model_name,
        best_estimator=search.best_estimator_,
        best_params=search.best_params_,
        cv_accuracy=float(best_row["mean_test_acc"]),
        cv_f1_weighted=float(best_row["mean_test_f1"]),
        test_accuracy=test_accuracy,
        test_precision_weighted=test_precision,
        test_recall_weighted=test_recall,
        test_f1_weighted=test_f1,
        test_roc_auc_ovr_weighted=test_auc,
        classification_rep=classification_report(y_test, y_pred, digits=4),
        confusion_mat=confusion_matrix(y_test, y_pred, labels=CLASS_ORDER),
        y_test=y_test,
        y_pred=y_pred,
        y_prob=y_prob,
        fit_time_seconds=fit_time,
        predict_time_seconds=predict_time,
    )


# ============================================================
# VISUALISATIONS
# ============================================================
def plot_confusion_matrix(cm: np.ndarray, title: str, out_path: Path) -> None:
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=CLASS_ORDER)
    disp.plot(cmap="Blues")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()


def plot_multiclass_roc(best_estimator, X_test: pd.DataFrame, y_test: pd.Series, out_path: Path) -> None:
    y_score = best_estimator.predict_proba(X_test)
    y_test_bin = label_binarize(y_test, classes=CLASS_ORDER)

    plt.figure(figsize=(8, 6))
    for i, class_name in enumerate(CLASS_ORDER):
        fpr, tpr, _ = roc_curve(y_test_bin[:, i], y_score[:, i])
        plt.plot(fpr, tpr, label=class_name)

    plt.plot([0, 1], [0, 1], linestyle="--", color="red")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("One-vs-Rest ROC Curves")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()


def plot_precision_recall(best_estimator, X_test: pd.DataFrame, y_test: pd.Series, out_path: Path) -> None:
    y_score = best_estimator.predict_proba(X_test)
    y_test_bin = label_binarize(y_test, classes=CLASS_ORDER)

    plt.figure(figsize=(8, 6))
    for i, class_name in enumerate(CLASS_ORDER):
        precision, recall, _ = precision_recall_curve(y_test_bin[:, i], y_score[:, i])
        plt.plot(recall, precision, label=class_name)

    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("One-vs-Rest Precision-Recall Curves")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()


def save_feature_importance(best_estimator, out_path: Path) -> None:
    model = best_estimator.named_steps["model"]
    preprocessor = best_estimator.named_steps["preprocessor"]
    feature_names = preprocessor.get_feature_names_out()

    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        importances = np.mean(np.abs(model.coef_), axis=0)
    else:
        return

    fi = pd.DataFrame({"Feature": feature_names, "Importance": importances})
    fi = fi.sort_values("Importance", ascending=False).head(20)

    plt.figure(figsize=(11, 7))
    sns.barplot(data=fi, x="Importance", y="Feature")
    plt.title("Top 20 Feature Importances")
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()

    fi.to_csv(out_path.with_suffix(".csv"), index=False)


# ============================================================
# RUN ALL EXPERIMENTS
# ============================================================
def run_all_experiments(df: pd.DataFrame, dirs: Dict[str, Path]) -> None:
    X = df.drop(columns=["Target"])
    y = df["Target"].astype(str)

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        stratify=y,
        random_state=RANDOM_STATE,
    )

    experiments = [
        ("full_no_smote", False, False),
        ("full_with_smote", False, True),
        ("reduced_no_smote", True, False),
        ("reduced_with_smote", True, True),
    ]

    all_results = []

    for experiment_name, reduced_feature_mode, use_smote in experiments:
        print(f"\n===== RUNNING {experiment_name} =====")

        experiment_results = []

        for model_name, (estimator, param_grid) in MODEL_CONFIGS.items():
            print(f"Running {model_name} ...")

            result = evaluate_model(
                experiment_name=experiment_name,
                model_name=model_name,
                estimator=estimator,
                param_grid=param_grid,
                X_train=X_train,
                X_test=X_test,
                y_train=y_train,
                y_test=y_test,
                reduced_feature_mode=reduced_feature_mode,
                use_smote=use_smote,
            )

            experiment_results.append(result)

            report_path = dirs["evaluation"] / f"{experiment_name}_{model_name}_classification_report.txt"
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(result.classification_rep)

            cm_path = dirs["figures"] / f"{experiment_name}_{model_name}_confusion_matrix.png"
            plot_confusion_matrix(
                result.confusion_mat,
                f"{experiment_name} - {model_name} Confusion Matrix",
                cm_path
            )

        summary_df = pd.DataFrame([
            {
                "Experiment": r.experiment_name,
                "Model": r.model_name,
                "CV_Accuracy": r.cv_accuracy,
                "CV_F1_Weighted": r.cv_f1_weighted,
                "Test_Accuracy": r.test_accuracy,
                "Test_Precision_Weighted": r.test_precision_weighted,
                "Test_Recall_Weighted": r.test_recall_weighted,
                "Test_F1_Weighted": r.test_f1_weighted,
                "Test_ROC_AUC_OVR_Weighted": r.test_roc_auc_ovr_weighted,
                "Fit_Time_Seconds": r.fit_time_seconds,
                "Predict_Time_Seconds": r.predict_time_seconds,
                "Best_Params": json.dumps(r.best_params),
            }
            for r in experiment_results
        ]).sort_values("Test_Accuracy", ascending=False)

        summary_path = dirs["comparisons"] / f"{experiment_name}_model_comparison.csv"
        summary_df.to_csv(summary_path, index=False)

        all_results.append(summary_df)

        best = max(experiment_results, key=lambda r: r.test_accuracy)

        roc_path = dirs["figures"] / f"{experiment_name}_{best.model_name}_roc.png"
        pr_path = dirs["figures"] / f"{experiment_name}_{best.model_name}_pr_curve.png"
        fi_path = dirs["figures"] / f"{experiment_name}_{best.model_name}_feature_importance.png"

        plot_multiclass_roc(best.best_estimator, X_test, y_test, roc_path)
        plot_precision_recall(best.best_estimator, X_test, y_test, pr_path)
        save_feature_importance(best.best_estimator, fi_path)

    final_df = pd.concat(all_results, ignore_index=True)
    final_df = final_df.sort_values(["Test_Accuracy", "Test_F1_Weighted"], ascending=False)
    final_df.to_csv(dirs["root"] / "all_experiments_model_comparison.csv", index=False)

    print("\n===== TOP RESULTS OVERALL =====")
    print(final_df.head(12).to_string(index=False))


# ============================================================
# MAIN
# ============================================================
def main():
    dirs = make_dirs(OUTPUT_ROOT)
    df = load_data(DATA_PATH)

    if "Performance_Proxy" in df.columns:
        df = df.drop(columns=["Performance_Proxy"])

    run_all_experiments(df, dirs)
    print(f"\nOutputs saved to: {OUTPUT_ROOT.resolve()}")


if __name__ == "__main__":
    main()