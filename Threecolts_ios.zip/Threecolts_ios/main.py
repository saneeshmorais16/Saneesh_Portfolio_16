from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from ai_os.config import CORS_ALLOWED_ORIGINS
from ai_os.migrations import init_database
from ai_os.routes import router


def create_app() -> FastAPI:
    init_database()

    app = FastAPI(title="AI Impact OS")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=CORS_ALLOWED_ORIGINS,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(router)
    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
