# AI Impact OS

AI Impact OS is a lightweight FastAPI and SQLite application for managing internal AI automation opportunities from intake through evidence, CEO brief, pilot decision, delivery registry, monitoring, and measured savings.

The app is intentionally modular under `ai_os/`. Keep routes, models, schemas, security, migrations, scoring, lifecycle, serializers, audit, AI analysis, UI, utilities, and config separated.

## Features

- Workflow intake with AI opportunity scoring and optional Gemini analysis.
- Evidence, measurement, governance, and pilot decision fields.
- CEO brief, executive summary, report, dashboard, and CSV export.
- Status lifecycle with audit events and role/header security.
- Automation Delivery Layer for approved opportunities: registry, owner, type, status, approval flag, run history, quality checks, failures, rollback plan, monitoring notes, health score, and review flag.
- SQLite migration support for additive schema changes.
- CI-ready tests, linting, formatting checks, security scan, and dependency audit.

## Install

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
```

Copy `.env.example` to `.env` if you want local environment overrides. Gemini is optional; if `GEMINI_API_KEY` is empty, the app uses deterministic keyword analysis.

## Run

```bash
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

Open the dashboard at:

```text
http://127.0.0.1:8000/dashboard-ui
```

Useful endpoints:

- `GET /health`
- `POST /submit-workflow`
- `GET /workflows`
- `GET /workflows/{workflow_id}/brief`
- `PUT /workflows/{workflow_id}/decision`
- `POST /workflows/{workflow_id}/automations`
- `GET /automations`
- `POST /automations/{automation_id}/runs`
- `GET /executive-summary`
- `GET /report`
- `GET /export-csv`

## Environment

```text
DATABASE_URL=sqlite:///./workflows.db
HOURLY_COST_GBP=25
GEMINI_API_KEY=
GEMINI_MODEL=gemini-2.5-flash
AI_OS_API_KEY=
CORS_ALLOWED_ORIGINS=http://127.0.0.1:8000,http://localhost:8000
```

When `AI_OS_API_KEY` is set, write and lead actions require the `X-API-Key` header. Role checks always apply:

- Write roles: `contributor`, `lead`, `admin`
- Lead roles: `lead`, `admin`

Example:

```bash
curl -H "X-API-Key: secret" -H "X-User-Role: admin" http://127.0.0.1:8000/workflows
```

## Developer Commands

```bash
make dev
make run
make test
make lint
make format-check
make security
make audit
make ci
```

Equivalent commands without `make`:

```bash
python -m pytest
python -m ruff check .
python -m ruff format --check .
python -m bandit -r ai_os main.py -c pyproject.toml
python -m pip_audit -r requirements.txt --no-deps --disable-pip --progress-spinner off --cache-dir .pip-audit-cache
```

On Windows PowerShell, if the default temp directory is blocked:

```powershell
New-Item -ItemType Directory -Force .pip-audit-cache, .pip-audit-tmp
$env:TMP = (Resolve-Path .pip-audit-tmp)
$env:TEMP = (Resolve-Path .pip-audit-tmp)
$env:TMPDIR = (Resolve-Path .pip-audit-tmp)
python -m pip_audit -r requirements.txt --no-deps --disable-pip --progress-spinner off --cache-dir .pip-audit-cache
```

Tests use temporary SQLite databases and do not touch `workflows.db`.

## GitHub Actions

`.github/workflows/ci.yml` runs on every push and pull request. The workflow:

1. Installs Python 3.13 dependencies.
2. Compiles/imports the FastAPI app.
3. Runs Ruff linting.
4. Runs Ruff formatting check.
5. Runs pytest.
6. Runs Bandit security scanning.
7. Runs pip-audit against `requirements.txt`.

## Branch and PR Checklist

- Keep schema changes additive and covered by `ai_os/migrations.py`.
- Add or update tests for route behavior, lifecycle changes, and serialization.
- Run `make ci` locally when practical.
- Do not commit `.env`, local SQLite databases, caches, or generated reports.
- Keep Gemini API access environment-based only; never hardcode secrets.
- Confirm the dashboard still loads at `/dashboard-ui`.
