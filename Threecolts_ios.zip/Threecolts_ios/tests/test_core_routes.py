from conftest import create_workflow


def test_health_startup_dashboard_and_static_reports(client):
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["status"] == "ok"
    assert health.json()["auth_enforced"] is False

    dashboard = client.get("/dashboard-ui")
    assert dashboard.status_code == 200
    assert "AI Operations Dashboard" in dashboard.text

    summary = client.get("/dashboard")
    assert summary.status_code == 200
    assert summary.json()["total_workflows"] == 0

    report = client.get("/report")
    assert report.status_code == 200
    assert "No workflows yet" in report.text

    csv_export = client.get("/export-csv")
    assert csv_export.status_code == 200
    assert "text/csv" in csv_export.headers["content-type"]


def test_workflow_creation_listing_detail_evidence_and_brief(client, workflow_payload):
    created = create_workflow(client, workflow_payload)
    assert created["team"] == "Customer Support"
    assert created["evidence_url"] == "https://example.test/evidence"
    assert created["approval_status"] == "Not Reviewed"
    assert created["score_breakdown"]["total"] == created["impact_score"]

    workflows = client.get("/workflows")
    assert workflows.status_code == 200
    assert len(workflows.json()) == 1

    detail = client.get(f"/workflows/{created['id']}")
    assert detail.status_code == 200
    body = detail.json()
    assert body["stage_history"][0]["stage"] == "New"
    assert body["comments"] == []
    assert body["automations"] == []
    assert body["decision_needed"] == "Approve pilot scope and owner."

    brief = client.get(f"/workflows/{created['id']}/brief")
    assert brief.status_code == 200
    assert "AI Opportunity CEO Brief" in brief.text
    assert "Automation Delivery" in brief.text
    assert "Approve pilot scope and owner" in brief.text


def test_csv_export_escapes_spreadsheet_formula_values(client, workflow_payload):
    workflow_payload["task_name"] = '=HYPERLINK("https://example.test")'
    created = create_workflow(client, workflow_payload)

    csv_export = client.get("/export-csv")
    assert csv_export.status_code == 200
    assert "'=HYPERLINK" in csv_export.text
    assert str(created["id"]) in csv_export.text
