from conftest import create_workflow


def test_automation_registry_update_run_history_and_reports(client, workflow_payload):
    workflow = create_workflow(client, workflow_payload)

    create_response = client.post(
        f"/workflows/{workflow['id']}/automations",
        json={
            "automation_name": "Ticket triage classifier",
            "owner": "Automation Lead",
            "automation_type": "AI Assistant",
            "status": "Testing",
            "human_approval_required": True,
            "quality_check_result": "Pass",
            "rollback_plan": "Disable classifier and return routing to support leads.",
            "monitoring_notes": "Daily review during pilot.",
        },
    )
    assert create_response.status_code == 200, create_response.text
    automation = create_response.json()
    assert automation["workflow_id"] == workflow["id"]
    assert automation["status"] == "Testing"
    assert automation["health_score"] >= 60

    listed = client.get("/automations")
    assert listed.status_code == 200
    assert listed.json()[0]["automation_name"] == "Ticket triage classifier"

    workflow_automations = client.get(f"/workflows/{workflow['id']}/automations")
    assert workflow_automations.status_code == 200
    assert len(workflow_automations.json()) == 1

    update = client.put(
        f"/automations/{automation['id']}",
        json={"status": "Live", "monitoring_notes": "Pilot passed; monitor weekly."},
    )
    assert update.status_code == 200
    assert update.json()["status"] == "Live"

    run_success = client.post(
        f"/automations/{automation['id']}/runs",
        json={"result": "Success", "quality_check_result": "Pass", "notes": "No exceptions."},
    )
    assert run_success.status_code == 200
    assert run_success.json()["automation"]["last_run_result"] == "Success"

    run_failed = client.post(
        f"/automations/{automation['id']}/runs",
        json={"result": "Failed", "quality_check_result": "Fail", "notes": "Source format changed."},
    )
    assert run_failed.status_code == 200
    failed_automation = run_failed.json()["automation"]
    assert failed_automation["status"] == "Failed"
    assert failed_automation["failure_count"] == 1
    assert failed_automation["needs_review"] is True

    runs = client.get(f"/automations/{automation['id']}/runs")
    assert runs.status_code == 200
    assert len(runs.json()) == 2

    detail = client.get(f"/automations/{automation['id']}")
    assert detail.status_code == 200
    assert len(detail.json()["runs"]) == 2

    report = client.get("/report")
    assert report.status_code == 200
    assert "Automation Delivery" in report.text
    assert "Ticket triage classifier" in report.text

    brief = client.get(f"/workflows/{workflow['id']}/brief")
    assert brief.status_code == 200
    assert "Ticket triage classifier" in brief.text

    dashboard = client.get("/dashboard-ui")
    assert dashboard.status_code == 200
    assert "Automation Registry" in dashboard.text
    assert "Ticket triage classifier" in dashboard.text
