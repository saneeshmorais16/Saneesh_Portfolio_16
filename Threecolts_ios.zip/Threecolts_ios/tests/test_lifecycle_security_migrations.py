from conftest import create_workflow
from sqlalchemy import text


def test_status_lifecycle_and_decision_layer(client, workflow_payload):
    workflow = create_workflow(client, workflow_payload)

    advanced = client.put(f"/advance-status/{workflow['id']}")
    assert advanced.status_code == 200
    assert advanced.json()["new_status"] == "Validation Needed"

    decision = client.put(
        f"/workflows/{workflow['id']}/decision",
        json={
            "approval_status": "Approved for Pilot",
            "decision_needed": "Build a monitored pilot with weekly checks.",
            "status": "Under Review",
        },
    )
    assert decision.status_code == 200
    data = decision.json()
    assert data["approval_status"] == "Approved for Pilot"
    assert data["status"] == "Under Review"
    assert data["decision_needed"] == "Build a monitored pilot with weekly checks."

    invalid_transition = client.put(
        f"/workflows/{workflow['id']}/decision",
        json={"approval_status": "Approved to Scale", "status": "Deployed"},
    )
    assert invalid_transition.status_code == 400


def test_role_headers_restrict_write_actions_without_api_key(client, workflow_payload):
    response = client.post(
        "/submit-workflow",
        json=workflow_payload,
        headers={"X-User-Role": "viewer"},
    )
    assert response.status_code == 403

    response = client.post(
        "/submit-workflow",
        json=workflow_payload,
        headers={"X-User-Role": "contributor", "X-Actor": "ops-user"},
    )
    assert response.status_code == 200

    lead_only = client.put(
        f"/advance-status/{response.json()['id']}",
        headers={"X-User-Role": "contributor"},
    )
    assert lead_only.status_code == 403


def test_api_key_is_required_when_configured(auth_client, workflow_payload):
    no_key = auth_client.post("/submit-workflow", json=workflow_payload)
    assert no_key.status_code == 401

    viewer = auth_client.post(
        "/submit-workflow",
        json=workflow_payload,
        headers={"X-API-Key": "test-secret", "X-User-Role": "viewer"},
    )
    assert viewer.status_code == 403

    admin = auth_client.post(
        "/submit-workflow",
        json=workflow_payload,
        headers={"X-API-Key": "test-secret", "X-User-Role": "admin"},
    )
    assert admin.status_code == 200


def test_migrations_are_idempotent_and_include_delivery_tables(client):
    from ai_os.database import engine_db
    from ai_os.migrations import init_database

    init_database()
    init_database()

    with engine_db.connect() as conn:
        workflow_columns = {row[1] for row in conn.execute(text("PRAGMA table_info(workflows)")).fetchall()}
        automation_columns = {row[1] for row in conn.execute(text("PRAGMA table_info(automations)")).fetchall()}
        run_columns = {row[1] for row in conn.execute(text("PRAGMA table_info(automation_runs)")).fetchall()}

    assert {"evidence_url", "approval_status", "decision_needed"}.issubset(workflow_columns)
    assert {"workflow_id", "automation_name", "health_score", "needs_review"}.issubset(automation_columns)
    assert {"automation_id", "result", "quality_check_result"}.issubset(run_columns)
