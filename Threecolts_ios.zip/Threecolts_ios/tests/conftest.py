import sys
from pathlib import Path
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient


def _clear_app_modules():
    for name in list(sys.modules):
        if name == "main" or name.startswith("ai_os"):
            del sys.modules[name]


def _database_url(path) -> str:
    return f"sqlite:///{path.as_posix()}"


def _runtime_db(name: str) -> Path:
    runtime_dir = Path.cwd() / "test_runtime"
    runtime_dir.mkdir(exist_ok=True)
    return runtime_dir / f"{name}_{uuid4().hex}.db"


@pytest.fixture()
def client(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", _database_url(_runtime_db("test_workflows")))
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.delenv("AI_OS_API_KEY", raising=False)
    _clear_app_modules()

    import main

    with TestClient(main.app) as test_client:
        yield test_client

    _clear_app_modules()


@pytest.fixture()
def auth_client(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", _database_url(_runtime_db("auth_workflows")))
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.setenv("AI_OS_API_KEY", "test-secret")
    _clear_app_modules()

    import main

    with TestClient(main.app) as test_client:
        yield test_client

    _clear_app_modules()


@pytest.fixture()
def workflow_payload():
    return {
        "team": "Customer Support",
        "task_name": "Manual ticket categorisation",
        "owner": "Support Lead",
        "affected_teams": "Support, Operations",
        "business_impact_type": "Employee Productivity",
        "time_spent_per_week": 12,
        "pain_level": 4,
        "frequency": "Daily",
        "baseline_cycle_time_minutes": 45,
        "target_cycle_time_minutes": 15,
        "expected_quality_gain_pct": 20,
        "notes": "Tickets are manually triaged before routing.",
        "evidence_url": "https://example.test/evidence",
        "baseline_evidence_url": "https://example.test/baseline",
        "measurement_owner": "Ops Analyst",
        "sample_size": 120,
        "decision_needed": "Approve pilot scope and owner.",
    }


def create_workflow(client, payload):
    response = client.post("/submit-workflow", json=payload)
    assert response.status_code == 200, response.text
    return response.json()
