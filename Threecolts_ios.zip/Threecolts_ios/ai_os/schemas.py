from typing import Optional

from pydantic import BaseModel, Field


class WorkflowInput(BaseModel):
    team: str = Field(..., min_length=1, max_length=100)
    task_name: str = Field(..., min_length=1, max_length=200)
    owner: Optional[str] = Field(default="", max_length=100)
    affected_teams: Optional[str] = Field(default="", max_length=500)
    business_impact_type: Optional[str] = Field(default="Employee Productivity", max_length=80)
    time_spent_per_week: int = Field(..., ge=0, le=168)
    pain_level: int = Field(..., ge=1, le=5)
    frequency: str = Field(..., min_length=1, max_length=100)
    baseline_cycle_time_minutes: Optional[float] = Field(default=0, ge=0, le=10080)
    target_cycle_time_minutes: Optional[float] = Field(default=0, ge=0, le=10080)
    expected_quality_gain_pct: Optional[int] = Field(default=0, ge=0, le=100)
    notes: Optional[str] = Field(default="", max_length=2000)
    evidence_url: Optional[str] = Field(default="", max_length=1000)
    baseline_evidence_url: Optional[str] = Field(default="", max_length=1000)
    after_evidence_url: Optional[str] = Field(default="", max_length=1000)
    measurement_owner: Optional[str] = Field(default="", max_length=100)
    sample_size: Optional[int] = Field(default=0, ge=0, le=1000000)
    approval_status: Optional[str] = Field(default="Not Reviewed", max_length=80)
    decision_needed: Optional[str] = Field(default="", max_length=1000)


class StatusInput(BaseModel):
    status: str


class ConfirmedSavingInput(BaseModel):
    confirmed_saving_hours: float = Field(..., ge=0, le=168)
    adoption_rate_pct: Optional[int] = Field(default=None, ge=0, le=100)
    quality_score_pct: Optional[int] = Field(default=None, ge=0, le=100)
    governance_notes: Optional[str] = Field(default=None, max_length=2000)
    after_evidence_url: Optional[str] = Field(default=None, max_length=1000)
    measurement_owner: Optional[str] = Field(default=None, max_length=100)
    sample_size: Optional[int] = Field(default=None, ge=0, le=1000000)
    approval_status: Optional[str] = Field(default=None, max_length=80)
    decision_needed: Optional[str] = Field(default=None, max_length=1000)


class WorkflowMeasurementInput(BaseModel):
    confirmed_saving_hours: Optional[float] = Field(default=None, ge=0, le=168)
    adoption_rate_pct: Optional[int] = Field(default=None, ge=0, le=100)
    quality_score_pct: Optional[int] = Field(default=None, ge=0, le=100)
    baseline_cycle_time_minutes: Optional[float] = Field(default=None, ge=0, le=10080)
    target_cycle_time_minutes: Optional[float] = Field(default=None, ge=0, le=10080)
    governance_notes: Optional[str] = Field(default=None, max_length=2000)
    evidence_url: Optional[str] = Field(default=None, max_length=1000)
    baseline_evidence_url: Optional[str] = Field(default=None, max_length=1000)
    after_evidence_url: Optional[str] = Field(default=None, max_length=1000)
    measurement_owner: Optional[str] = Field(default=None, max_length=100)
    sample_size: Optional[int] = Field(default=None, ge=0, le=1000000)
    approval_status: Optional[str] = Field(default=None, max_length=80)
    decision_needed: Optional[str] = Field(default=None, max_length=1000)


class DecisionInput(BaseModel):
    approval_status: str = Field(..., min_length=1, max_length=80)
    decision_needed: Optional[str] = Field(default=None, max_length=1000)
    governance_notes: Optional[str] = Field(default=None, max_length=2000)
    status: Optional[str] = Field(default=None, max_length=80)


class CommentInput(BaseModel):
    author: Optional[str] = Field(default="Anonymous", max_length=100)
    body: str = Field(..., min_length=1, max_length=2000)


class AutomationInput(BaseModel):
    automation_name: str = Field(..., min_length=1, max_length=200)
    owner: str = Field(..., min_length=1, max_length=100)
    automation_type: str = Field(default="Workflow", min_length=1, max_length=80)
    status: str = Field(default="Planned", min_length=1, max_length=80)
    human_approval_required: bool = True
    last_run_result: Optional[str] = Field(default="Not Run", max_length=80)
    failure_count: Optional[int] = Field(default=0, ge=0, le=1000000)
    quality_check_result: Optional[str] = Field(default="Not Checked", max_length=80)
    rollback_plan: Optional[str] = Field(default="", max_length=2000)
    monitoring_notes: Optional[str] = Field(default="", max_length=2000)
    health_score: Optional[int] = Field(default=None, ge=0, le=100)
    needs_review: Optional[bool] = None


class AutomationUpdateInput(BaseModel):
    automation_name: Optional[str] = Field(default=None, min_length=1, max_length=200)
    owner: Optional[str] = Field(default=None, min_length=1, max_length=100)
    automation_type: Optional[str] = Field(default=None, min_length=1, max_length=80)
    status: Optional[str] = Field(default=None, min_length=1, max_length=80)
    human_approval_required: Optional[bool] = None
    last_run_result: Optional[str] = Field(default=None, max_length=80)
    failure_count: Optional[int] = Field(default=None, ge=0, le=1000000)
    quality_check_result: Optional[str] = Field(default=None, max_length=80)
    rollback_plan: Optional[str] = Field(default=None, max_length=2000)
    monitoring_notes: Optional[str] = Field(default=None, max_length=2000)
    health_score: Optional[int] = Field(default=None, ge=0, le=100)
    needs_review: Optional[bool] = None


class AutomationRunInput(BaseModel):
    result: str = Field(..., min_length=1, max_length=80)
    quality_check_result: Optional[str] = Field(default="Pass", max_length=80)
    notes: Optional[str] = Field(default="", max_length=2000)
