from datetime import UTC, datetime

from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text

from .database import Base


def utc_now():
    return datetime.now(UTC).replace(tzinfo=None)


class WorkflowDB(Base):
    __tablename__ = "workflows"

    id = Column(Integer, primary_key=True, index=True)

    team = Column(String, default="")
    task_name = Column(String, default="")
    owner = Column(String, default="")
    affected_teams = Column(Text, default="")
    business_impact_type = Column(String, default="Employee Productivity")

    time_spent_per_week = Column(Integer, default=0)
    pain_level = Column(Integer, default=1)
    frequency = Column(String, default="")
    baseline_cycle_time_minutes = Column(Float, default=0.0)
    target_cycle_time_minutes = Column(Float, default=0.0)

    impact_score = Column(Integer, default=0)
    recommendation = Column(String, default="Low Priority")
    status = Column(String, default="New")
    score_breakdown_json = Column(Text, default="{}")

    notes = Column(Text, default="")

    ai_suggestion = Column(Text, default="")
    automation_plan = Column(Text, default="")
    prototype_plan_json = Column(Text, default="[]")

    estimated_effort_days = Column(Integer, default=10)
    confidence = Column(String, default="Medium")
    risk_level = Column(String, default="Medium")
    readiness_score = Column(Integer, default=50)

    confirmed_saving_hours = Column(Float, default=0.0)
    adoption_rate_pct = Column(Integer, default=0)
    quality_score_pct = Column(Integer, default=0)
    expected_quality_gain_pct = Column(Integer, default=0)
    governance_notes = Column(Text, default="")

    evidence_url = Column(Text, default="")
    baseline_evidence_url = Column(Text, default="")
    after_evidence_url = Column(Text, default="")
    measurement_owner = Column(String, default="")
    sample_size = Column(Integer, default=0)
    approval_status = Column(String, default="Not Reviewed")
    decision_needed = Column(Text, default="")

    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now)
    stage_entered_at = Column(DateTime, default=utc_now)
    stage_history = Column(Text, default="[]")


class EngineRunDB(Base):
    __tablename__ = "engine_runs"

    id = Column(Integer, primary_key=True, index=True)
    run_at = Column(DateTime, default=utc_now)

    analysed_workflows = Column(Integer, default=0)
    updated_workflows = Column(Integer, default=0)
    high_priority_moved_to_review = Column(Integer, default=0)
    medium_priority_moved_to_validation = Column(Integer, default=0)
    low_priority_moved_to_backlog = Column(Integer, default=0)
    protected_unchanged = Column(Integer, default=0)


class WorkflowCommentDB(Base):
    __tablename__ = "workflow_comments"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, index=True)
    author = Column(String, default="Anonymous")
    body = Column(Text, default="")
    created_at = Column(DateTime, default=utc_now)


class WorkflowAuditDB(Base):
    __tablename__ = "workflow_audit_events"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, index=True, nullable=True)
    actor = Column(String, default="system")
    role = Column(String, default="system")
    action = Column(String, default="")
    details_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=utc_now)


class AutomationDB(Base):
    __tablename__ = "automations"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, ForeignKey("workflows.id"), index=True, nullable=False)

    automation_name = Column(String, default="")
    owner = Column(String, default="")
    automation_type = Column(String, default="Workflow")
    status = Column(String, default="Planned")
    human_approval_required = Column(Boolean, default=True)

    last_run_at = Column(DateTime, nullable=True)
    last_run_result = Column(String, default="Not Run")
    failure_count = Column(Integer, default=0)
    quality_check_result = Column(String, default="Not Checked")
    rollback_plan = Column(Text, default="")
    monitoring_notes = Column(Text, default="")
    health_score = Column(Integer, default=50)
    needs_review = Column(Boolean, default=True)

    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now)


class AutomationRunDB(Base):
    __tablename__ = "automation_runs"

    id = Column(Integer, primary_key=True, index=True)
    automation_id = Column(Integer, ForeignKey("automations.id"), index=True, nullable=False)
    workflow_id = Column(Integer, ForeignKey("workflows.id"), index=True, nullable=False)

    run_at = Column(DateTime, default=utc_now)
    result = Column(String, default="Success")
    quality_check_result = Column(String, default="Pass")
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=utc_now)
