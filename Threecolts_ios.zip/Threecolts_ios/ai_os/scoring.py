from typing import Optional

from .config import PRIORITY_HIGH, PRIORITY_MEDIUM, VALID_BUSINESS_IMPACT_TYPES


def validate_business_impact_type(value: Optional[str]) -> str:
    if value in VALID_BUSINESS_IMPACT_TYPES:
        return value or "Employee Productivity"
    return "Employee Productivity"


def split_affected_teams(value: Optional[str]) -> list:
    return [item.strip() for item in (value or "").replace(";", ",").split(",") if item.strip()]


def calculate_opportunity_score(
    hours: int,
    pain: int,
    impact_type: str,
    affected_teams: str,
    confidence: str,
    risk: str,
    expected_quality_gain_pct: int = 0,
) -> tuple[int, dict]:
    hours_score = min(30, int((hours / 20) * 30)) if hours else 0
    pain_score = pain * 8
    team_count = len(split_affected_teams(affected_teams)) or 1
    reach_score = min(15, team_count * 5)
    impact_score = {
        "Cost Saving": 15,
        "Revenue Growth": 18,
        "Risk Reduction": 16,
        "Customer Experience": 14,
        "Employee Productivity": 12,
        "Quality Improvement": 13,
    }.get(impact_type, 12)
    quality_score = min(10, int((expected_quality_gain_pct or 0) / 10))
    confidence_adjustment = {"High": 6, "Medium": 3, "Low": -3}.get(confidence, 3)
    risk_adjustment = {"Low": 4, "Medium": 0, "High": -8}.get(risk, 0)

    total = max(
        0,
        min(
            100,
            hours_score
            + pain_score
            + reach_score
            + impact_score
            + quality_score
            + confidence_adjustment
            + risk_adjustment,
        ),
    )

    return total, {
        "manual_effort": hours_score,
        "pain": pain_score,
        "company_reach": reach_score,
        "business_impact": impact_score,
        "expected_quality_gain": quality_score,
        "confidence_adjustment": confidence_adjustment,
        "risk_adjustment": risk_adjustment,
        "total": total,
    }


def calculate_priority(score: int) -> str:
    if score >= PRIORITY_HIGH:
        return "High Priority"
    if score >= PRIORITY_MEDIUM:
        return "Medium Priority"
    return "Low Priority"


def get_badge_class(score: int) -> str:
    if score >= PRIORITY_HIGH:
        return "high"
    if score >= PRIORITY_MEDIUM:
        return "medium"
    return "low"


def calculate_readiness_score(hours: int, pain: int, risk: str, confidence: str) -> int:
    score = 40

    if hours >= 5:
        score += 20
    elif hours >= 2:
        score += 10

    score += pain * 5

    if confidence == "High":
        score += 15
    elif confidence == "Medium":
        score += 8

    if risk == "Low":
        score += 10
    elif risk == "High":
        score -= 10

    return max(0, min(score, 100))
