import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./workflows.db")


def _int_env(name: str, default: int, minimum: int = 0) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError:
        return default

    return max(minimum, value)


def _csv_env(name: str, default: list[str]) -> list[str]:
    raw = os.getenv(name, "")
    values = [item.strip() for item in raw.split(",") if item.strip()]
    return values or default


HOURLY_COST_GBP = _int_env("HOURLY_COST_GBP", 25, minimum=1)
CORS_ALLOWED_ORIGINS = _csv_env(
    "CORS_ALLOWED_ORIGINS",
    ["http://127.0.0.1:8000", "http://localhost:8000"],
)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
AI_OS_API_KEY = os.getenv("AI_OS_API_KEY", "")

PRIORITY_HIGH = 70
PRIORITY_MEDIUM = 45

VALID_STATUSES = [
    "New",
    "Backlog",
    "Validation Needed",
    "Under Review",
    "Prototype Built",
    "Pilot",
    "Scaling",
    "Deployed",
]

STATUS_TRANSITIONS = {
    "New": ["Backlog", "Validation Needed", "Under Review"],
    "Backlog": ["Validation Needed", "Under Review"],
    "Validation Needed": ["Under Review", "Backlog"],
    "Under Review": ["Prototype Built", "Backlog"],
    "Prototype Built": ["Pilot", "Under Review"],
    "Pilot": ["Scaling", "Prototype Built"],
    "Scaling": ["Deployed", "Pilot"],
    "Deployed": [],
}

VALID_BUSINESS_IMPACT_TYPES = [
    "Cost Saving",
    "Revenue Growth",
    "Risk Reduction",
    "Customer Experience",
    "Employee Productivity",
    "Quality Improvement",
]

VALID_ROLES = ["viewer", "contributor", "lead", "admin"]
WRITE_ROLES = ["contributor", "lead", "admin"]
LEAD_ROLES = ["lead", "admin"]

VALID_APPROVAL_STATUSES = [
    "Not Reviewed",
    "Needs Evidence",
    "Approved for Pilot",
    "Deferred",
    "Rejected",
    "Approved to Scale",
]

VALID_AUTOMATION_STATUSES = [
    "Planned",
    "Build",
    "Testing",
    "Live",
    "Paused",
    "Failed",
    "Retired",
]

VALID_AUTOMATION_RUN_RESULTS = [
    "Not Run",
    "Success",
    "Partial",
    "Failed",
    "Skipped",
]

VALID_QUALITY_CHECK_RESULTS = [
    "Pass",
    "Needs Review",
    "Fail",
    "Not Checked",
]
