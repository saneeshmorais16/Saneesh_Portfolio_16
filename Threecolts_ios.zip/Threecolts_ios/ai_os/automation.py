from .config import (
    VALID_AUTOMATION_RUN_RESULTS,
    VALID_AUTOMATION_STATUSES,
    VALID_QUALITY_CHECK_RESULTS,
)


def validate_automation_status(status: str) -> str:
    if status not in VALID_AUTOMATION_STATUSES:
        return "Planned"
    return status


def validate_run_result(result: str) -> str:
    if result not in VALID_AUTOMATION_RUN_RESULTS:
        return "Failed"
    return result


def validate_quality_check_result(result: str) -> str:
    if result not in VALID_QUALITY_CHECK_RESULTS:
        return "Needs Review"
    return result


def calculate_automation_health(
    status: str,
    failure_count: int,
    quality_check_result: str,
    last_run_result: str,
    rollback_plan: str,
) -> tuple[int, bool]:
    base_by_status = {
        "Planned": 45,
        "Build": 55,
        "Testing": 65,
        "Live": 85,
        "Paused": 40,
        "Failed": 25,
        "Retired": 70,
    }

    health = base_by_status.get(status, 45)
    health -= min(40, max(0, failure_count) * 10)

    if last_run_result == "Success":
        health += 5
    elif last_run_result == "Partial":
        health -= 5
    elif last_run_result == "Failed":
        health -= 15

    if quality_check_result == "Pass":
        health += 10
    elif quality_check_result == "Needs Review":
        health -= 10
    elif quality_check_result == "Fail":
        health -= 20

    if status in {"Live", "Testing"} and not rollback_plan.strip():
        health -= 5

    health = max(0, min(100, health))
    needs_review = (
        health < 60
        or last_run_result == "Failed"
        or quality_check_result in {"Fail", "Needs Review"}
        or status == "Failed"
    )

    return health, needs_review
