import json
from typing import Optional

from .models import WorkflowAuditDB
from .utils import now


def log_audit_event(
    db,
    workflow_id: Optional[int],
    actor: str,
    role: str,
    action: str,
    details: Optional[dict] = None,
):
    db.add(
        WorkflowAuditDB(
            workflow_id=workflow_id,
            actor=actor or "system",
            role=role or "system",
            action=action,
            details_json=json.dumps(details or {}),
            created_at=now(),
        )
    )
