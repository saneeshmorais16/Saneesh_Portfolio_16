import json

try:
    from google import genai
except ImportError:
    genai = None

from .config import GEMINI_API_KEY, GEMINI_MODEL


def keyword_analysis(task_name: str, team: str = "", notes: str = "") -> dict:
    text_value = f"{task_name} {team} {notes}".lower()

    result = {
        "suggestion": "AI workflow automation prototype",
        "automation_plan": "Map the workflow, identify repeatable rules, build a small prototype, test with users, and measure time saved.",
        "prototype_plan": [
            "Data needed: examples of the current manual workflow",
            "Prototype: automate the repeatable part of the process",
            "Success metric: reduce task completion time by at least 30%",
            "Risk: workflow may need human judgement in edge cases",
            "Human check: process owner validates prototype output",
        ],
        "estimated_effort_days": 10,
        "confidence": "Medium",
        "risk_level": "Medium",
    }

    if "ticket" in text_value or "support" in text_value or "categor" in text_value:
        result.update(
            {
                "suggestion": "AI ticket classifier with auto-routing",
                "automation_plan": "Collect historical tickets, define categories, build a classifier, test routing accuracy, and deploy with human approval for edge cases.",
                "prototype_plan": [
                    "Data needed: 100-300 historical support tickets",
                    "Prototype: classify tickets into categories and suggested routes",
                    "Success metric: reduce manual triage time by 40-60%",
                    "Risk: incorrect routing of urgent or sensitive tickets",
                    "Human check: support lead approves category logic",
                ],
                "estimated_effort_days": 7,
                "confidence": "High",
                "risk_level": "Medium",
            }
        )

    elif "report" in text_value or "spreadsheet" in text_value or "csv" in text_value:
        result.update(
            {
                "suggestion": "Automated reporting agent",
                "automation_plan": "Connect to source data, generate summary tables, produce written insights, and schedule recurring delivery.",
                "prototype_plan": [
                    "Data needed: sample weekly reports and source CSV files",
                    "Prototype: auto-generate summary tables and written insights",
                    "Success metric: reduce report preparation time by 50%",
                    "Risk: inaccurate figures if source data changes format",
                    "Human check: team owner validates report output",
                ],
                "estimated_effort_days": 5,
                "confidence": "High",
                "risk_level": "Medium",
            }
        )

    elif "meeting" in text_value or "notes" in text_value or "summary" in text_value:
        result.update(
            {
                "suggestion": "Meeting summary and action tracker",
                "automation_plan": "Capture meeting text, extract decisions and owners, create action items, and push them into a tracker.",
                "prototype_plan": [
                    "Data needed: meeting transcripts or notes",
                    "Prototype: extract decisions, action owners, and deadlines",
                    "Success metric: reduce follow-up admin time by 30-50%",
                    "Risk: missed context or incorrect action ownership",
                    "Human check: meeting owner confirms action list",
                ],
                "estimated_effort_days": 4,
                "confidence": "High",
                "risk_level": "Low",
            }
        )

    elif "document" in text_value or "sop" in text_value or "knowledge" in text_value or "faq" in text_value:
        result.update(
            {
                "suggestion": "Internal knowledge search assistant",
                "automation_plan": "Collect verified documents, index them, build retrieval-based Q&A, and require cited answers for validation.",
                "prototype_plan": [
                    "Data needed: SOPs, FAQs, policy docs, and internal guides",
                    "Prototype: searchable knowledge assistant with cited answers",
                    "Success metric: reduce repeated internal questions by 30%",
                    "Risk: outdated documents producing wrong answers",
                    "Human check: document owner validates answer quality",
                ],
                "estimated_effort_days": 12,
                "confidence": "Medium",
                "risk_level": "High",
            }
        )

    elif "feedback" in text_value or "review" in text_value or "sentiment" in text_value:
        result.update(
            {
                "suggestion": "Customer feedback sentiment analysis dashboard",
                "automation_plan": "Collect feedback, classify sentiment and recurring themes, then show trends and priority issues in a dashboard.",
                "prototype_plan": [
                    "Data needed: customer feedback, reviews, or survey comments",
                    "Prototype: sentiment and theme classification dashboard",
                    "Success metric: identify recurring pain points faster",
                    "Risk: sentiment misclassification on ambiguous feedback",
                    "Human check: customer success lead reviews themes",
                ],
                "estimated_effort_days": 6,
                "confidence": "High",
                "risk_level": "Low",
            }
        )

    elif "email" in text_value or "reply" in text_value or "inbox" in text_value:
        result.update(
            {
                "suggestion": "AI email triage and response assistant",
                "automation_plan": "Classify incoming emails, draft suggested replies, route urgent messages, and keep human approval before sending.",
                "prototype_plan": [
                    "Data needed: common email examples and response templates",
                    "Prototype: classify emails and draft suggested responses",
                    "Success metric: reduce first-response drafting time by 40%",
                    "Risk: sending unsuitable responses without review",
                    "Human check: all replies require approval before sending",
                ],
                "estimated_effort_days": 8,
                "confidence": "Medium",
                "risk_level": "High",
            }
        )

    return result


async def llm_analyse(task_name: str, team: str, hours: int, pain: int, notes: str) -> dict:
    fallback = keyword_analysis(task_name, team, notes)

    system_prompt = "You are an AI automation consultant. Return only valid JSON. No markdown."

    user_prompt = f"""
Analyse this workflow for AI automation potential.

Team: {team}
Task: {task_name}
Hours per week: {hours}
Pain level: {pain}/5
Notes: {notes or "None"}

Return JSON with exactly these keys:
suggestion, automation_plan, prototype_plan, estimated_effort_days, confidence, risk_level.

prototype_plan must be an array of exactly 5 strings.
confidence must be High, Medium, or Low.
risk_level must be Low, Medium, or High.
"""

    if GEMINI_API_KEY and genai is not None:
        try:
            client = genai.Client(api_key=GEMINI_API_KEY)
            response = client.models.generate_content(
                model=GEMINI_MODEL,
                contents=f"{system_prompt}\n\n{user_prompt}",
            )
            raw = getattr(response, "text", "") or ""
            clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            data = json.loads(clean)
            required = [
                "suggestion",
                "automation_plan",
                "prototype_plan",
                "estimated_effort_days",
                "confidence",
                "risk_level",
            ]

            if all(key in data for key in required):
                return data

        except Exception:
            return fallback

    return fallback
