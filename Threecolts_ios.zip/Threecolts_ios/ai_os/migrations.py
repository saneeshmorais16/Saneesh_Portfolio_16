import re

from sqlalchemy import text

from . import models  # noqa: F401 - ensures model metadata is registered
from .database import Base, engine_db

VALID_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _validate_identifier(value: str) -> str:
    if not VALID_IDENTIFIER.fullmatch(value):
        raise ValueError(f"Unsafe database identifier: {value}")
    return value


def _existing_columns(conn, table_name: str) -> set[str]:
    table_name = _validate_identifier(table_name)
    return {row[1] for row in conn.execute(text(f"PRAGMA table_info({table_name})")).fetchall()}


def _add_missing_columns(conn, table_name: str, columns_to_add: dict[str, str]) -> None:
    table_name = _validate_identifier(table_name)
    existing_columns = _existing_columns(conn, table_name)

    for column_name, definition in columns_to_add.items():
        column_name = _validate_identifier(column_name)
        if column_name not in existing_columns:
            conn.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"))


def migrate_database():
    workflow_columns_to_add = {
        "owner": "VARCHAR DEFAULT ''",
        "affected_teams": "TEXT DEFAULT ''",
        "business_impact_type": "VARCHAR DEFAULT 'Employee Productivity'",
        "notes": "TEXT DEFAULT ''",
        "ai_suggestion": "TEXT DEFAULT ''",
        "automation_plan": "TEXT DEFAULT ''",
        "prototype_plan_json": "TEXT DEFAULT '[]'",
        "estimated_effort_days": "INTEGER DEFAULT 10",
        "confidence": "VARCHAR DEFAULT 'Medium'",
        "risk_level": "VARCHAR DEFAULT 'Medium'",
        "readiness_score": "INTEGER DEFAULT 50",
        "confirmed_saving_hours": "REAL DEFAULT 0.0",
        "baseline_cycle_time_minutes": "REAL DEFAULT 0.0",
        "target_cycle_time_minutes": "REAL DEFAULT 0.0",
        "adoption_rate_pct": "INTEGER DEFAULT 0",
        "quality_score_pct": "INTEGER DEFAULT 0",
        "expected_quality_gain_pct": "INTEGER DEFAULT 0",
        "governance_notes": "TEXT DEFAULT ''",
        "evidence_url": "TEXT DEFAULT ''",
        "baseline_evidence_url": "TEXT DEFAULT ''",
        "after_evidence_url": "TEXT DEFAULT ''",
        "measurement_owner": "VARCHAR DEFAULT ''",
        "sample_size": "INTEGER DEFAULT 0",
        "approval_status": "VARCHAR DEFAULT 'Not Reviewed'",
        "decision_needed": "TEXT DEFAULT ''",
        "score_breakdown_json": "TEXT DEFAULT '{}'",
        "created_at": "DATETIME",
        "updated_at": "DATETIME",
        "stage_entered_at": "DATETIME",
        "stage_history": "TEXT DEFAULT '[]'",
    }

    automation_columns_to_add = {
        "workflow_id": "INTEGER NOT NULL DEFAULT 0",
        "automation_name": "VARCHAR DEFAULT ''",
        "owner": "VARCHAR DEFAULT ''",
        "automation_type": "VARCHAR DEFAULT 'Workflow'",
        "status": "VARCHAR DEFAULT 'Planned'",
        "human_approval_required": "BOOLEAN DEFAULT 1",
        "last_run_at": "DATETIME",
        "last_run_result": "VARCHAR DEFAULT 'Not Run'",
        "failure_count": "INTEGER DEFAULT 0",
        "quality_check_result": "VARCHAR DEFAULT 'Not Checked'",
        "rollback_plan": "TEXT DEFAULT ''",
        "monitoring_notes": "TEXT DEFAULT ''",
        "health_score": "INTEGER DEFAULT 50",
        "needs_review": "BOOLEAN DEFAULT 1",
        "created_at": "DATETIME",
        "updated_at": "DATETIME",
    }

    automation_run_columns_to_add = {
        "automation_id": "INTEGER NOT NULL DEFAULT 0",
        "workflow_id": "INTEGER NOT NULL DEFAULT 0",
        "run_at": "DATETIME",
        "result": "VARCHAR DEFAULT 'Success'",
        "quality_check_result": "VARCHAR DEFAULT 'Pass'",
        "notes": "TEXT DEFAULT ''",
        "created_at": "DATETIME",
    }

    with engine_db.begin() as conn:
        _add_missing_columns(conn, "workflows", workflow_columns_to_add)
        _add_missing_columns(conn, "automations", automation_columns_to_add)
        _add_missing_columns(conn, "automation_runs", automation_run_columns_to_add)


def init_database():
    Base.metadata.create_all(bind=engine_db)
    migrate_database()
