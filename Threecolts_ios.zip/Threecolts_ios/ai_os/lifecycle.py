from __future__ import annotations

import json
from typing import TYPE_CHECKING

from fastapi import HTTPException

from .config import PRIORITY_HIGH, PRIORITY_MEDIUM, STATUS_TRANSITIONS
from .utils import now, safe_json_loads

if TYPE_CHECKING:
    from .models import WorkflowDB


def get_status_class(status: str) -> str:
    return {
        "New": "s-new",
        "Backlog": "s-backlog",
        "Validation Needed": "s-validation",
        "Under Review": "s-review",
        "Prototype Built": "s-prototype",
        "Pilot": "s-pilot",
        "Scaling": "s-scaling",
        "Deployed": "s-deployed",
    }.get(status, "s-new")


def get_next_status(status: str) -> str:
    return {
        "New": "Validation Needed",
        "Backlog": "Validation Needed",
        "Validation Needed": "Under Review",
        "Under Review": "Prototype Built",
        "Prototype Built": "Pilot",
        "Pilot": "Scaling",
        "Scaling": "Deployed",
    }.get(status, "Deployed")


def get_action_label(status: str) -> str:
    return {
        "New": "Move to Review",
        "Backlog": "Validate",
        "Validation Needed": "Move to Review",
        "Under Review": "Mark Prototype",
        "Prototype Built": "Start Pilot",
        "Pilot": "Scale",
        "Scaling": "Mark Deployed",
        "Deployed": "Completed",
    }.get(status, "Completed")


def days_in_stage(stage_entered_at) -> int:
    if not stage_entered_at:
        return 0

    return max(0, (now() - stage_entered_at).days)


def record_stage_change(workflow: WorkflowDB, new_status: str):
    if new_status not in STATUS_TRANSITIONS.get(workflow.status or "New", []):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid transition from {workflow.status or 'New'} to {new_status}",
        )

    history = safe_json_loads(workflow.stage_history, [])

    if history and history[-1].get("exited") is None:
        history[-1]["exited"] = now().isoformat()

    history.append({"stage": new_status, "entered": now().isoformat(), "exited": None})

    workflow.stage_history = json.dumps(history)
    workflow.stage_entered_at = now()


def generate_next_step(score: int, status: str) -> str:
    if status == "Backlog":
        return "Keep documented until business value increases"

    if status == "Validation Needed":
        return "Validate with team owner"

    if status == "Under Review":
        return "Confirm owner and build prototype"

    if status == "Prototype Built":
        return "Start a measured pilot with named users"

    if status == "Pilot":
        return "Track adoption, quality, and savings"

    if status == "Scaling":
        return "Confirm controls and roll out company-wide"

    if status == "Deployed":
        return "Measure adoption and actual saving"

    if score >= PRIORITY_HIGH:
        return "Run engine and move to review"

    if score >= PRIORITY_MEDIUM:
        return "Run engine and validate"

    return "Run engine and place in backlog"
