import json
from datetime import UTC, datetime


def now():
    return datetime.now(UTC).replace(tzinfo=None)


def safe_json_loads(value, fallback):
    try:
        if value:
            return json.loads(value)
        return fallback
    except Exception:
        return fallback
