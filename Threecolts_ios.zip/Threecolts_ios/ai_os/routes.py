import csv
import io
import json

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse, PlainTextResponse, StreamingResponse

from .ai_analysis import llm_analyse
from .audit import log_audit_event
from .automation import (
    calculate_automation_health,
    validate_automation_status,
    validate_quality_check_result,
    validate_run_result,
)
from .briefs import generate_opportunity_brief
from .config import (
    AI_OS_API_KEY,
    HOURLY_COST_GBP,
    PRIORITY_HIGH,
    PRIORITY_MEDIUM,
    VALID_APPROVAL_STATUSES,
    VALID_STATUSES,
)
from .database import SessionLocal
from .lifecycle import days_in_stage, get_next_status, record_stage_change
from .models import AutomationDB, AutomationRunDB, EngineRunDB, WorkflowAuditDB, WorkflowCommentDB, WorkflowDB
from .schemas import (
    AutomationInput,
    AutomationRunInput,
    AutomationUpdateInput,
    CommentInput,
    ConfirmedSavingInput,
    DecisionInput,
    StatusInput,
    WorkflowInput,
    WorkflowMeasurementInput,
)
from .scoring import (
    calculate_opportunity_score,
    calculate_priority,
    calculate_readiness_score,
    validate_business_impact_type,
)
from .security import require_lead_access, require_write_access
from .serializers import automation_run_to_dict, automation_to_dict, workflow_to_dict
from .ui import render_dashboard_ui
from .utils import now, safe_json_loads

router = APIRouter()


def _get_workflow_or_404(db, workflow_id: int) -> WorkflowDB:
    workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

    if workflow is None:
        raise HTTPException(status_code=404, detail="Workflow not found")

    return workflow


def _get_automation_or_404(db, automation_id: int) -> AutomationDB:
    automation = db.query(AutomationDB).filter(AutomationDB.id == automation_id).first()

    if automation is None:
        raise HTTPException(status_code=404, detail="Automation not found")

    return automation


def _refresh_automation_health(automation: AutomationDB) -> None:
    health_score, needs_review = calculate_automation_health(
        automation.status or "Planned",
        automation.failure_count or 0,
        automation.quality_check_result or "Not Checked",
        automation.last_run_result or "Not Run",
        automation.rollback_plan or "",
    )
    automation.health_score = health_score
    automation.needs_review = needs_review


def _csv_safe(value):
    if value is None:
        return ""

    if not isinstance(value, str):
        return value

    if value.startswith(("=", "+", "-", "@")):
        return "'" + value

    return value


@router.get("/health")
def health():
    return {
        "status": "ok",
        "timestamp": now().isoformat(),
        "auth_enforced": bool(AI_OS_API_KEY),
    }


@router.get("/")
def home():
    return {
        "message": "Threecolts AI Automation Engine Ultimate is running",
        "dashboard": "/dashboard-ui",
    }


@router.post("/submit-workflow")
async def submit_workflow(data: WorkflowInput, auth: dict = Depends(require_write_access)):
    ai = await llm_analyse(
        data.task_name,
        data.team,
        data.time_spent_per_week,
        data.pain_level,
        data.notes or "",
    )

    impact_type = validate_business_impact_type(data.business_impact_type)
    impact_score, score_breakdown = calculate_opportunity_score(
        data.time_spent_per_week,
        data.pain_level,
        impact_type,
        data.affected_teams or data.team,
        ai.get("confidence", "Medium"),
        ai.get("risk_level", "Medium"),
        data.expected_quality_gain_pct or 0,
    )

    readiness = calculate_readiness_score(
        data.time_spent_per_week,
        data.pain_level,
        ai.get("risk_level", "Medium"),
        ai.get("confidence", "Medium"),
    )

    db = SessionLocal()

    try:
        current_time = now()

        workflow = WorkflowDB(
            team=data.team,
            task_name=data.task_name,
            owner=data.owner or "",
            affected_teams=data.affected_teams or data.team,
            business_impact_type=impact_type,
            time_spent_per_week=data.time_spent_per_week,
            pain_level=data.pain_level,
            frequency=data.frequency,
            baseline_cycle_time_minutes=data.baseline_cycle_time_minutes or 0,
            target_cycle_time_minutes=data.target_cycle_time_minutes or 0,
            impact_score=impact_score,
            recommendation=calculate_priority(impact_score),
            status="New",
            score_breakdown_json=json.dumps(score_breakdown),
            notes=data.notes or "",
            ai_suggestion=ai.get("suggestion", "AI workflow automation prototype"),
            automation_plan=ai.get("automation_plan", "Map the workflow and build a prototype."),
            prototype_plan_json=json.dumps(ai.get("prototype_plan", [])),
            estimated_effort_days=int(ai.get("estimated_effort_days", 10)),
            confidence=ai.get("confidence", "Medium"),
            risk_level=ai.get("risk_level", "Medium"),
            readiness_score=readiness,
            expected_quality_gain_pct=data.expected_quality_gain_pct or 0,
            evidence_url=data.evidence_url or "",
            baseline_evidence_url=data.baseline_evidence_url or "",
            after_evidence_url=data.after_evidence_url or "",
            measurement_owner=data.measurement_owner or "",
            sample_size=data.sample_size or 0,
            approval_status=data.approval_status or "Not Reviewed",
            decision_needed=data.decision_needed or "",
            created_at=current_time,
            updated_at=current_time,
            stage_entered_at=current_time,
            stage_history=json.dumps([{"stage": "New", "entered": current_time.isoformat(), "exited": None}]),
        )

        db.add(workflow)
        db.flush()
        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "workflow_created",
            {
                "impact_score": impact_score,
                "recommendation": calculate_priority(impact_score),
                "business_impact_type": impact_type,
            },
        )
        db.commit()
        db.refresh(workflow)

        return workflow_to_dict(workflow)

    finally:
        db.close()


@router.get("/workflows")
def get_workflows():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc()).all()

        return [workflow_to_dict(w) for w in workflows]

    finally:
        db.close()


@router.get("/workflows/{workflow_id}")
def get_workflow(workflow_id: int):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        comments = (
            db.query(WorkflowCommentDB)
            .filter(WorkflowCommentDB.workflow_id == workflow_id)
            .order_by(WorkflowCommentDB.created_at.asc())
            .all()
        )

        audit_events = (
            db.query(WorkflowAuditDB)
            .filter(WorkflowAuditDB.workflow_id == workflow_id)
            .order_by(WorkflowAuditDB.created_at.asc())
            .all()
        )

        automations = (
            db.query(AutomationDB)
            .filter(AutomationDB.workflow_id == workflow_id)
            .order_by(AutomationDB.updated_at.desc())
            .all()
        )

        data = workflow_to_dict(workflow)

        data["stage_history"] = safe_json_loads(workflow.stage_history, [])
        data["comments"] = [
            {
                "id": c.id,
                "author": c.author,
                "body": c.body,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in comments
        ]
        data["audit_events"] = [
            {
                "id": event.id,
                "actor": event.actor,
                "role": event.role,
                "action": event.action,
                "details": safe_json_loads(event.details_json, {}),
                "created_at": event.created_at.isoformat() if event.created_at else None,
            }
            for event in audit_events
        ]
        data["automations"] = [automation_to_dict(automation) for automation in automations]

        return data

    finally:
        db.close()


@router.get("/workflows/{workflow_id}/brief", response_class=PlainTextResponse)
def get_workflow_brief(workflow_id: int):
    db = SessionLocal()

    try:
        workflow = _get_workflow_or_404(db, workflow_id)
        automations = (
            db.query(AutomationDB)
            .filter(AutomationDB.workflow_id == workflow_id)
            .order_by(AutomationDB.updated_at.desc())
            .all()
        )

        return generate_opportunity_brief(workflow, automations)

    finally:
        db.close()


@router.post("/workflows/{workflow_id}/comments")
def add_comment(
    workflow_id: int,
    comment: CommentInput,
    auth: dict = Depends(require_write_access),
):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        new_comment = WorkflowCommentDB(
            workflow_id=workflow_id,
            author=comment.author or "Anonymous",
            body=comment.body,
            created_at=now(),
        )

        db.add(new_comment)
        log_audit_event(
            db,
            workflow_id,
            auth["actor"],
            auth["role"],
            "comment_added",
            {"author": comment.author or "Anonymous"},
        )
        db.commit()
        db.refresh(new_comment)

        return {"comment_id": new_comment.id}

    finally:
        db.close()


@router.put("/workflows/{workflow_id}/confirmed-saving")
def update_confirmed_saving(
    workflow_id: int,
    data: ConfirmedSavingInput,
    auth: dict = Depends(require_write_access),
):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        workflow.confirmed_saving_hours = data.confirmed_saving_hours
        if data.adoption_rate_pct is not None:
            workflow.adoption_rate_pct = data.adoption_rate_pct
        if data.quality_score_pct is not None:
            workflow.quality_score_pct = data.quality_score_pct
        if data.governance_notes is not None:
            workflow.governance_notes = data.governance_notes
        if data.after_evidence_url is not None:
            workflow.after_evidence_url = data.after_evidence_url
        if data.measurement_owner is not None:
            workflow.measurement_owner = data.measurement_owner
        if data.sample_size is not None:
            workflow.sample_size = data.sample_size
        if data.approval_status is not None:
            workflow.approval_status = data.approval_status
        if data.decision_needed is not None:
            workflow.decision_needed = data.decision_needed
        workflow.updated_at = now()

        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "measurement_updated",
            {
                "confirmed_saving_hours": workflow.confirmed_saving_hours,
                "adoption_rate_pct": workflow.adoption_rate_pct,
                "quality_score_pct": workflow.quality_score_pct,
            },
        )
        db.commit()
        db.refresh(workflow)

        estimated = (workflow.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP
        confirmed = data.confirmed_saving_hours * 52 * HOURLY_COST_GBP

        return {
            "workflow_id": workflow.id,
            "confirmed_annual_saving_gbp": confirmed,
            "estimated_annual_saving_gbp": estimated,
            "accuracy_pct": round((confirmed / estimated) * 100, 1) if estimated else 0,
            "adoption_rate_pct": workflow.adoption_rate_pct,
            "quality_score_pct": workflow.quality_score_pct,
        }

    finally:
        db.close()


@router.put("/workflows/{workflow_id}/measurement")
def update_measurement(
    workflow_id: int,
    data: WorkflowMeasurementInput,
    auth: dict = Depends(require_write_access),
):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        changed = {}

        for field in [
            "confirmed_saving_hours",
            "adoption_rate_pct",
            "quality_score_pct",
            "baseline_cycle_time_minutes",
            "target_cycle_time_minutes",
            "governance_notes",
            "evidence_url",
            "baseline_evidence_url",
            "after_evidence_url",
            "measurement_owner",
            "sample_size",
            "approval_status",
            "decision_needed",
        ]:
            value = getattr(data, field)
            if value is not None:
                setattr(workflow, field, value)
                changed[field] = value

        workflow.updated_at = now()

        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "measurement_updated",
            changed,
        )
        db.commit()
        db.refresh(workflow)

        return workflow_to_dict(workflow)

    finally:
        db.close()


@router.put("/workflows/{workflow_id}/decision")
def update_decision(
    workflow_id: int,
    data: DecisionInput,
    auth: dict = Depends(require_lead_access),
):
    if data.approval_status not in VALID_APPROVAL_STATUSES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid approval status. Use: {VALID_APPROVAL_STATUSES}",
        )

    if data.status is not None and data.status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail=f"Invalid status. Use: {VALID_STATUSES}")

    db = SessionLocal()

    try:
        workflow = _get_workflow_or_404(db, workflow_id)
        previous_status = workflow.status

        workflow.approval_status = data.approval_status
        if data.decision_needed is not None:
            workflow.decision_needed = data.decision_needed
        if data.governance_notes is not None:
            workflow.governance_notes = data.governance_notes

        if data.status is not None and data.status != workflow.status:
            record_stage_change(workflow, data.status)
            workflow.status = data.status

        workflow.updated_at = now()

        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "decision_updated",
            {
                "approval_status": workflow.approval_status,
                "status_from": previous_status,
                "status_to": workflow.status,
            },
        )
        db.commit()
        db.refresh(workflow)

        return workflow_to_dict(workflow)

    finally:
        db.close()


@router.post("/workflows/{workflow_id}/reanalyse")
async def reanalyse_workflow(workflow_id: int, auth: dict = Depends(require_write_access)):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        ai = await llm_analyse(
            workflow.task_name or "",
            workflow.team or "",
            workflow.time_spent_per_week or 0,
            workflow.pain_level or 1,
            workflow.notes or "",
        )

        workflow.ai_suggestion = ai.get("suggestion", workflow.ai_suggestion)
        workflow.automation_plan = ai.get("automation_plan", workflow.automation_plan)
        workflow.prototype_plan_json = json.dumps(
            ai.get("prototype_plan", safe_json_loads(workflow.prototype_plan_json, []))
        )
        workflow.estimated_effort_days = int(ai.get("estimated_effort_days", workflow.estimated_effort_days or 10))
        workflow.confidence = ai.get("confidence", workflow.confidence or "Medium")
        workflow.risk_level = ai.get("risk_level", workflow.risk_level or "Medium")
        impact_score, score_breakdown = calculate_opportunity_score(
            workflow.time_spent_per_week or 0,
            workflow.pain_level or 1,
            workflow.business_impact_type or "Employee Productivity",
            workflow.affected_teams or workflow.team or "",
            workflow.confidence or "Medium",
            workflow.risk_level or "Medium",
            workflow.expected_quality_gain_pct or 0,
        )
        workflow.impact_score = impact_score
        workflow.recommendation = calculate_priority(impact_score)
        workflow.score_breakdown_json = json.dumps(score_breakdown)

        workflow.readiness_score = calculate_readiness_score(
            workflow.time_spent_per_week or 0,
            workflow.pain_level or 1,
            workflow.risk_level or "Medium",
            workflow.confidence or "Medium",
        )

        workflow.updated_at = now()

        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "workflow_reanalysed",
            {"impact_score": workflow.impact_score, "recommendation": workflow.recommendation},
        )
        db.commit()
        db.refresh(workflow)

        return workflow_to_dict(workflow)

    finally:
        db.close()


@router.put("/update-status/{workflow_id}")
def update_status(
    workflow_id: int,
    status_input: StatusInput,
    auth: dict = Depends(require_lead_access),
):
    if status_input.status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail=f"Invalid status. Use: {VALID_STATUSES}")

    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        if workflow.status != status_input.status:
            previous_status = workflow.status
            record_stage_change(workflow, status_input.status)
            log_audit_event(
                db,
                workflow.id,
                auth["actor"],
                auth["role"],
                "status_changed",
                {"from": previous_status, "to": status_input.status},
            )

        workflow.status = status_input.status
        workflow.updated_at = now()

        db.commit()
        db.refresh(workflow)

        return {"workflow_id": workflow.id, "status": workflow.status}

    finally:
        db.close()


@router.put("/advance-status/{workflow_id}")
def advance_status(workflow_id: int, auth: dict = Depends(require_lead_access)):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        new_status = get_next_status(workflow.status or "New")

        if workflow.status != new_status:
            previous_status = workflow.status
            record_stage_change(workflow, new_status)
            workflow.status = new_status
            workflow.updated_at = now()
            log_audit_event(
                db,
                workflow.id,
                auth["actor"],
                auth["role"],
                "status_advanced",
                {"from": previous_status, "to": new_status},
            )

            db.commit()
            db.refresh(workflow)

        return {"workflow_id": workflow.id, "new_status": workflow.status}

    finally:
        db.close()


@router.delete("/delete-workflow/{workflow_id}")
def delete_workflow(workflow_id: int, auth: dict = Depends(require_lead_access)):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        db.query(WorkflowCommentDB).filter(WorkflowCommentDB.workflow_id == workflow_id).delete()
        db.query(AutomationRunDB).filter(AutomationRunDB.workflow_id == workflow_id).delete()
        db.query(AutomationDB).filter(AutomationDB.workflow_id == workflow_id).delete()
        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "workflow_deleted",
            {
                "team": workflow.team,
                "task_name": workflow.task_name,
                "status": workflow.status,
            },
        )

        db.delete(workflow)
        db.commit()

        return {"message": "Workflow deleted successfully"}

    finally:
        db.close()


@router.post("/workflows/{workflow_id}/automations")
def create_workflow_automation(
    workflow_id: int,
    data: AutomationInput,
    auth: dict = Depends(require_lead_access),
):
    db = SessionLocal()

    try:
        workflow = _get_workflow_or_404(db, workflow_id)
        status = validate_automation_status(data.status)
        last_run_result = validate_run_result(data.last_run_result or "Skipped")
        quality_result = validate_quality_check_result(data.quality_check_result or "Not Checked")

        automation = AutomationDB(
            workflow_id=workflow.id,
            automation_name=data.automation_name,
            owner=data.owner,
            automation_type=data.automation_type,
            status=status,
            human_approval_required=data.human_approval_required,
            last_run_result=last_run_result if last_run_result != "Skipped" else "Not Run",
            failure_count=data.failure_count or 0,
            quality_check_result=quality_result,
            rollback_plan=data.rollback_plan or "",
            monitoring_notes=data.monitoring_notes or "",
            created_at=now(),
            updated_at=now(),
        )

        if data.health_score is not None:
            automation.health_score = data.health_score
            automation.needs_review = data.needs_review if data.needs_review is not None else data.health_score < 60
        else:
            _refresh_automation_health(automation)
            if data.needs_review is not None:
                automation.needs_review = data.needs_review

        db.add(automation)
        db.flush()
        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "automation_created",
            {
                "automation_id": automation.id,
                "automation_name": automation.automation_name,
                "status": automation.status,
                "health_score": automation.health_score,
            },
        )
        db.commit()
        db.refresh(automation)

        return automation_to_dict(automation, workflow)

    finally:
        db.close()


@router.get("/workflows/{workflow_id}/automations")
def get_workflow_automations(workflow_id: int):
    db = SessionLocal()

    try:
        workflow = _get_workflow_or_404(db, workflow_id)
        automations = (
            db.query(AutomationDB)
            .filter(AutomationDB.workflow_id == workflow_id)
            .order_by(AutomationDB.updated_at.desc())
            .all()
        )

        return [automation_to_dict(automation, workflow) for automation in automations]

    finally:
        db.close()


@router.get("/automations")
def get_automations(needs_review: bool | None = None):
    db = SessionLocal()

    try:
        query = db.query(AutomationDB)
        if needs_review is not None:
            query = query.filter(AutomationDB.needs_review == needs_review)

        automations = query.order_by(AutomationDB.health_score.asc(), AutomationDB.updated_at.desc()).all()
        workflow_ids = {automation.workflow_id for automation in automations}
        workflows = (
            {workflow.id: workflow for workflow in db.query(WorkflowDB).filter(WorkflowDB.id.in_(workflow_ids)).all()}
            if workflow_ids
            else {}
        )

        return [automation_to_dict(automation, workflows.get(automation.workflow_id)) for automation in automations]

    finally:
        db.close()


@router.get("/automations/{automation_id}")
def get_automation(automation_id: int):
    db = SessionLocal()

    try:
        automation = _get_automation_or_404(db, automation_id)
        workflow = _get_workflow_or_404(db, automation.workflow_id)
        runs = (
            db.query(AutomationRunDB)
            .filter(AutomationRunDB.automation_id == automation_id)
            .order_by(AutomationRunDB.run_at.desc())
            .limit(20)
            .all()
        )
        data = automation_to_dict(automation, workflow)
        data["runs"] = [automation_run_to_dict(run) for run in runs]

        return data

    finally:
        db.close()


@router.put("/automations/{automation_id}")
def update_automation(
    automation_id: int,
    data: AutomationUpdateInput,
    auth: dict = Depends(require_lead_access),
):
    db = SessionLocal()

    try:
        automation = _get_automation_or_404(db, automation_id)
        workflow = _get_workflow_or_404(db, automation.workflow_id)
        changed = {}

        for field in [
            "automation_name",
            "owner",
            "automation_type",
            "human_approval_required",
            "rollback_plan",
            "monitoring_notes",
        ]:
            value = getattr(data, field)
            if value is not None:
                setattr(automation, field, value)
                changed[field] = value

        if data.status is not None:
            automation.status = validate_automation_status(data.status)
            changed["status"] = automation.status
        if data.last_run_result is not None:
            automation.last_run_result = validate_run_result(data.last_run_result)
            changed["last_run_result"] = automation.last_run_result
        if data.failure_count is not None:
            automation.failure_count = data.failure_count
            changed["failure_count"] = data.failure_count
        if data.quality_check_result is not None:
            automation.quality_check_result = validate_quality_check_result(data.quality_check_result)
            changed["quality_check_result"] = automation.quality_check_result

        if data.health_score is not None:
            automation.health_score = data.health_score
            automation.needs_review = data.needs_review if data.needs_review is not None else data.health_score < 60
        else:
            _refresh_automation_health(automation)
            if data.needs_review is not None:
                automation.needs_review = data.needs_review

        automation.updated_at = now()

        log_audit_event(
            db,
            automation.workflow_id,
            auth["actor"],
            auth["role"],
            "automation_updated",
            {"automation_id": automation.id, **changed, "health_score": automation.health_score},
        )
        db.commit()
        db.refresh(automation)

        return automation_to_dict(automation, workflow)

    finally:
        db.close()


@router.post("/automations/{automation_id}/runs")
def record_automation_run(
    automation_id: int,
    data: AutomationRunInput,
    auth: dict = Depends(require_write_access),
):
    db = SessionLocal()

    try:
        automation = _get_automation_or_404(db, automation_id)
        workflow = _get_workflow_or_404(db, automation.workflow_id)
        result = validate_run_result(data.result)
        quality_result = validate_quality_check_result(data.quality_check_result or "Not Checked")
        current_time = now()

        run = AutomationRunDB(
            automation_id=automation.id,
            workflow_id=automation.workflow_id,
            run_at=current_time,
            result=result,
            quality_check_result=quality_result,
            notes=data.notes or "",
            created_at=current_time,
        )
        db.add(run)

        automation.last_run_at = current_time
        automation.last_run_result = result
        automation.quality_check_result = quality_result
        if result == "Failed":
            automation.failure_count = (automation.failure_count or 0) + 1
            automation.status = "Failed"
        elif automation.status == "Failed" and result in {"Success", "Partial"}:
            automation.status = "Testing"

        automation.updated_at = current_time
        _refresh_automation_health(automation)

        log_audit_event(
            db,
            automation.workflow_id,
            auth["actor"],
            auth["role"],
            "automation_run_recorded",
            {
                "automation_id": automation.id,
                "result": result,
                "quality_check_result": quality_result,
                "health_score": automation.health_score,
                "needs_review": automation.needs_review,
            },
        )
        db.commit()
        db.refresh(automation)
        db.refresh(run)

        return {
            "automation": automation_to_dict(automation, workflow),
            "run": automation_run_to_dict(run),
        }

    finally:
        db.close()


@router.get("/automations/{automation_id}/runs")
def get_automation_runs(automation_id: int, limit: int = 20):
    db = SessionLocal()

    try:
        _get_automation_or_404(db, automation_id)
        runs = (
            db.query(AutomationRunDB)
            .filter(AutomationRunDB.automation_id == automation_id)
            .order_by(AutomationRunDB.run_at.desc())
            .limit(min(max(limit, 1), 100))
            .all()
        )

        return [automation_run_to_dict(run) for run in runs]

    finally:
        db.close()


@router.post("/run-automation-engine")
def run_automation_engine(auth: dict = Depends(require_lead_access)):
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).all()

        analysed = len(workflows)
        updated = 0
        high = 0
        medium = 0
        low = 0
        protected = 0

        for workflow in workflows:
            score, score_breakdown = calculate_opportunity_score(
                workflow.time_spent_per_week or 0,
                workflow.pain_level or 1,
                workflow.business_impact_type or "Employee Productivity",
                workflow.affected_teams or workflow.team or "",
                workflow.confidence or "Medium",
                workflow.risk_level or "Medium",
                workflow.expected_quality_gain_pct or 0,
            )
            workflow.impact_score = score
            workflow.recommendation = calculate_priority(score)
            workflow.score_breakdown_json = json.dumps(score_breakdown)
            current_status = workflow.status or "New"

            if current_status not in ["New", "Backlog", "Validation Needed"]:
                protected += 1
                continue

            if score >= PRIORITY_HIGH:
                new_status = "Under Review"
                high += 1
            elif score >= PRIORITY_MEDIUM:
                new_status = "Validation Needed"
                medium += 1
            else:
                new_status = "Backlog"
                low += 1

            if new_status != current_status:
                record_stage_change(workflow, new_status)
                workflow.status = new_status
                workflow.updated_at = now()
                log_audit_event(
                    db,
                    workflow.id,
                    auth["actor"],
                    auth["role"],
                    "engine_status_classified",
                    {"from": current_status, "to": new_status, "score": score},
                )
                updated += 1

        run = EngineRunDB(
            run_at=now(),
            analysed_workflows=analysed,
            updated_workflows=updated,
            high_priority_moved_to_review=high,
            medium_priority_moved_to_validation=medium,
            low_priority_moved_to_backlog=low,
            protected_unchanged=protected,
        )

        db.add(run)
        log_audit_event(
            db,
            None,
            auth["actor"],
            auth["role"],
            "engine_run",
            {
                "analysed": analysed,
                "updated": updated,
                "to_review": high,
                "to_validation": medium,
                "to_backlog": low,
                "protected": protected,
            },
        )
        db.commit()
        db.refresh(run)

        return {
            "message": "Automation engine completed",
            "run_id": run.id,
            "analysed": analysed,
            "updated": updated,
            "to_review": high,
            "to_validation": medium,
            "to_backlog": low,
            "protected": protected,
        }

    finally:
        db.close()


@router.get("/engine-runs")
def get_engine_runs(limit: int = 10):
    db = SessionLocal()

    try:
        runs = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).limit(limit).all()

        return [
            {
                "id": r.id,
                "run_at": r.run_at.isoformat() if r.run_at else None,
                "analysed": r.analysed_workflows,
                "updated": r.updated_workflows,
                "to_review": r.high_priority_moved_to_review,
                "to_validation": r.medium_priority_moved_to_validation,
                "to_backlog": r.low_priority_moved_to_backlog,
                "protected": r.protected_unchanged,
            }
            for r in runs
        ]

    finally:
        db.close()


@router.get("/executive-summary")
def executive_summary():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).all()
        automations = db.query(AutomationDB).all()

        deployed = [w for w in workflows if (w.status or "") == "Deployed"]

        in_progress = [
            w
            for w in workflows
            if (w.status or "") in ["Validation Needed", "Under Review", "Prototype Built", "Pilot", "Scaling"]
        ]

        high_priority = [w for w in workflows if (w.impact_score or 0) >= PRIORITY_HIGH]

        active_measurements = [w for w in workflows if (w.status or "") in ["Pilot", "Scaling", "Deployed"]]

        measured_adoption = [w.adoption_rate_pct or 0 for w in active_measurements if (w.adoption_rate_pct or 0) > 0]

        measured_quality = [w.quality_score_pct or 0 for w in active_measurements if (w.quality_score_pct or 0) > 0]

        high_risk = [w for w in workflows if (w.risk_level or "Medium") == "High"]
        overdue_reviews = [
            w
            for w in workflows
            if days_in_stage(w.stage_entered_at) > 14 and (w.status or "") not in ["Backlog", "Deployed"]
        ]
        decision_needed = [
            w
            for w in workflows
            if (w.approval_status or "Not Reviewed") in ["Not Reviewed", "Needs Evidence"]
            and (w.status or "") in ["Under Review", "Prototype Built", "Pilot"]
        ]
        missing_evidence = [
            w for w in workflows if not (w.evidence_url or w.baseline_evidence_url or w.after_evidence_url)
        ]
        automation_health_values = [automation.health_score or 0 for automation in automations]

        impact_mix = {}

        for w in workflows:
            impact_type = w.business_impact_type or "Employee Productivity"
            impact_mix[impact_type] = impact_mix.get(impact_type, 0) + 1

        estimated = sum(w.time_spent_per_week or 0 for w in workflows) * 52 * HOURLY_COST_GBP

        confirmed = sum((w.confirmed_saving_hours or 0) for w in deployed) * 52 * HOURLY_COST_GBP

        deploy_days = [(now() - w.created_at).days for w in deployed if w.created_at]

        average_days_to_deploy = round(sum(deploy_days) / len(deploy_days), 1) if deploy_days else 0

        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()

        top_wins = sorted(deployed, key=lambda x: x.confirmed_saving_hours or 0, reverse=True)[:5]

        return {
            "summary": {
                "total_workflows": len(workflows),
                "deployed": len(deployed),
                "in_progress": len(in_progress),
                "high_priority": len(high_priority),
                "high_risk": len(high_risk),
                "pilots_or_scaling": len(active_measurements),
                "decision_needed": len(decision_needed),
                "overdue_reviews": len(overdue_reviews),
                "missing_evidence": len(missing_evidence),
                "average_days_to_deploy": average_days_to_deploy,
            },
            "roi": {
                "estimated_annual_saving_gbp": estimated,
                "confirmed_annual_saving_gbp": confirmed,
                "accuracy_pct": round((confirmed / estimated) * 100, 1) if estimated else 0,
                "hourly_rate_gbp": HOURLY_COST_GBP,
            },
            "operating_metrics": {
                "average_adoption_rate_pct": round(sum(measured_adoption) / len(measured_adoption), 1)
                if measured_adoption
                else 0,
                "average_quality_score_pct": round(sum(measured_quality) / len(measured_quality), 1)
                if measured_quality
                else 0,
                "impact_mix": impact_mix,
                "evidence_coverage_pct": round(((len(workflows) - len(missing_evidence)) / len(workflows)) * 100, 1)
                if workflows
                else 0,
                "auth_enforced": bool(AI_OS_API_KEY),
            },
            "automation_delivery": {
                "total_automations": len(automations),
                "live_automations": sum(1 for automation in automations if (automation.status or "") == "Live"),
                "needs_review": sum(1 for automation in automations if automation.needs_review),
                "average_health_score": round(sum(automation_health_values) / len(automation_health_values), 1)
                if automation_health_values
                else 0,
            },
            "top_deployed_wins": [workflow_to_dict(w) for w in top_wins],
            "last_engine_run": {
                "run_at": last_run.run_at.isoformat() if last_run and last_run.run_at else "Never",
                "analysed": last_run.analysed_workflows if last_run else 0,
                "updated": last_run.updated_workflows if last_run else 0,
            },
        }

    finally:
        db.close()


@router.get("/dashboard")
def dashboard():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).all()
        automations = db.query(AutomationDB).all()

        deployed = [w for w in workflows if (w.status or "") == "Deployed"]

        in_progress = [
            w for w in workflows if (w.status or "") in ["Validation Needed", "Under Review", "Prototype Built"]
        ]

        estimated = sum(w.time_spent_per_week or 0 for w in workflows) * 52 * HOURLY_COST_GBP

        confirmed = sum((w.confirmed_saving_hours or 0) for w in deployed) * 52 * HOURLY_COST_GBP

        adoption_values = [w.adoption_rate_pct or 0 for w in workflows if (w.adoption_rate_pct or 0) > 0]

        quality_values = [w.quality_score_pct or 0 for w in workflows if (w.quality_score_pct or 0) > 0]
        automation_health_values = [automation.health_score or 0 for automation in automations]

        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()

        return {
            "total_workflows": len(workflows),
            "estimated_yearly_saving_gbp": estimated,
            "confirmed_annual_saving_gbp": confirmed,
            "in_progress": len(in_progress),
            "deployed": len(deployed),
            "average_adoption_rate_pct": round(sum(adoption_values) / len(adoption_values), 1)
            if adoption_values
            else 0,
            "average_quality_score_pct": round(sum(quality_values) / len(quality_values), 1) if quality_values else 0,
            "high_risk_workflows": sum(1 for w in workflows if (w.risk_level or "Medium") == "High"),
            "decision_needed": sum(
                1
                for w in workflows
                if (w.approval_status or "Not Reviewed") in ["Not Reviewed", "Needs Evidence"]
                and (w.status or "") in ["Under Review", "Prototype Built", "Pilot"]
            ),
            "overdue_reviews": sum(
                1
                for w in workflows
                if days_in_stage(w.stage_entered_at) > 14 and (w.status or "") not in ["Backlog", "Deployed"]
            ),
            "automation_count": len(automations),
            "automation_needs_review": sum(1 for automation in automations if automation.needs_review),
            "automation_average_health_score": round(sum(automation_health_values) / len(automation_health_values), 1)
            if automation_health_values
            else 0,
            "last_engine_run": last_run.run_at.isoformat() if last_run and last_run.run_at else "Never",
        }

    finally:
        db.close()


@router.get("/export-csv")
def export_csv():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc()).all()
        automations = db.query(AutomationDB).all()
        automations_by_workflow = {}
        for automation in automations:
            automations_by_workflow.setdefault(automation.workflow_id, []).append(automation)

        buffer = io.StringIO()
        writer = csv.writer(buffer)

        writer.writerow(
            [
                "ID",
                "Team",
                "Workflow",
                "Owner",
                "Affected Teams",
                "Business Impact Type",
                "Status",
                "Hours/Week",
                "Pain",
                "Baseline Cycle Time Minutes",
                "Target Cycle Time Minutes",
                "Impact Score",
                "Score Breakdown",
                "Priority",
                "AI Suggestion",
                "Automation Plan",
                "Prototype Plan",
                "Effort Days",
                "Confidence",
                "Risk",
                "Readiness",
                "Expected Quality Gain %",
                "Estimated Annual Saving GBP",
                "Confirmed Weekly Saving Hours",
                "Confirmed Annual Saving GBP",
                "Adoption Rate %",
                "Quality Score %",
                "Governance Notes",
                "Evidence URL",
                "Baseline Evidence URL",
                "After Evidence URL",
                "Measurement Owner",
                "Sample Size",
                "Approval Status",
                "Decision Needed",
                "Automation Count",
                "Live Automations",
                "Automation Needs Review",
                "Average Automation Health",
                "Automation Names",
            ]
        )

        for w in workflows:
            workflow_automations = automations_by_workflow.get(w.id, [])
            automation_health_values = [automation.health_score or 0 for automation in workflow_automations]
            writer.writerow(
                [
                    w.id,
                    _csv_safe(w.team),
                    _csv_safe(w.task_name),
                    _csv_safe(w.owner),
                    _csv_safe(w.affected_teams),
                    _csv_safe(w.business_impact_type),
                    _csv_safe(w.status),
                    w.time_spent_per_week,
                    w.pain_level,
                    w.baseline_cycle_time_minutes,
                    w.target_cycle_time_minutes,
                    w.impact_score,
                    _csv_safe(w.score_breakdown_json),
                    _csv_safe(w.recommendation),
                    _csv_safe(w.ai_suggestion),
                    _csv_safe(w.automation_plan),
                    _csv_safe(" | ".join(safe_json_loads(w.prototype_plan_json, []))),
                    w.estimated_effort_days,
                    _csv_safe(w.confidence),
                    _csv_safe(w.risk_level),
                    w.readiness_score,
                    w.expected_quality_gain_pct,
                    (w.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP,
                    w.confirmed_saving_hours,
                    (w.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP,
                    w.adoption_rate_pct,
                    w.quality_score_pct,
                    _csv_safe(w.governance_notes),
                    _csv_safe(w.evidence_url),
                    _csv_safe(w.baseline_evidence_url),
                    _csv_safe(w.after_evidence_url),
                    _csv_safe(w.measurement_owner),
                    w.sample_size,
                    _csv_safe(w.approval_status),
                    _csv_safe(w.decision_needed),
                    len(workflow_automations),
                    sum(1 for automation in workflow_automations if (automation.status or "") == "Live"),
                    sum(1 for automation in workflow_automations if automation.needs_review),
                    round(sum(automation_health_values) / len(automation_health_values), 1)
                    if automation_health_values
                    else 0,
                    _csv_safe(" | ".join(automation.automation_name or "" for automation in workflow_automations)),
                ]
            )

        buffer.seek(0)

        return StreamingResponse(
            iter([buffer.getvalue()]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=threecolts_ai_automation_export.csv"},
        )

    finally:
        db.close()


@router.get("/report", response_class=PlainTextResponse)
def generate_report():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc()).all()
        automations = db.query(AutomationDB).all()
        automations_by_workflow = {}
        for automation in automations:
            automations_by_workflow.setdefault(automation.workflow_id, []).append(automation)

        if not workflows:
            return "AI Impact OS\n\nNo workflows yet."

        estimated = sum(w.time_spent_per_week or 0 for w in workflows) * 52 * HOURLY_COST_GBP
        deployed = [w for w in workflows if (w.status or "") == "Deployed"]
        confirmed = sum((w.confirmed_saving_hours or 0) for w in deployed) * 52 * HOURLY_COST_GBP
        adoption_values = [w.adoption_rate_pct or 0 for w in workflows if (w.adoption_rate_pct or 0) > 0]
        quality_values = [w.quality_score_pct or 0 for w in workflows if (w.quality_score_pct or 0) > 0]
        missing_evidence = [
            w for w in workflows if not (w.evidence_url or w.baseline_evidence_url or w.after_evidence_url)
        ]
        decision_needed = [
            w
            for w in workflows
            if (w.approval_status or "Not Reviewed") in ["Not Reviewed", "Needs Evidence"]
            and (w.status or "") in ["Under Review", "Prototype Built", "Pilot"]
        ]
        overdue_reviews = [
            w
            for w in workflows
            if days_in_stage(w.stage_entered_at) > 14 and (w.status or "") not in ["Backlog", "Deployed"]
        ]
        automation_health_values = [automation.health_score or 0 for automation in automations]

        impact_mix = {}
        for workflow in workflows:
            impact_type = workflow.business_impact_type or "Employee Productivity"
            impact_mix[impact_type] = impact_mix.get(impact_type, 0) + 1

        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()

        lines = [
            "AI Impact OS Executive Report",
            "=" * 60,
            "",
            f"Total workflows: {len(workflows)}",
            f"Deployed workflows: {len(deployed)}",
            f"Estimated annual saving: GBP {estimated:,}",
            f"Confirmed annual saving: GBP {confirmed:,.0f}",
            f"Hourly value assumption: GBP {HOURLY_COST_GBP}/hour",
            "",
            f"Average adoption: {round(sum(adoption_values) / len(adoption_values), 1) if adoption_values else 0}%",
            f"Average quality score: {round(sum(quality_values) / len(quality_values), 1) if quality_values else 0}%",
            f"High risk workflows: {sum(1 for w in workflows if (w.risk_level or 'Medium') == 'High')}",
            f"Workflows missing evidence: {len(missing_evidence)}",
            f"Decision-needed items: {len(decision_needed)}",
            f"Overdue reviews: {len(overdue_reviews)}",
            f"Impact mix: {', '.join(f'{k}: {v}' for k, v in sorted(impact_mix.items()))}",
            "",
            "Automation Delivery",
            "-" * 60,
            f"Registered automations: {len(automations)}",
            f"Live automations: {sum(1 for automation in automations if (automation.status or '') == 'Live')}",
            f"Automations needing review: {sum(1 for automation in automations if automation.needs_review)}",
            "Average automation health: "
            f"{round(sum(automation_health_values) / len(automation_health_values), 1) if automation_health_values else 0}%",
            "",
            "Last Automation Engine Run",
            "-" * 60,
            f"Run at: {last_run.run_at.isoformat() if last_run and last_run.run_at else 'Never'}",
            f"Analysed: {last_run.analysed_workflows if last_run else 0}",
            f"Updated: {last_run.updated_workflows if last_run else 0}",
            "",
            "Top Automation Opportunities",
            "-" * 60,
        ]

        for index, workflow in enumerate(workflows[:8], start=1):
            plan = safe_json_loads(workflow.prototype_plan_json, [])

            lines += [
                f"{index}. {workflow.task_name}",
                f"   Team: {workflow.team}",
                f"   Owner: {workflow.owner or 'Unassigned'}",
                f"   Affected Teams: {workflow.affected_teams or workflow.team or 'Not recorded'}",
                f"   Business Impact: {workflow.business_impact_type or 'Employee Productivity'}",
                f"   Status: {workflow.status} ({days_in_stage(workflow.stage_entered_at)} days in stage)",
                f"   Score: {workflow.impact_score} | Priority: {workflow.recommendation}",
                f"   Readiness: {workflow.readiness_score}% | Confidence: {workflow.confidence} | Risk: {workflow.risk_level}",
                f"   Adoption: {workflow.adoption_rate_pct or 0}% | Quality: {workflow.quality_score_pct or 0}% | Expected Quality Gain: {workflow.expected_quality_gain_pct or 0}%",
                f"   Before/After Cycle Time: {workflow.baseline_cycle_time_minutes or 0:g} -> {workflow.target_cycle_time_minutes or 0:g} minutes",
                f"   Evidence: {workflow.evidence_url or workflow.baseline_evidence_url or workflow.after_evidence_url or 'Not recorded'}",
                f"   Approval Status: {workflow.approval_status or 'Not Reviewed'}",
                f"   Decision Needed: {workflow.decision_needed or 'Not recorded'}",
                f"   AI Suggestion: {workflow.ai_suggestion or 'Not generated'}",
                f"   Automation Plan: {workflow.automation_plan or 'Not generated'}",
                f"   Estimated Annual Saving: GBP {(workflow.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP:,}",
                (
                    f"   Confirmed Annual Saving: GBP {(workflow.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP:,.0f}"
                    if workflow.confirmed_saving_hours
                    else "   Confirmed Annual Saving: Not recorded yet"
                ),
                "   Prototype Task Plan:",
            ]

            for item in plan:
                lines.append(f"      - {item}")

            workflow_automations = automations_by_workflow.get(workflow.id, [])
            if workflow_automations:
                lines.append("   Automation Registry:")
                for automation in workflow_automations:
                    lines.append(
                        (
                            f"      - {automation.automation_name or 'Unnamed automation'} | "
                            f"{automation.status or 'Planned'} | "
                            f"owner: {automation.owner or 'Unassigned'} | "
                            f"health: {automation.health_score or 0}% | "
                            f"review: {'yes' if automation.needs_review else 'no'}"
                        )
                    )

            lines.append("")

        return "\n".join(lines)

    finally:
        db.close()


@router.get("/dashboard-ui", response_class=HTMLResponse)
def dashboard_ui():
    return render_dashboard_ui()
