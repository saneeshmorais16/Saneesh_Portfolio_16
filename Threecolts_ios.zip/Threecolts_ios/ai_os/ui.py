from html import escape
from string import Template

from .config import HOURLY_COST_GBP, PRIORITY_HIGH
from .database import SessionLocal
from .lifecycle import days_in_stage, generate_next_step, get_action_label, get_status_class
from .models import AutomationDB, EngineRunDB, WorkflowDB
from .scoring import get_badge_class


def _esc(value) -> str:
    return escape(str(value or ""))


def _gbp(value: float) -> str:
    return f"GBP {value:,.0f}"


def _short(value: str, limit: int = 120) -> str:
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


def _health_class(score: int) -> str:
    if score >= 75:
        return "good"
    if score >= 55:
        return "watch"
    return "bad"


def _automation_summary(automations: list[AutomationDB]) -> tuple[str, int]:
    if not automations:
        return "<span class='muted'>No registry entry</span>", 0

    health_values = [automation.health_score or 0 for automation in automations]
    average_health = round(sum(health_values) / len(health_values))
    needs_review = sum(1 for automation in automations if automation.needs_review)
    status_counts = {}
    for automation in automations:
        status = automation.status or "Planned"
        status_counts[status] = status_counts.get(status, 0) + 1

    status_text = ", ".join(f"{count} {status}" for status, count in sorted(status_counts.items()))
    html = (
        f"<strong>{len(automations)}</strong> registered"
        f"<div class='muted'>{_esc(status_text)}</div>"
        f"<div><span class='health {_health_class(average_health)}'>{average_health}% health</span></div>"
    )
    if needs_review:
        html += f"<div class='risk-line'>{needs_review} needs review</div>"

    return html, average_health


def render_dashboard_ui():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc(), WorkflowDB.updated_at.desc()).all()
        automations = (
            db.query(AutomationDB).order_by(AutomationDB.needs_review.desc(), AutomationDB.health_score.asc()).all()
        )
        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()
    finally:
        db.close()

    automations_by_workflow: dict[int, list[AutomationDB]] = {}
    for automation in automations:
        automations_by_workflow.setdefault(automation.workflow_id, []).append(automation)

    total = len(workflows)
    deployed = [workflow for workflow in workflows if (workflow.status or "") == "Deployed"]
    active_pilots = [workflow for workflow in workflows if (workflow.status or "") in ["Pilot", "Scaling"]]
    estimated_saving = sum(workflow.time_spent_per_week or 0 for workflow in workflows) * 52 * HOURLY_COST_GBP
    confirmed_saving = sum(workflow.confirmed_saving_hours or 0 for workflow in deployed) * 52 * HOURLY_COST_GBP
    high_priority = sum(1 for workflow in workflows if (workflow.impact_score or 0) >= PRIORITY_HIGH)
    high_risk_count = sum(1 for workflow in workflows if (workflow.risk_level or "Medium") == "High")
    decision_needed_count = sum(
        1
        for workflow in workflows
        if (workflow.approval_status or "Not Reviewed") in ["Not Reviewed", "Needs Evidence"]
        and (workflow.status or "") in ["Under Review", "Prototype Built", "Pilot"]
    )
    overdue_reviews = sum(
        1
        for workflow in workflows
        if days_in_stage(workflow.stage_entered_at) > 14 and (workflow.status or "") not in ["Backlog", "Deployed"]
    )
    missing_evidence = sum(
        1
        for workflow in workflows
        if not (workflow.evidence_url or workflow.baseline_evidence_url or workflow.after_evidence_url)
    )
    automation_health_values = [automation.health_score or 0 for automation in automations]
    average_automation_health = (
        round(sum(automation_health_values) / len(automation_health_values), 1) if automation_health_values else 0
    )
    automation_needs_review = sum(1 for automation in automations if automation.needs_review)

    last_run_at = last_run.run_at.strftime("%d %b %Y %H:%M") if last_run and last_run.run_at else "Not run yet"

    impact_mix = {}
    for workflow in workflows:
        impact_type = workflow.business_impact_type or "Employee Productivity"
        impact_mix[impact_type] = impact_mix.get(impact_type, 0) + 1

    impact_mix_html = (
        "".join(
            f"<div class='mix-row'><span>{_esc(label)}</span><strong>{count}</strong></div>"
            for label, count in sorted(impact_mix.items())
        )
        or "<p class='muted'>No impact data yet.</p>"
    )

    status_flow = [
        "New",
        "Backlog",
        "Validation Needed",
        "Under Review",
        "Prototype Built",
        "Pilot",
        "Scaling",
        "Deployed",
    ]
    status_counts = {
        status: sum(1 for workflow in workflows if (workflow.status or "New") == status) for status in status_flow
    }
    stage_html = "".join(
        (f"<div class='stage'><span>{_esc(status)}</span><strong>{status_counts[status]}</strong></div>")
        for status in status_flow
    )

    workflow_rows = ""
    for workflow in workflows:
        score = workflow.impact_score or 0
        status = workflow.status or "New"
        days = days_in_stage(workflow.stage_entered_at)
        stale = days > 14 and status not in ["Deployed", "Backlog"]
        estimated = (workflow.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP
        confirmed = (workflow.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP
        workflow_automations = automations_by_workflow.get(workflow.id, [])
        automation_html, _automation_health = _automation_summary(workflow_automations)
        evidence_text = (
            workflow.evidence_url or workflow.baseline_evidence_url or workflow.after_evidence_url or "Not recorded"
        )
        decision_text = workflow.decision_needed or "No decision note"

        if status == "Deployed":
            advance_button = "<button class='btn neutral' disabled>Complete</button>"
        else:
            advance_button = (
                f"<button class='btn primary' onclick='advanceStatus({workflow.id})'>"
                f"{_esc(get_action_label(status))}</button>"
            )

        workflow_rows += f"""
        <tr data-status="{_esc(status)}" data-priority="{_esc(workflow.recommendation or "")}">
            <td>
                <strong>{_esc(workflow.task_name)}</strong>
                <div class="muted">{_esc(workflow.team)} / {_esc(workflow.business_impact_type or "Employee Productivity")}</div>
                <div class="small">{_esc(_short(workflow.notes or workflow.ai_suggestion or "", 96))}</div>
            </td>
            <td>
                <span class="owner">{_esc(workflow.owner or "Unassigned")}</span>
                <div class="muted">{_esc(workflow.affected_teams or workflow.team or "No affected teams")}</div>
            </td>
            <td>
                <span class="status {get_status_class(status)}">{_esc(status)}</span>
                <div class="muted{" warn-text" if stale else ""}">{days} days in stage</div>
            </td>
            <td>
                <strong>{score}</strong>
                <span class="badge {get_badge_class(score)}">{_esc(workflow.recommendation or "Low Priority")}</span>
                <div class="muted">{workflow.readiness_score or 0}% readiness</div>
            </td>
            <td>
                <strong>{_gbp(estimated)}</strong>
                <div class="muted">{workflow.time_spent_per_week or 0} hrs/week</div>
                <div class="muted">Confirmed: {_gbp(confirmed) if workflow.confirmed_saving_hours else "Not recorded"}</div>
            </td>
            <td>
                <div><strong>{workflow.adoption_rate_pct or 0}%</strong> adoption</div>
                <div class="muted">{workflow.quality_score_pct or 0}% quality</div>
                <div class="muted">{workflow.baseline_cycle_time_minutes or 0:g} -> {workflow.target_cycle_time_minutes or 0:g} min</div>
            </td>
            <td>
                <div class="small">{_esc(_short(evidence_text, 90))}</div>
                <div class="decision">{_esc(workflow.approval_status or "Not Reviewed")}</div>
                <div class="muted">{_esc(_short(decision_text, 90))}</div>
            </td>
            <td>{automation_html}</td>
            <td><span class="next">{_esc(generate_next_step(score, status))}</span></td>
            <td class="actions">
                <div class="action-row">
                    <button class="btn" onclick="openBrief({workflow.id})">CEO Brief</button>
                    <button class="btn" onclick="updateDecision({workflow.id})">Decision</button>
                    <button class="btn" onclick="createAutomation({workflow.id})">Automation</button>
                </div>
                <div class="action-row">
                    {advance_button}
                    <button class="btn" onclick="setSaving({workflow.id})">Set Saving</button>
                    <button class="btn" onclick="reanalyze({workflow.id})">Reanalyse</button>
                    <button class="btn danger" onclick="deleteWorkflow({workflow.id})">Remove</button>
                </div>
            </td>
        </tr>
        """

    if not workflow_rows:
        workflow_rows = "<tr><td colspan='10' class='empty'>No workflows yet.</td></tr>"

    automation_rows = ""
    workflow_names = {workflow.id: workflow.task_name for workflow in workflows}
    for automation in automations:
        health = automation.health_score or 0
        automation_rows += f"""
        <tr>
            <td>
                <strong>{_esc(automation.automation_name)}</strong>
                <div class="muted">{_esc(automation.automation_type or "Workflow")}</div>
            </td>
            <td>
                {_esc(workflow_names.get(automation.workflow_id, "Unknown workflow"))}
                <div class="muted">Workflow #{automation.workflow_id}</div>
            </td>
            <td>{_esc(automation.owner or "Unassigned")}</td>
            <td>
                <span class="status auto-status">{_esc(automation.status or "Planned")}</span>
                <div class="muted">{"Approval required" if automation.human_approval_required else "No approval flag"}</div>
            </td>
            <td>
                <span class="health {_health_class(health)}">{health}%</span>
                <div class="muted">{_esc(automation.quality_check_result or "Not Checked")}</div>
                <div class="muted">{"Needs review" if automation.needs_review else "Healthy"}</div>
            </td>
            <td>
                <strong>{_esc(automation.last_run_result or "Not Run")}</strong>
                <div class="muted">{automation.last_run_at.strftime("%d %b %Y %H:%M") if automation.last_run_at else "No runs recorded"}</div>
                <div class="muted">{automation.failure_count or 0} failures</div>
            </td>
            <td class="small">{_esc(_short(automation.rollback_plan or "No rollback plan recorded", 110))}</td>
            <td class="actions">
                <div class="action-row">
                    <button class="btn" onclick="recordRun({automation.id}, 'Success')">Run OK</button>
                    <button class="btn danger" onclick="recordRun({automation.id}, 'Failed')">Run Failed</button>
                    <button class="btn" onclick="updateAutomationStatus({automation.id})">Update</button>
                </div>
            </td>
        </tr>
        """

    if not automation_rows:
        automation_rows = "<tr><td colspan='8' class='empty'>No automations registered yet.</td></tr>"

    page = Template(
        """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AI Impact OS</title>
<style>
:root {
    --bg:#f5f7fb;
    --surface:#ffffff;
    --surface-2:#f0f4f8;
    --line:#d9e1ec;
    --text:#172033;
    --muted:#607089;
    --ink:#0f172a;
    --blue:#2563eb;
    --teal:#0f9f82;
    --amber:#b7791f;
    --red:#c24152;
    --purple:#6d28d9;
    --radius:8px;
}

* {
    box-sizing:border-box;
}

html {
    scroll-behavior:smooth;
}

body {
    margin:0;
    background:var(--bg);
    color:var(--text);
    font-family:Inter,Segoe UI,Arial,sans-serif;
    font-size:14px;
    line-height:1.5;
}

a {
    color:inherit;
}

.shell {
    min-height:100vh;
    display:grid;
    grid-template-columns:220px minmax(0,1fr);
}

.sidebar {
    background:#101828;
    color:#d8e0ee;
    padding:22px 18px;
    position:sticky;
    top:0;
    height:100vh;
}

.brand {
    font-weight:800;
    font-size:18px;
    margin-bottom:22px;
}

.brand span {
    color:#68d8bd;
}

.nav {
    display:block;
    text-decoration:none;
    color:#a9b4c7;
    padding:9px 10px;
    border-radius:6px;
    margin-bottom:4px;
    font-weight:650;
}

.nav:hover,
.nav.active {
    background:#1f2937;
    color:#ffffff;
}

.content {
    min-width:0;
    padding:24px;
}

.topbar {
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:18px;
    margin-bottom:18px;
}

.topbar h1 {
    margin:0 0 4px;
    color:var(--ink);
    font-size:28px;
    letter-spacing:0;
}

.topbar p {
    margin:0;
    color:var(--muted);
    max-width:760px;
}

.top-actions {
    display:flex;
    flex-wrap:wrap;
    justify-content:flex-end;
    gap:8px;
}

.btn {
    border:1px solid var(--line);
    background:var(--surface);
    color:var(--ink);
    border-radius:6px;
    padding:8px 10px;
    min-height:34px;
    font-weight:700;
    cursor:pointer;
    text-decoration:none;
    white-space:nowrap;
}

.btn:hover {
    border-color:var(--blue);
}

.btn.primary,
.btn-engine {
    background:var(--blue);
    border-color:var(--blue);
    color:#ffffff;
}

.btn.danger {
    color:var(--red);
}

.btn.neutral {
    color:var(--muted);
    cursor:not-allowed;
}

.metric-grid {
    display:grid;
    grid-template-columns:repeat(4,minmax(160px,1fr));
    gap:12px;
    margin-bottom:16px;
}

.metric,
.panel {
    background:var(--surface);
    border:1px solid var(--line);
    border-radius:var(--radius);
}

.metric {
    padding:16px;
    min-height:100px;
}

.metric .label {
    color:var(--muted);
    font-size:11px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.04em;
}

.metric .value {
    color:var(--ink);
    font-size:26px;
    font-weight:850;
    margin-top:5px;
}

.metric .note {
    color:var(--muted);
    font-size:12px;
}

.section-grid {
    display:grid;
    grid-template-columns:minmax(0,1.15fr) minmax(330px,.85fr);
    gap:14px;
    margin-bottom:16px;
}

.panel {
    padding:16px;
}

.panel h2,
.panel h3 {
    color:var(--ink);
    margin:0 0 12px;
    font-size:16px;
}

.stage-map {
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:8px;
}

.stage {
    background:var(--surface-2);
    border:1px solid var(--line);
    border-radius:6px;
    padding:10px;
    min-height:64px;
}

.stage span,
.muted {
    color:var(--muted);
    font-size:12px;
}

.stage strong {
    display:block;
    color:var(--ink);
    font-size:22px;
    margin-top:4px;
}

.mix-row {
    display:flex;
    justify-content:space-between;
    gap:12px;
    border-bottom:1px solid var(--line);
    padding:8px 0;
}

.mix-row:last-child {
    border-bottom:none;
}

form {
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:10px;
}

form .wide {
    grid-column:1 / -1;
}

input,
select,
textarea {
    width:100%;
    border:1px solid var(--line);
    border-radius:6px;
    padding:10px;
    color:var(--ink);
    background:#ffffff;
    font:inherit;
}

textarea {
    min-height:76px;
    resize:vertical;
}

.table-panel {
    background:var(--surface);
    border:1px solid var(--line);
    border-radius:var(--radius);
    margin-bottom:16px;
    overflow:hidden;
}

.table-head {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    padding:14px 16px;
    border-bottom:1px solid var(--line);
}

.table-head h2 {
    margin:0;
    font-size:16px;
    color:var(--ink);
}

.filters {
    display:flex;
    flex-wrap:wrap;
    gap:6px;
}

.filter {
    border:1px solid var(--line);
    background:var(--surface-2);
    border-radius:999px;
    color:var(--text);
    cursor:pointer;
    padding:6px 10px;
    font-weight:700;
}

.table-wrap {
    overflow-x:auto;
}

table {
    width:100%;
    min-width:1320px;
    border-collapse:collapse;
}

th {
    background:#f8fafc;
    color:var(--muted);
    font-size:11px;
    text-align:left;
    text-transform:uppercase;
    letter-spacing:.04em;
    padding:11px 12px;
    border-bottom:1px solid var(--line);
}

td {
    vertical-align:top;
    padding:12px;
    border-bottom:1px solid var(--line);
}

tr:hover td {
    background:#fbfdff;
}

.small {
    color:#3d4a5f;
    font-size:12px;
    margin-top:4px;
}

.owner,
.badge,
.status,
.health,
.next,
.decision {
    display:inline-flex;
    align-items:center;
    border-radius:999px;
    font-size:11px;
    font-weight:850;
    padding:4px 8px;
    white-space:nowrap;
}

.owner {
    background:#eef2f7;
    color:#2f3b4f;
}

.badge.high {
    background:#fff0f2;
    color:var(--red);
}

.badge.medium {
    background:#fff7e8;
    color:var(--amber);
}

.badge.low {
    background:#e9f8f4;
    color:var(--teal);
}

.s-new,
.s-backlog {
    background:#eef2f7;
    color:#46556d;
}

.s-validation,
.s-pilot {
    background:#fff7e8;
    color:var(--amber);
}

.s-review {
    background:#eaf1ff;
    color:var(--blue);
}

.s-prototype {
    background:#f1ebff;
    color:var(--purple);
}

.s-scaling {
    background:#e7f7ff;
    color:#0673a6;
}

.s-deployed {
    background:#e9f8f4;
    color:var(--teal);
}

.auto-status,
.decision {
    background:#eef2f7;
    color:#2f3b4f;
}

.health.good {
    background:#e9f8f4;
    color:var(--teal);
}

.health.watch {
    background:#fff7e8;
    color:var(--amber);
}

.health.bad {
    background:#fff0f2;
    color:var(--red);
}

.next {
    background:#edf6ff;
    color:#155f9b;
    line-height:1.3;
    white-space:normal;
}

.warn-text,
.risk-line {
    color:var(--amber);
    font-size:12px;
    font-weight:750;
}

.actions {
    min-width:250px;
}

.action-row {
    display:flex;
    flex-wrap:wrap;
    gap:6px;
    margin-bottom:6px;
}

.empty {
    color:var(--muted);
    text-align:center;
    padding:28px;
}

.toast {
    position:fixed;
    right:18px;
    bottom:18px;
    max-width:360px;
    padding:12px 14px;
    border:1px solid var(--line);
    border-radius:8px;
    background:#101828;
    color:#ffffff;
    opacity:0;
    transform:translateY(8px);
    transition:.2s ease;
    z-index:20;
}

.toast.show {
    opacity:1;
    transform:translateY(0);
}

@media (max-width:980px) {
    .shell {
        grid-template-columns:1fr;
    }
    .sidebar {
        height:auto;
        position:static;
    }
    .metric-grid,
    .section-grid,
    form,
    .stage-map {
        grid-template-columns:1fr;
    }
    .topbar {
        flex-direction:column;
    }
    .top-actions {
        justify-content:flex-start;
    }
}
</style>
</head>
<body>
<div class="shell">
    <aside class="sidebar">
        <div class="brand">AI Impact <span>OS</span></div>
        <a class="nav active" href="#overview">Overview</a>
        <a class="nav" href="#intake">Intake</a>
        <a class="nav" href="#pipeline">Pipeline</a>
        <a class="nav" href="#automation">Automation Registry</a>
        <a class="nav" href="/executive-summary" target="_blank">Executive Summary</a>
        <a class="nav" href="/report" target="_blank">Report</a>
        <a class="nav" href="/export-csv" target="_blank">Export CSV</a>
    </aside>

    <main class="content" id="overview">
        <div class="topbar">
            <div>
                <h1>AI Operations Dashboard</h1>
                <p>Opportunity intake, evidence, CEO briefs, pilot decisions, delivery registry, monitoring, and measured savings.</p>
            </div>
            <div class="top-actions">
                <button class="btn btn-engine" onclick="runEngine()">Run Engine</button>
                <a class="btn" href="/executive-summary" target="_blank">Executive Summary</a>
                <a class="btn" href="/report" target="_blank">Report</a>
                <a class="btn" href="/export-csv" target="_blank">Export CSV</a>
            </div>
        </div>

        <section class="metric-grid">
            <div class="metric"><div class="label">Opportunities</div><div class="value">$total</div><div class="note">$high_priority high priority</div></div>
            <div class="metric"><div class="label">Estimated Savings</div><div class="value">$estimated_saving</div><div class="note">at GBP $hourly_cost/hr</div></div>
            <div class="metric"><div class="label">Confirmed Savings</div><div class="value">$confirmed_saving</div><div class="note">$deployed deployed</div></div>
            <div class="metric"><div class="label">Active Pilots</div><div class="value">$active_pilots</div><div class="note">pilot or scaling</div></div>
            <div class="metric"><div class="label">Decision Needed</div><div class="value">$decision_needed</div><div class="note">$missing_evidence missing evidence</div></div>
            <div class="metric"><div class="label">High Risk</div><div class="value">$high_risk</div><div class="note">$overdue_reviews overdue reviews</div></div>
            <div class="metric"><div class="label">Automations</div><div class="value">$automation_count</div><div class="note">$automation_needs_review needing review</div></div>
            <div class="metric"><div class="label">Automation Health</div><div class="value">$automation_health%</div><div class="note">last engine run: $last_run</div></div>
        </section>

        <section class="section-grid">
            <div class="panel">
                <h2>Lifecycle Pipeline</h2>
                <div class="stage-map">$stage_html</div>
            </div>
            <div class="panel">
                <h2>Business Impact Mix</h2>
                $impact_mix_html
            </div>
        </section>

        <section class="panel" id="intake">
            <h2>Workflow Intake</h2>
            <form onsubmit="submitWorkflow(event)">
                <input id="team" placeholder="Team" required>
                <input id="task_name" placeholder="Workflow name" required>
                <input id="owner" placeholder="Owner">
                <input id="affected_teams" placeholder="Affected teams">
                <select id="business_impact_type">
                    <option value="Employee Productivity">Employee Productivity</option>
                    <option value="Cost Saving">Cost Saving</option>
                    <option value="Revenue Growth">Revenue Growth</option>
                    <option value="Risk Reduction">Risk Reduction</option>
                    <option value="Customer Experience">Customer Experience</option>
                    <option value="Quality Improvement">Quality Improvement</option>
                </select>
                <input id="frequency" placeholder="Frequency" required>
                <input id="time_spent" type="number" min="0" max="168" placeholder="Hours per week" required>
                <select id="pain_level" required>
                    <option value="">Pain level</option>
                    <option value="1">1 - Low</option>
                    <option value="2">2</option>
                    <option value="3">3 - Medium</option>
                    <option value="4">4</option>
                    <option value="5">5 - High</option>
                </select>
                <input id="baseline_cycle_time" type="number" min="0" max="10080" placeholder="Baseline cycle minutes">
                <input id="target_cycle_time" type="number" min="0" max="10080" placeholder="Target cycle minutes">
                <input id="expected_quality_gain" type="number" min="0" max="100" placeholder="Expected quality gain %">
                <input id="measurement_owner" placeholder="Measurement owner">
                <input id="sample_size" type="number" min="0" max="1000000" placeholder="Sample size">
                <input id="evidence_url" placeholder="Evidence URL">
                <input id="baseline_evidence_url" placeholder="Baseline evidence URL">
                <input id="after_evidence_url" placeholder="After evidence URL">
                <input id="decision_needed" placeholder="Decision needed">
                <textarea class="wide" id="notes" placeholder="Problem notes or evidence summary"></textarea>
                <button type="submit" class="btn primary wide">Add Workflow + AI Analysis</button>
            </form>
        </section>

        <section class="table-panel" id="pipeline">
            <div class="table-head">
                <h2>Opportunity Pipeline</h2>
                <div class="filters">
                    <button class="filter" onclick="filterRows('All')">All</button>
                    <button class="filter" onclick="filterRows('High Priority')">High Priority</button>
                    <button class="filter" onclick="filterRows('Under Review')">Under Review</button>
                    <button class="filter" onclick="filterRows('Pilot')">Pilot</button>
                    <button class="filter" onclick="filterRows('Scaling')">Scaling</button>
                    <button class="filter" onclick="filterRows('Deployed')">Deployed</button>
                </div>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Opportunity</th>
                            <th>Owner</th>
                            <th>Stage</th>
                            <th>Score</th>
                            <th>Value</th>
                            <th>Measurement</th>
                            <th>Evidence / Decision</th>
                            <th>Automation</th>
                            <th>Next Step</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>$workflow_rows</tbody>
                </table>
            </div>
        </section>

        <section class="table-panel" id="automation">
            <div class="table-head">
                <h2>Automation Registry</h2>
                <div class="filters">
                    <a class="btn" href="/automations" target="_blank">Registry API</a>
                </div>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Automation</th>
                            <th>Workflow</th>
                            <th>Owner</th>
                            <th>Status</th>
                            <th>Health</th>
                            <th>Last Run</th>
                            <th>Rollback</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>$automation_rows</tbody>
                </table>
            </div>
        </section>
    </main>
</div>

<div class="toast" id="toast"></div>

<script>
function toast(message) {
    const el = document.getElementById('toast');
    el.textContent = message;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 3000);
}

async function requestJson(url, options) {
    const response = await fetch(url, options || {});
    if (!response.ok) {
        const text = await response.text();
        throw new Error(text || 'Request failed');
    }
    return response.json();
}

async function submitWorkflow(event) {
    event.preventDefault();
    const button = event.target.querySelector('button[type="submit"]');
    button.disabled = true;
    button.textContent = 'Analysing...';

    const payload = {
        team: document.getElementById('team').value,
        task_name: document.getElementById('task_name').value,
        owner: document.getElementById('owner').value,
        affected_teams: document.getElementById('affected_teams').value,
        business_impact_type: document.getElementById('business_impact_type').value,
        frequency: document.getElementById('frequency').value,
        time_spent_per_week: parseInt(document.getElementById('time_spent').value, 10),
        pain_level: parseInt(document.getElementById('pain_level').value, 10),
        baseline_cycle_time_minutes: parseFloat(document.getElementById('baseline_cycle_time').value || '0'),
        target_cycle_time_minutes: parseFloat(document.getElementById('target_cycle_time').value || '0'),
        expected_quality_gain_pct: parseInt(document.getElementById('expected_quality_gain').value || '0', 10),
        measurement_owner: document.getElementById('measurement_owner').value,
        sample_size: parseInt(document.getElementById('sample_size').value || '0', 10),
        evidence_url: document.getElementById('evidence_url').value,
        baseline_evidence_url: document.getElementById('baseline_evidence_url').value,
        after_evidence_url: document.getElementById('after_evidence_url').value,
        decision_needed: document.getElementById('decision_needed').value,
        notes: document.getElementById('notes').value
    };

    try {
        const data = await requestJson('/submit-workflow', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        toast('Added: score ' + data.impact_score + ', ' + data.recommendation);
        setTimeout(() => location.reload(), 700);
    } catch (error) {
        button.disabled = false;
        button.textContent = 'Add Workflow + AI Analysis';
        toast('Workflow was not saved.');
    }
}

async function runEngine() {
    try {
        const data = await requestJson('/run-automation-engine', {method: 'POST'});
        toast('Engine complete: ' + data.updated + ' updated');
        setTimeout(() => location.reload(), 700);
    } catch (error) {
        toast('Engine failed.');
    }
}

async function advanceStatus(id) {
    try {
        const data = await requestJson('/advance-status/' + id, {method: 'PUT'});
        toast('Moved to ' + data.new_status);
        setTimeout(() => location.reload(), 600);
    } catch (error) {
        toast('Status was not updated.');
    }
}

async function setSaving(id) {
    const hours = prompt('Confirmed weekly hours saved:', '0');
    if (hours === null || hours === '') {
        return;
    }
    const adoption = prompt('Adoption rate %:', '0');
    const quality = prompt('Quality score %:', '0');
    const evidence = prompt('After evidence URL:', '');

    try {
        await requestJson('/workflows/' + id + '/confirmed-saving', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                confirmed_saving_hours: parseFloat(hours),
                adoption_rate_pct: parseInt(adoption || '0', 10),
                quality_score_pct: parseInt(quality || '0', 10),
                after_evidence_url: evidence || null
            })
        });
        toast('Saving updated');
        setTimeout(() => location.reload(), 600);
    } catch (error) {
        toast('Saving was not updated.');
    }
}

async function updateDecision(id) {
    const approval = prompt('Approval status:', 'Approved for Pilot');
    if (!approval) {
        return;
    }
    const decision = prompt('Decision note:', '');
    const status = prompt('Move to status, or leave blank:', '');

    const payload = {
        approval_status: approval,
        decision_needed: decision || null
    };
    if (status) {
        payload.status = status;
    }

    try {
        await requestJson('/workflows/' + id + '/decision', {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        toast('Decision updated');
        setTimeout(() => location.reload(), 600);
    } catch (error) {
        toast('Decision was not updated.');
    }
}

async function createAutomation(id) {
    const name = prompt('Automation name:');
    if (!name) {
        return;
    }
    const owner = prompt('Owner:', 'Automation Owner');
    const type = prompt('Automation type:', 'Workflow');
    const rollback = prompt('Rollback plan:', 'Pause automation and return work to the process owner.');

    try {
        await requestJson('/workflows/' + id + '/automations', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                automation_name: name,
                owner: owner || 'Automation Owner',
                automation_type: type || 'Workflow',
                status: 'Planned',
                rollback_plan: rollback || ''
            })
        });
        toast('Automation registered');
        setTimeout(() => location.reload(), 600);
    } catch (error) {
        toast('Automation was not registered.');
    }
}

async function updateAutomationStatus(id) {
    const status = prompt('Automation status:', 'Live');
    if (!status) {
        return;
    }
    const notes = prompt('Monitoring notes:', '');

    try {
        await requestJson('/automations/' + id, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                status: status,
                monitoring_notes: notes || null
            })
        });
        toast('Automation updated');
        setTimeout(() => location.reload(), 600);
    } catch (error) {
        toast('Automation was not updated.');
    }
}

async function recordRun(id, result) {
    const quality = result === 'Success' ? 'Pass' : 'Fail';
    const notes = prompt('Run notes:', result);
    try {
        await requestJson('/automations/' + id + '/runs', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                result: result,
                quality_check_result: quality,
                notes: notes || ''
            })
        });
        toast('Run recorded');
        setTimeout(() => location.reload(), 600);
    } catch (error) {
        toast('Run was not recorded.');
    }
}

async function reanalyze(id) {
    try {
        await requestJson('/workflows/' + id + '/reanalyse', {method: 'POST'});
        toast('AI analysis refreshed');
        setTimeout(() => location.reload(), 700);
    } catch (error) {
        toast('Reanalysis failed.');
    }
}

async function deleteWorkflow(id) {
    if (!confirm('Remove this workflow?')) {
        return;
    }
    try {
        await requestJson('/delete-workflow/' + id, {method: 'DELETE'});
        toast('Workflow removed');
        setTimeout(() => location.reload(), 600);
    } catch (error) {
        toast('Workflow was not removed.');
    }
}

function openBrief(id) {
    window.open('/workflows/' + id + '/brief', '_blank');
}

function filterRows(filter) {
    const rows = document.querySelectorAll('#pipeline tbody tr');
    rows.forEach(row => {
        const status = row.getAttribute('data-status') || '';
        const priority = row.getAttribute('data-priority') || '';
        row.style.display = filter === 'All' || status === filter || priority === filter ? '' : 'none';
    });
}
</script>
</body>
</html>
"""
    )

    return page.safe_substitute(
        total=total,
        high_priority=high_priority,
        estimated_saving=_gbp(estimated_saving),
        hourly_cost=HOURLY_COST_GBP,
        confirmed_saving=_gbp(confirmed_saving),
        deployed=len(deployed),
        active_pilots=len(active_pilots),
        decision_needed=decision_needed_count,
        missing_evidence=missing_evidence,
        high_risk=high_risk_count,
        overdue_reviews=overdue_reviews,
        automation_count=len(automations),
        automation_needs_review=automation_needs_review,
        automation_health=average_automation_health,
        last_run=_esc(last_run_at),
        stage_html=stage_html,
        impact_mix_html=impact_mix_html,
        workflow_rows=workflow_rows,
        automation_rows=automation_rows,
    )
