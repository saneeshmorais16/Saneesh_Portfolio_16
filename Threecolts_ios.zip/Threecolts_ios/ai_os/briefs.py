from __future__ import annotations

from .config import HOURLY_COST_GBP
from .utils import safe_json_loads


def clean_text(value, fallback: str = "Not recorded") -> str:
    text = str(value or "").strip()
    return text if text else fallback


def format_gbp(value: float) -> str:
    try:
        return f"GBP {float(value):,.0f}"
    except (TypeError, ValueError):
        return "Not recorded"


def generate_opportunity_brief(workflow, automations: list | None = None) -> str:
    prototype_plan = safe_json_loads(workflow.prototype_plan_json, [])
    estimated_annual = (workflow.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP
    confirmed_annual = (workflow.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP
    automations = automations or []

    evidence_items = [
        f"General evidence: {clean_text(workflow.evidence_url)}",
        f"Baseline evidence: {clean_text(workflow.baseline_evidence_url)}",
        f"After evidence: {clean_text(workflow.after_evidence_url)}",
    ]

    data_needed = prototype_plan or [
        "Collect examples of the current workflow",
        "Confirm baseline time and quality with the process owner",
        "Run a small pilot before scaling",
    ]

    lines = [
        "AI Opportunity CEO Brief",
        "=" * 60,
        "",
        f"Workflow: {clean_text(workflow.task_name)}",
        f"Team: {clean_text(workflow.team)}",
        f"Owner: {clean_text(workflow.owner, 'Unassigned')}",
        f"Affected teams: {clean_text(workflow.affected_teams or workflow.team)}",
        f"Business impact type: {clean_text(workflow.business_impact_type, 'Employee Productivity')}",
        "",
        "Problem",
        "-" * 60,
        clean_text(workflow.notes, "No problem notes have been recorded yet."),
        "",
        "Current Effort and Measurement",
        "-" * 60,
        f"Current effort: {workflow.time_spent_per_week or 0} hours/week",
        f"Pain level: {workflow.pain_level or 0}/5",
        f"Frequency: {clean_text(workflow.frequency)}",
        (
            "Before/after cycle time: "
            f"{workflow.baseline_cycle_time_minutes or 0:g} -> "
            f"{workflow.target_cycle_time_minutes or 0:g} minutes"
        ),
        f"Sample size: {workflow.sample_size or 0}",
        f"Measurement owner: {clean_text(workflow.measurement_owner, 'Unassigned')}",
        "",
        "Business Value",
        "-" * 60,
        f"Impact score: {workflow.impact_score or 0}/100",
        f"Priority: {clean_text(workflow.recommendation)}",
        f"Readiness score: {workflow.readiness_score or 0}%",
        f"Estimated annual saving: {format_gbp(estimated_annual)}",
        (
            f"Confirmed annual saving: {format_gbp(confirmed_annual)}"
            if workflow.confirmed_saving_hours
            else "Confirmed annual saving: Not recorded yet"
        ),
        f"Adoption rate: {workflow.adoption_rate_pct or 0}%",
        f"Quality score: {workflow.quality_score_pct or 0}%",
        "",
        "AI Recommendation",
        "-" * 60,
        f"AI suggestion: {clean_text(workflow.ai_suggestion, 'Not generated')}",
        f"Prototype plan: {clean_text(workflow.automation_plan, 'Not generated')}",
        "",
        "Data and Evidence",
        "-" * 60,
    ]

    for item in evidence_items:
        lines.append(f"- {item}")

    for item in data_needed:
        lines.append(f"- {item}")

    lines += [
        "",
        "Risk and Governance",
        "-" * 60,
        f"Risk level: {clean_text(workflow.risk_level, 'Medium')}",
        f"Confidence: {clean_text(workflow.confidence, 'Medium')}",
        f"Governance notes: {clean_text(workflow.governance_notes, 'No governance notes recorded yet.')}",
        f"Approval status: {clean_text(workflow.approval_status, 'Not Reviewed')}",
        "",
        "Decision Needed",
        "-" * 60,
        clean_text(
            workflow.decision_needed,
            "Confirm whether this opportunity should move to validation, prototype, pilot, or backlog.",
        ),
        "",
        "Automation Delivery",
        "-" * 60,
    ]

    if automations:
        for automation in automations:
            lines.append(
                (
                    f"- {clean_text(automation.automation_name)} | "
                    f"{clean_text(automation.status)} | "
                    f"owner: {clean_text(automation.owner, 'Unassigned')} | "
                    f"health: {automation.health_score or 0}% | "
                    f"last run: {clean_text(automation.last_run_result, 'Not Run')}"
                )
            )
    else:
        lines.append("- No automation registry entry has been linked yet.")

    lines += [
        "",
        "No figures in this brief are generated or invented. It uses only stored workflow data.",
    ]

    return "\n".join(lines)
