from __future__ import annotations

from .config import HOURLY_COST_GBP
from .lifecycle import days_in_stage
from .models import AutomationDB, AutomationRunDB, WorkflowDB
from .scoring import split_affected_teams
from .utils import safe_json_loads


def workflow_to_dict(w: WorkflowDB) -> dict:
    return {
        "id": w.id,
        "team": w.team,
        "task_name": w.task_name,
        "owner": w.owner,
        "affected_teams": w.affected_teams,
        "affected_team_list": split_affected_teams(w.affected_teams),
        "business_impact_type": w.business_impact_type,
        "time_spent_per_week": w.time_spent_per_week,
        "pain_level": w.pain_level,
        "frequency": w.frequency,
        "baseline_cycle_time_minutes": w.baseline_cycle_time_minutes,
        "target_cycle_time_minutes": w.target_cycle_time_minutes,
        "impact_score": w.impact_score,
        "score_breakdown": safe_json_loads(w.score_breakdown_json, {}),
        "recommendation": w.recommendation,
        "status": w.status,
        "notes": w.notes,
        "ai_suggestion": w.ai_suggestion,
        "automation_plan": w.automation_plan,
        "prototype_plan": safe_json_loads(w.prototype_plan_json, []),
        "estimated_effort_days": w.estimated_effort_days,
        "confidence": w.confidence,
        "risk_level": w.risk_level,
        "readiness_score": w.readiness_score,
        "confirmed_saving_hours": w.confirmed_saving_hours,
        "adoption_rate_pct": w.adoption_rate_pct,
        "quality_score_pct": w.quality_score_pct,
        "expected_quality_gain_pct": w.expected_quality_gain_pct,
        "governance_notes": w.governance_notes,
        "evidence_url": w.evidence_url,
        "baseline_evidence_url": w.baseline_evidence_url,
        "after_evidence_url": w.after_evidence_url,
        "measurement_owner": w.measurement_owner,
        "sample_size": w.sample_size,
        "approval_status": w.approval_status,
        "decision_needed": w.decision_needed,
        "estimated_annual_saving_gbp": (w.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP,
        "confirmed_annual_saving_gbp": (w.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP,
        "days_in_stage": days_in_stage(w.stage_entered_at),
        "created_at": w.created_at.isoformat() if w.created_at else None,
        "updated_at": w.updated_at.isoformat() if w.updated_at else None,
    }


def automation_to_dict(automation: AutomationDB, workflow: WorkflowDB | None = None) -> dict:
    data = {
        "id": automation.id,
        "workflow_id": automation.workflow_id,
        "automation_name": automation.automation_name,
        "owner": automation.owner,
        "automation_type": automation.automation_type,
        "status": automation.status,
        "human_approval_required": automation.human_approval_required,
        "last_run_at": automation.last_run_at.isoformat() if automation.last_run_at else None,
        "last_run_result": automation.last_run_result,
        "failure_count": automation.failure_count,
        "quality_check_result": automation.quality_check_result,
        "rollback_plan": automation.rollback_plan,
        "monitoring_notes": automation.monitoring_notes,
        "health_score": automation.health_score,
        "needs_review": automation.needs_review,
        "created_at": automation.created_at.isoformat() if automation.created_at else None,
        "updated_at": automation.updated_at.isoformat() if automation.updated_at else None,
    }

    if workflow is not None:
        data["workflow"] = {
            "id": workflow.id,
            "team": workflow.team,
            "task_name": workflow.task_name,
            "status": workflow.status,
            "impact_score": workflow.impact_score,
            "recommendation": workflow.recommendation,
        }

    return data


def automation_run_to_dict(run: AutomationRunDB) -> dict:
    return {
        "id": run.id,
        "automation_id": run.automation_id,
        "workflow_id": run.workflow_id,
        "run_at": run.run_at.isoformat() if run.run_at else None,
        "result": run.result,
        "quality_check_result": run.quality_check_result,
        "notes": run.notes,
        "created_at": run.created_at.isoformat() if run.created_at else None,
    }
