from secrets import compare_digest
from typing import Optional

from fastapi import Header, HTTPException

from .config import AI_OS_API_KEY, LEAD_ROLES, VALID_ROLES, WRITE_ROLES


def require_role(
    allowed_roles,
    x_api_key: Optional[str] = Header(default=None),
    x_user_role: Optional[str] = Header(default="viewer"),
    x_actor: Optional[str] = Header(default="demo-user"),
) -> dict:
    role = (x_user_role or "viewer").lower()

    if role not in VALID_ROLES:
        raise HTTPException(status_code=403, detail="Invalid role")

    if role not in allowed_roles:
        raise HTTPException(status_code=403, detail="Role cannot perform this action")

    if AI_OS_API_KEY and (not x_api_key or not compare_digest(x_api_key, AI_OS_API_KEY)):
        raise HTTPException(status_code=401, detail="Invalid or missing API key")

    return {
        "actor": x_actor or "demo-user",
        "role": role,
        "auth_enforced": bool(AI_OS_API_KEY),
    }


def require_write_access(
    x_api_key: Optional[str] = Header(default=None),
    x_user_role: Optional[str] = Header(default="admin"),
    x_actor: Optional[str] = Header(default="demo-user"),
) -> dict:
    return require_role(WRITE_ROLES, x_api_key, x_user_role, x_actor)


def require_lead_access(
    x_api_key: Optional[str] = Header(default=None),
    x_user_role: Optional[str] = Header(default="admin"),
    x_actor: Optional[str] = Header(default="demo-user"),
) -> dict:
    return require_role(LEAD_ROLES, x_api_key, x_user_role, x_actor)
