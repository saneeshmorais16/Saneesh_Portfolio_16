from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse, PlainTextResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    Float,
    Text,
    DateTime,
    text,
)
from sqlalchemy.orm import declarative_base, sessionmaker
from html import escape
from datetime import datetime
from typing import Optional
import csv
import io
import json
import os

try:
    from google import genai
except ImportError:
    genai = None

# ============================================================
# CONFIG
# ============================================================

DATABASE_URL = "sqlite:///./workflows.db"
HOURLY_COST_GBP = 25

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
AI_OS_API_KEY = os.getenv("AI_OS_API_KEY", "")

PRIORITY_HIGH = 70
PRIORITY_MEDIUM = 45

VALID_STATUSES = [
    "New",
    "Backlog",
    "Validation Needed",
    "Under Review",
    "Prototype Built",
    "Pilot",
    "Scaling",
    "Deployed",
]

STATUS_TRANSITIONS = {
    "New": ["Backlog", "Validation Needed", "Under Review"],
    "Backlog": ["Validation Needed", "Under Review"],
    "Validation Needed": ["Under Review", "Backlog"],
    "Under Review": ["Prototype Built", "Backlog"],
    "Prototype Built": ["Pilot", "Under Review"],
    "Pilot": ["Scaling", "Prototype Built"],
    "Scaling": ["Deployed", "Pilot"],
    "Deployed": [],
}

VALID_BUSINESS_IMPACT_TYPES = [
    "Cost Saving",
    "Revenue Growth",
    "Risk Reduction",
    "Customer Experience",
    "Employee Productivity",
    "Quality Improvement",
]

VALID_ROLES = ["viewer", "contributor", "lead", "admin"]
WRITE_ROLES = ["contributor", "lead", "admin"]
LEAD_ROLES = ["lead", "admin"]


# ============================================================
# APP + DATABASE
# ============================================================

app = FastAPI(title="AI Impact OS — Workflow Intelligence Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

engine_db = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

SessionLocal = sessionmaker(bind=engine_db, autoflush=False, autocommit=False)

Base = declarative_base()


# ============================================================
# DATABASE MODELS
# ============================================================


class WorkflowDB(Base):
    __tablename__ = "workflows"

    id = Column(Integer, primary_key=True, index=True)

    team = Column(String, default="")
    task_name = Column(String, default="")
    owner = Column(String, default="")
    affected_teams = Column(Text, default="")
    business_impact_type = Column(String, default="Employee Productivity")

    time_spent_per_week = Column(Integer, default=0)
    pain_level = Column(Integer, default=1)
    frequency = Column(String, default="")
    baseline_cycle_time_minutes = Column(Float, default=0.0)
    target_cycle_time_minutes = Column(Float, default=0.0)

    impact_score = Column(Integer, default=0)
    recommendation = Column(String, default="Low Priority")
    status = Column(String, default="New")
    score_breakdown_json = Column(Text, default="{}")

    notes = Column(Text, default="")

    ai_suggestion = Column(Text, default="")
    automation_plan = Column(Text, default="")
    prototype_plan_json = Column(Text, default="[]")

    estimated_effort_days = Column(Integer, default=10)
    confidence = Column(String, default="Medium")
    risk_level = Column(String, default="Medium")
    readiness_score = Column(Integer, default=50)

    confirmed_saving_hours = Column(Float, default=0.0)
    adoption_rate_pct = Column(Integer, default=0)
    quality_score_pct = Column(Integer, default=0)
    expected_quality_gain_pct = Column(Integer, default=0)
    governance_notes = Column(Text, default="")

    evidence_url = Column(Text, default="")
    baseline_evidence_url = Column(Text, default="")
    after_evidence_url = Column(Text, default="")
    measurement_owner = Column(String, default="")
    sample_size = Column(Integer, default=0)
    approval_status = Column(String, default="Not Reviewed")
    decision_needed = Column(Text, default="")

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    stage_entered_at = Column(DateTime, default=datetime.utcnow)
    stage_history = Column(Text, default="[]")


class EngineRunDB(Base):
    __tablename__ = "engine_runs"

    id = Column(Integer, primary_key=True, index=True)
    run_at = Column(DateTime, default=datetime.utcnow)

    analysed_workflows = Column(Integer, default=0)
    updated_workflows = Column(Integer, default=0)
    high_priority_moved_to_review = Column(Integer, default=0)
    medium_priority_moved_to_validation = Column(Integer, default=0)
    low_priority_moved_to_backlog = Column(Integer, default=0)
    protected_unchanged = Column(Integer, default=0)


class WorkflowCommentDB(Base):
    __tablename__ = "workflow_comments"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, index=True)
    author = Column(String, default="Anonymous")
    body = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class WorkflowAuditDB(Base):
    __tablename__ = "workflow_audit_events"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(Integer, index=True, nullable=True)
    actor = Column(String, default="system")
    role = Column(String, default="system")
    action = Column(String, default="")
    details_json = Column(Text, default="{}")
    created_at = Column(DateTime, default=datetime.utcnow)


Base.metadata.create_all(bind=engine_db)


def migrate_database():
    columns_to_add = {
        "owner": "VARCHAR DEFAULT ''",
        "affected_teams": "TEXT DEFAULT ''",
        "business_impact_type": "VARCHAR DEFAULT 'Employee Productivity'",
        "notes": "TEXT DEFAULT ''",
        "ai_suggestion": "TEXT DEFAULT ''",
        "automation_plan": "TEXT DEFAULT ''",
        "prototype_plan_json": "TEXT DEFAULT '[]'",
        "estimated_effort_days": "INTEGER DEFAULT 10",
        "confidence": "VARCHAR DEFAULT 'Medium'",
        "risk_level": "VARCHAR DEFAULT 'Medium'",
        "readiness_score": "INTEGER DEFAULT 50",
        "confirmed_saving_hours": "REAL DEFAULT 0.0",
        "baseline_cycle_time_minutes": "REAL DEFAULT 0.0",
        "target_cycle_time_minutes": "REAL DEFAULT 0.0",
        "adoption_rate_pct": "INTEGER DEFAULT 0",
        "quality_score_pct": "INTEGER DEFAULT 0",
        "expected_quality_gain_pct": "INTEGER DEFAULT 0",
        "governance_notes": "TEXT DEFAULT ''",
        "score_breakdown_json": "TEXT DEFAULT '{}'",
        "created_at": "DATETIME",
        "updated_at": "DATETIME",
        "stage_entered_at": "DATETIME",
        "stage_history": "TEXT DEFAULT '[]'",
        "evidence_url": "TEXT DEFAULT ''",
        "baseline_evidence_url": "TEXT DEFAULT ''",
        "after_evidence_url": "TEXT DEFAULT ''",
        "measurement_owner": "VARCHAR DEFAULT ''",
        "sample_size": "INTEGER DEFAULT 0",
        "approval_status": "VARCHAR DEFAULT 'Not Reviewed'",
        "decision_needed": "TEXT DEFAULT ''",
    }

    with engine_db.begin() as conn:
        existing_columns = {
            row[1]
            for row in conn.execute(text("PRAGMA table_info(workflows)")).fetchall()
        }

        for column_name, definition in columns_to_add.items():
            if column_name not in existing_columns:
                conn.execute(
                    text(f"ALTER TABLE workflows ADD COLUMN {column_name} {definition}")
                )


migrate_database()


# ============================================================
# PYDANTIC SCHEMAS
# ============================================================


class WorkflowInput(BaseModel):
    team: str = Field(..., min_length=1, max_length=100)
    task_name: str = Field(..., min_length=1, max_length=200)
    owner: Optional[str] = Field(default="", max_length=100)
    affected_teams: Optional[str] = Field(default="", max_length=500)
    business_impact_type: Optional[str] = Field(
        default="Employee Productivity", max_length=80
    )
    time_spent_per_week: int = Field(..., ge=0, le=168)
    pain_level: int = Field(..., ge=1, le=5)
    frequency: str = Field(..., min_length=1, max_length=100)
    baseline_cycle_time_minutes: Optional[float] = Field(default=0, ge=0, le=10080)
    target_cycle_time_minutes: Optional[float] = Field(default=0, ge=0, le=10080)
    expected_quality_gain_pct: Optional[int] = Field(default=0, ge=0, le=100)
    notes: Optional[str] = Field(default="", max_length=2000)
    evidence_url: Optional[str] = Field(default="", max_length=1000)
    baseline_evidence_url: Optional[str] = Field(default="", max_length=1000)
    after_evidence_url: Optional[str] = Field(default="", max_length=1000)
    measurement_owner: Optional[str] = Field(default="", max_length=100)
    sample_size: Optional[int] = Field(default=0, ge=0, le=1000000)
    approval_status: Optional[str] = Field(default="Not Reviewed", max_length=80)
    decision_needed: Optional[str] = Field(default="", max_length=1000)


class StatusInput(BaseModel):
    status: str


class ConfirmedSavingInput(BaseModel):
    confirmed_saving_hours: float = Field(..., ge=0, le=168)
    adoption_rate_pct: Optional[int] = Field(default=None, ge=0, le=100)
    quality_score_pct: Optional[int] = Field(default=None, ge=0, le=100)
    governance_notes: Optional[str] = Field(default=None, max_length=2000)
    after_evidence_url: Optional[str] = Field(default=None, max_length=1000)
    measurement_owner: Optional[str] = Field(default=None, max_length=100)
    sample_size: Optional[int] = Field(default=None, ge=0, le=1000000)
    approval_status: Optional[str] = Field(default=None, max_length=80)
    decision_needed: Optional[str] = Field(default=None, max_length=1000)


class WorkflowMeasurementInput(BaseModel):
    confirmed_saving_hours: Optional[float] = Field(default=None, ge=0, le=168)
    adoption_rate_pct: Optional[int] = Field(default=None, ge=0, le=100)
    quality_score_pct: Optional[int] = Field(default=None, ge=0, le=100)
    baseline_cycle_time_minutes: Optional[float] = Field(default=None, ge=0, le=10080)
    target_cycle_time_minutes: Optional[float] = Field(default=None, ge=0, le=10080)
    governance_notes: Optional[str] = Field(default=None, max_length=2000)
    evidence_url: Optional[str] = Field(default=None, max_length=1000)
    baseline_evidence_url: Optional[str] = Field(default=None, max_length=1000)
    after_evidence_url: Optional[str] = Field(default=None, max_length=1000)
    measurement_owner: Optional[str] = Field(default=None, max_length=100)
    sample_size: Optional[int] = Field(default=None, ge=0, le=1000000)
    approval_status: Optional[str] = Field(default=None, max_length=80)
    decision_needed: Optional[str] = Field(default=None, max_length=1000)


class CommentInput(BaseModel):
    author: Optional[str] = Field(default="Anonymous", max_length=100)
    body: str = Field(..., min_length=1, max_length=2000)


# ============================================================
# HELPER FUNCTIONS
# ============================================================


def now():
    return datetime.utcnow()


def safe_json_loads(value, fallback):
    try:
        if value:
            return json.loads(value)
        return fallback
    except Exception:
        return fallback


def require_role(
    allowed_roles,
    x_api_key: Optional[str] = Header(default=None),
    x_user_role: Optional[str] = Header(default="viewer"),
    x_actor: Optional[str] = Header(default="demo-user"),
) -> dict:
    role = (x_user_role or "viewer").lower()

    if role not in VALID_ROLES:
        raise HTTPException(status_code=403, detail="Invalid role")

    if AI_OS_API_KEY:
        if not x_api_key or x_api_key != AI_OS_API_KEY:
            raise HTTPException(status_code=401, detail="Invalid or missing API key")

        if role not in allowed_roles:
            raise HTTPException(
                status_code=403, detail="Role cannot perform this action"
            )

    return {
        "actor": x_actor or "demo-user",
        "role": role,
        "auth_enforced": bool(AI_OS_API_KEY),
    }


def require_write_access(
    x_api_key: Optional[str] = Header(default=None),
    x_user_role: Optional[str] = Header(default="admin"),
    x_actor: Optional[str] = Header(default="demo-user"),
) -> dict:
    return require_role(WRITE_ROLES, x_api_key, x_user_role, x_actor)


def require_lead_access(
    x_api_key: Optional[str] = Header(default=None),
    x_user_role: Optional[str] = Header(default="admin"),
    x_actor: Optional[str] = Header(default="demo-user"),
) -> dict:
    return require_role(LEAD_ROLES, x_api_key, x_user_role, x_actor)


def validate_business_impact_type(value: Optional[str]) -> str:
    if value in VALID_BUSINESS_IMPACT_TYPES:
        return value or "Employee Productivity"
    return "Employee Productivity"


def split_affected_teams(value: Optional[str]) -> list:
    return [
        item.strip()
        for item in (value or "").replace(";", ",").split(",")
        if item.strip()
    ]


def calculate_opportunity_score(
    hours: int,
    pain: int,
    impact_type: str,
    affected_teams: str,
    confidence: str,
    risk: str,
    expected_quality_gain_pct: int = 0,
) -> tuple[int, dict]:
    hours_score = min(30, int((hours / 20) * 30)) if hours else 0
    pain_score = pain * 8
    team_count = len(split_affected_teams(affected_teams)) or 1
    reach_score = min(15, team_count * 5)
    impact_score = {
        "Cost Saving": 15,
        "Revenue Growth": 18,
        "Risk Reduction": 16,
        "Customer Experience": 14,
        "Employee Productivity": 12,
        "Quality Improvement": 13,
    }.get(impact_type, 12)
    quality_score = min(10, int((expected_quality_gain_pct or 0) / 10))
    confidence_adjustment = {"High": 6, "Medium": 3, "Low": -3}.get(confidence, 3)
    risk_adjustment = {"Low": 4, "Medium": 0, "High": -8}.get(risk, 0)

    total = max(
        0,
        min(
            100,
            hours_score
            + pain_score
            + reach_score
            + impact_score
            + quality_score
            + confidence_adjustment
            + risk_adjustment,
        ),
    )

    return total, {
        "manual_effort": hours_score,
        "pain": pain_score,
        "company_reach": reach_score,
        "business_impact": impact_score,
        "expected_quality_gain": quality_score,
        "confidence_adjustment": confidence_adjustment,
        "risk_adjustment": risk_adjustment,
        "total": total,
    }


def calculate_priority(score: int) -> str:
    if score >= PRIORITY_HIGH:
        return "High Priority"
    if score >= PRIORITY_MEDIUM:
        return "Medium Priority"
    return "Low Priority"


def get_badge_class(score: int) -> str:
    if score >= PRIORITY_HIGH:
        return "high"
    if score >= PRIORITY_MEDIUM:
        return "medium"
    return "low"


def get_status_class(status: str) -> str:
    return {
        "New": "s-new",
        "Backlog": "s-backlog",
        "Validation Needed": "s-validation",
        "Under Review": "s-review",
        "Prototype Built": "s-prototype",
        "Pilot": "s-pilot",
        "Scaling": "s-scaling",
        "Deployed": "s-deployed",
    }.get(status, "s-new")


def get_next_status(status: str) -> str:
    return {
        "New": "Validation Needed",
        "Backlog": "Validation Needed",
        "Validation Needed": "Under Review",
        "Under Review": "Prototype Built",
        "Prototype Built": "Pilot",
        "Pilot": "Scaling",
        "Scaling": "Deployed",
    }.get(status, "Deployed")


def get_action_label(status: str) -> str:
    return {
        "New": "Move to Review",
        "Backlog": "Validate",
        "Validation Needed": "Move to Review",
        "Under Review": "Mark Prototype",
        "Prototype Built": "Start Pilot",
        "Pilot": "Scale",
        "Scaling": "Mark Deployed",
        "Deployed": "Completed",
    }.get(status, "Completed")


def days_in_stage(stage_entered_at) -> int:
    if not stage_entered_at:
        return 0

    return max(0, (now() - stage_entered_at).days)


def can_transition(current_status: str, new_status: str) -> bool:
    return new_status in STATUS_TRANSITIONS.get(current_status or "New", [])


def record_stage_change(
    workflow: WorkflowDB,
    new_status: str,
    strict: bool = True,
) -> bool:
    current_status = workflow.status or "New"

    if new_status == current_status:
        return True

    if not can_transition(current_status, new_status):
        if strict:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid transition from {current_status} to {new_status}",
            )
        return False

    history = safe_json_loads(workflow.stage_history, [])

    if history and history[-1].get("exited") is None:
        history[-1]["exited"] = now().isoformat()

    history.append({"stage": new_status, "entered": now().isoformat(), "exited": None})

    workflow.stage_history = json.dumps(history)
    workflow.stage_entered_at = now()
    return True


def generate_next_step(score: int, status: str) -> str:
    if status == "Backlog":
        return "Keep documented until business value increases"

    if status == "Validation Needed":
        return "Validate with team owner"

    if status == "Under Review":
        return "Confirm owner and build prototype"

    if status == "Prototype Built":
        return "Start a measured pilot with named users"

    if status == "Pilot":
        return "Track adoption, quality, and savings"

    if status == "Scaling":
        return "Confirm controls and roll out company-wide"

    if status == "Deployed":
        return "Measure adoption and actual saving"

    if score >= PRIORITY_HIGH:
        return "Run engine and move to review"

    if score >= PRIORITY_MEDIUM:
        return "Run engine and validate"

    return "Run engine and place in backlog"


def calculate_readiness_score(hours: int, pain: int, risk: str, confidence: str) -> int:
    score = 40

    if hours >= 5:
        score += 20
    elif hours >= 2:
        score += 10

    score += pain * 5

    if confidence == "High":
        score += 15
    elif confidence == "Medium":
        score += 8

    if risk == "Low":
        score += 10
    elif risk == "High":
        score -= 10

    return max(0, min(score, 100))


def log_audit_event(
    db,
    workflow_id: Optional[int],
    actor: str,
    role: str,
    action: str,
    details: Optional[dict] = None,
):
    db.add(
        WorkflowAuditDB(
            workflow_id=workflow_id,
            actor=actor or "system",
            role=role or "system",
            action=action,
            details_json=json.dumps(details or {}),
            created_at=now(),
        )
    )


def keyword_analysis(task_name: str, team: str = "", notes: str = "") -> dict:
    text_value = f"{task_name} {team} {notes}".lower()

    result = {
        "suggestion": "AI workflow automation prototype",
        "automation_plan": "Map the workflow, identify repeatable rules, build a small prototype, test with users, and measure time saved.",
        "prototype_plan": [
            "Data needed: examples of the current manual workflow",
            "Prototype: automate the repeatable part of the process",
            "Success metric: reduce task completion time by at least 30%",
            "Risk: workflow may need human judgement in edge cases",
            "Human check: process owner validates prototype output",
        ],
        "estimated_effort_days": 10,
        "confidence": "Medium",
        "risk_level": "Medium",
    }

    if "ticket" in text_value or "support" in text_value or "categor" in text_value:
        result.update(
            {
                "suggestion": "AI ticket classifier with auto-routing",
                "automation_plan": "Collect historical tickets, define categories, build a classifier, test routing accuracy, and deploy with human approval for edge cases.",
                "prototype_plan": [
                    "Data needed: 100-300 historical support tickets",
                    "Prototype: classify tickets into categories and suggested routes",
                    "Success metric: reduce manual triage time by 40-60%",
                    "Risk: incorrect routing of urgent or sensitive tickets",
                    "Human check: support lead approves category logic",
                ],
                "estimated_effort_days": 7,
                "confidence": "High",
                "risk_level": "Medium",
            }
        )

    elif "report" in text_value or "spreadsheet" in text_value or "csv" in text_value:
        result.update(
            {
                "suggestion": "Automated reporting agent",
                "automation_plan": "Connect to source data, generate summary tables, produce written insights, and schedule recurring delivery.",
                "prototype_plan": [
                    "Data needed: sample weekly reports and source CSV files",
                    "Prototype: auto-generate summary tables and written insights",
                    "Success metric: reduce report preparation time by 50%",
                    "Risk: inaccurate figures if source data changes format",
                    "Human check: team owner validates report output",
                ],
                "estimated_effort_days": 5,
                "confidence": "High",
                "risk_level": "Medium",
            }
        )

    elif "meeting" in text_value or "notes" in text_value or "summary" in text_value:
        result.update(
            {
                "suggestion": "Meeting summary and action tracker",
                "automation_plan": "Capture meeting text, extract decisions and owners, create action items, and push them into a tracker.",
                "prototype_plan": [
                    "Data needed: meeting transcripts or notes",
                    "Prototype: extract decisions, action owners, and deadlines",
                    "Success metric: reduce follow-up admin time by 30-50%",
                    "Risk: missed context or incorrect action ownership",
                    "Human check: meeting owner confirms action list",
                ],
                "estimated_effort_days": 4,
                "confidence": "High",
                "risk_level": "Low",
            }
        )

    elif (
        "document" in text_value
        or "sop" in text_value
        or "knowledge" in text_value
        or "faq" in text_value
    ):
        result.update(
            {
                "suggestion": "Internal knowledge search assistant",
                "automation_plan": "Collect verified documents, index them, build retrieval-based Q&A, and require cited answers for validation.",
                "prototype_plan": [
                    "Data needed: SOPs, FAQs, policy docs, and internal guides",
                    "Prototype: searchable knowledge assistant with cited answers",
                    "Success metric: reduce repeated internal questions by 30%",
                    "Risk: outdated documents producing wrong answers",
                    "Human check: document owner validates answer quality",
                ],
                "estimated_effort_days": 12,
                "confidence": "Medium",
                "risk_level": "High",
            }
        )

    elif (
        "feedback" in text_value or "review" in text_value or "sentiment" in text_value
    ):
        result.update(
            {
                "suggestion": "Customer feedback sentiment analysis dashboard",
                "automation_plan": "Collect feedback, classify sentiment and recurring themes, then show trends and priority issues in a dashboard.",
                "prototype_plan": [
                    "Data needed: customer feedback, reviews, or survey comments",
                    "Prototype: sentiment and theme classification dashboard",
                    "Success metric: identify recurring pain points faster",
                    "Risk: sentiment misclassification on ambiguous feedback",
                    "Human check: customer success lead reviews themes",
                ],
                "estimated_effort_days": 6,
                "confidence": "High",
                "risk_level": "Low",
            }
        )

    elif "email" in text_value or "reply" in text_value or "inbox" in text_value:
        result.update(
            {
                "suggestion": "AI email triage and response assistant",
                "automation_plan": "Classify incoming emails, draft suggested replies, route urgent messages, and keep human approval before sending.",
                "prototype_plan": [
                    "Data needed: common email examples and response templates",
                    "Prototype: classify emails and draft suggested responses",
                    "Success metric: reduce first-response drafting time by 40%",
                    "Risk: sending unsuitable responses without review",
                    "Human check: all replies require approval before sending",
                ],
                "estimated_effort_days": 8,
                "confidence": "Medium",
                "risk_level": "High",
            }
        )

    return result


async def llm_analyse(
    task_name: str, team: str, hours: int, pain: int, notes: str
) -> dict:
    fallback = keyword_analysis(task_name, team, notes)

    system_prompt = (
        "You are an AI automation consultant. Return only valid JSON. No markdown."
    )

    user_prompt = f"""
Analyse this workflow for AI automation potential.

Team: {team}
Task: {task_name}
Hours per week: {hours}
Pain level: {pain}/5
Notes: {notes or 'None'}

Return JSON with exactly these keys:
suggestion, automation_plan, prototype_plan, estimated_effort_days, confidence, risk_level.

prototype_plan must be an array of exactly 5 strings.
confidence must be High, Medium, or Low.
risk_level must be Low, Medium, or High.
"""

    if GEMINI_API_KEY and genai is not None:
        try:
            client = genai.Client(api_key=GEMINI_API_KEY)
            response = client.models.generate_content(
                model=GEMINI_MODEL,
                contents=f"{system_prompt}\n\n{user_prompt}",
            )
            raw = getattr(response, "text", "") or ""
            clean = (
                raw.strip()
                .removeprefix("```json")
                .removeprefix("```")
                .removesuffix("```")
                .strip()
            )
            data = json.loads(clean)
            required = [
                "suggestion",
                "automation_plan",
                "prototype_plan",
                "estimated_effort_days",
                "confidence",
                "risk_level",
            ]

            if all(key in data for key in required):
                return data

        except Exception:
            return fallback

    return fallback


def clean_text(value, fallback="Not recorded") -> str:
    if value is None:
        return fallback
    text_value = str(value).strip()
    return text_value if text_value else fallback


def format_gbp(value) -> str:
    try:
        return f"£{float(value):,.0f}"
    except Exception:
        return "Not recorded"


def generate_opportunity_brief(workflow: WorkflowDB) -> str:
    prototype_plan = safe_json_loads(workflow.prototype_plan_json, [])
    estimated_annual = (workflow.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP
    confirmed_annual = (workflow.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP

    evidence_items = [
        f"General evidence: {clean_text(workflow.evidence_url)}",
        f"Baseline evidence: {clean_text(workflow.baseline_evidence_url)}",
        f"After evidence: {clean_text(workflow.after_evidence_url)}",
    ]

    data_needed = prototype_plan if prototype_plan else [
        "Collect examples of the current workflow",
        "Confirm baseline time and quality with the process owner",
        "Run a small pilot before scaling",
    ]

    lines = [
        "AI Opportunity Brief",
        "=" * 60,
        "",
        f"Workflow: {clean_text(workflow.task_name)}",
        f"Team: {clean_text(workflow.team)}",
        f"Owner: {clean_text(workflow.owner, 'Unassigned')}",
        f"Affected teams: {clean_text(workflow.affected_teams or workflow.team)}",
        f"Business impact type: {clean_text(workflow.business_impact_type, 'Employee Productivity')}",
        "",
        "Problem",
        "-" * 60,
        clean_text(workflow.notes, "No problem notes have been recorded yet."),
        "",
        "Current Effort and Measurement",
        "-" * 60,
        f"Current effort: {workflow.time_spent_per_week or 0} hours/week",
        f"Pain level: {workflow.pain_level or 0}/5",
        f"Frequency: {clean_text(workflow.frequency)}",
        f"Before/after cycle time: {workflow.baseline_cycle_time_minutes or 0:g} -> {workflow.target_cycle_time_minutes or 0:g} minutes",
        f"Sample size: {workflow.sample_size or 0 if workflow.sample_size is not None else 0}",
        f"Measurement owner: {clean_text(workflow.measurement_owner, 'Unassigned')}",
        "",
        "Business Value",
        "-" * 60,
        f"Impact score: {workflow.impact_score or 0}/100",
        f"Priority: {clean_text(workflow.recommendation)}",
        f"Readiness score: {workflow.readiness_score or 0}%",
        f"Estimated annual saving: {format_gbp(estimated_annual)}",
        f"Confirmed annual saving: {format_gbp(confirmed_annual) if workflow.confirmed_saving_hours else 'Not recorded yet'}",
        f"Adoption rate: {workflow.adoption_rate_pct or 0}%",
        f"Quality score: {workflow.quality_score_pct or 0}%",
        "",
        "AI Recommendation",
        "-" * 60,
        f"AI suggestion: {clean_text(workflow.ai_suggestion, 'Not generated')}",
        f"Prototype plan: {clean_text(workflow.automation_plan, 'Not generated')}",
        "",
        "Data and Evidence Needed",
        "-" * 60,
    ]

    for item in evidence_items:
        lines.append(f"- {item}")

    for item in data_needed:
        lines.append(f"- {item}")

    lines += [
        "",
        "Risk and Governance",
        "-" * 60,
        f"Risk level: {clean_text(workflow.risk_level, 'Medium')}",
        f"Confidence: {clean_text(workflow.confidence, 'Medium')}",
        f"Governance notes: {clean_text(workflow.governance_notes, 'No governance notes recorded yet.')}",
        f"Approval status: {clean_text(workflow.approval_status, 'Not Reviewed')}",
        "",
        "Decision Needed",
        "-" * 60,
        clean_text(workflow.decision_needed, "Confirm whether this opportunity should move to validation, prototype, pilot, or backlog."),
        "",
        "No figures in this brief are generated or invented. It uses only stored workflow data.",
    ]

    return "\n".join(lines)


def workflow_to_dict(w: WorkflowDB) -> dict:
    return {
        "id": w.id,
        "team": w.team,
        "task_name": w.task_name,
        "owner": w.owner,
        "affected_teams": w.affected_teams,
        "affected_team_list": split_affected_teams(w.affected_teams),
        "business_impact_type": w.business_impact_type,
        "time_spent_per_week": w.time_spent_per_week,
        "pain_level": w.pain_level,
        "frequency": w.frequency,
        "baseline_cycle_time_minutes": w.baseline_cycle_time_minutes,
        "target_cycle_time_minutes": w.target_cycle_time_minutes,
        "impact_score": w.impact_score,
        "score_breakdown": safe_json_loads(w.score_breakdown_json, {}),
        "recommendation": w.recommendation,
        "status": w.status,
        "notes": w.notes,
        "ai_suggestion": w.ai_suggestion,
        "automation_plan": w.automation_plan,
        "prototype_plan": safe_json_loads(w.prototype_plan_json, []),
        "estimated_effort_days": w.estimated_effort_days,
        "confidence": w.confidence,
        "risk_level": w.risk_level,
        "readiness_score": w.readiness_score,
        "confirmed_saving_hours": w.confirmed_saving_hours,
        "adoption_rate_pct": w.adoption_rate_pct,
        "quality_score_pct": w.quality_score_pct,
        "expected_quality_gain_pct": w.expected_quality_gain_pct,
        "governance_notes": w.governance_notes,
        "evidence_url": w.evidence_url,
        "baseline_evidence_url": w.baseline_evidence_url,
        "after_evidence_url": w.after_evidence_url,
        "measurement_owner": w.measurement_owner,
        "sample_size": w.sample_size,
        "approval_status": w.approval_status,
        "decision_needed": w.decision_needed,
        "estimated_annual_saving_gbp": (w.time_spent_per_week or 0)
        * 52
        * HOURLY_COST_GBP,
        "confirmed_annual_saving_gbp": (w.confirmed_saving_hours or 0)
        * 52
        * HOURLY_COST_GBP,
        "days_in_stage": days_in_stage(w.stage_entered_at),
        "created_at": w.created_at.isoformat() if w.created_at else None,
        "updated_at": w.updated_at.isoformat() if w.updated_at else None,
    }


# ============================================================
# API ENDPOINTS
# ============================================================


@app.get("/health")
def health():
    return {
        "status": "ok",
        "timestamp": now().isoformat(),
        "auth_enforced": bool(AI_OS_API_KEY),
    }


@app.get("/")
def home():
    return {
        "message": "AI Impact OS — Workflow Intelligence Engine is running",
        "dashboard": "/dashboard-ui",
    }


@app.post("/submit-workflow")
async def submit_workflow(
    data: WorkflowInput, auth: dict = Depends(require_write_access)
):
    ai = await llm_analyse(
        data.task_name,
        data.team,
        data.time_spent_per_week,
        data.pain_level,
        data.notes or "",
    )

    impact_type = validate_business_impact_type(data.business_impact_type)
    impact_score, score_breakdown = calculate_opportunity_score(
        data.time_spent_per_week,
        data.pain_level,
        impact_type,
        data.affected_teams or data.team,
        ai.get("confidence", "Medium"),
        ai.get("risk_level", "Medium"),
        data.expected_quality_gain_pct or 0,
    )

    readiness = calculate_readiness_score(
        data.time_spent_per_week,
        data.pain_level,
        ai.get("risk_level", "Medium"),
        ai.get("confidence", "Medium"),
    )

    db = SessionLocal()

    try:
        current_time = now()

        workflow = WorkflowDB(
            team=data.team,
            task_name=data.task_name,
            owner=data.owner or "",
            affected_teams=data.affected_teams or data.team,
            business_impact_type=impact_type,
            time_spent_per_week=data.time_spent_per_week,
            pain_level=data.pain_level,
            frequency=data.frequency,
            baseline_cycle_time_minutes=data.baseline_cycle_time_minutes or 0,
            target_cycle_time_minutes=data.target_cycle_time_minutes or 0,
            impact_score=impact_score,
            recommendation=calculate_priority(impact_score),
            status="New",
            score_breakdown_json=json.dumps(score_breakdown),
            notes=data.notes or "",
            ai_suggestion=ai.get("suggestion", "AI workflow automation prototype"),
            automation_plan=ai.get(
                "automation_plan", "Map the workflow and build a prototype."
            ),
            prototype_plan_json=json.dumps(ai.get("prototype_plan", [])),
            estimated_effort_days=int(ai.get("estimated_effort_days", 10)),
            confidence=ai.get("confidence", "Medium"),
            risk_level=ai.get("risk_level", "Medium"),
            readiness_score=readiness,
            expected_quality_gain_pct=data.expected_quality_gain_pct or 0,
            evidence_url=data.evidence_url or "",
            baseline_evidence_url=data.baseline_evidence_url or "",
            after_evidence_url=data.after_evidence_url or "",
            measurement_owner=data.measurement_owner or data.owner or "",
            sample_size=data.sample_size or 0,
            approval_status=data.approval_status or "Not Reviewed",
            decision_needed=data.decision_needed or "",
            created_at=current_time,
            updated_at=current_time,
            stage_entered_at=current_time,
            stage_history=json.dumps(
                [{"stage": "New", "entered": current_time.isoformat(), "exited": None}]
            ),
        )

        db.add(workflow)
        db.flush()
        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "workflow_created",
            {
                "impact_score": impact_score,
                "recommendation": calculate_priority(impact_score),
                "business_impact_type": impact_type,
            },
        )
        db.commit()
        db.refresh(workflow)

        return workflow_to_dict(workflow)

    finally:
        db.close()


@app.get("/workflows")
def get_workflows():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc()).all()

        return [workflow_to_dict(w) for w in workflows]

    finally:
        db.close()


@app.get("/workflows/{workflow_id}")
def get_workflow(workflow_id: int):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        comments = (
            db.query(WorkflowCommentDB)
            .filter(WorkflowCommentDB.workflow_id == workflow_id)
            .order_by(WorkflowCommentDB.created_at.asc())
            .all()
        )

        audit_events = (
            db.query(WorkflowAuditDB)
            .filter(WorkflowAuditDB.workflow_id == workflow_id)
            .order_by(WorkflowAuditDB.created_at.asc())
            .all()
        )

        data = workflow_to_dict(workflow)

        data["stage_history"] = safe_json_loads(workflow.stage_history, [])
        data["comments"] = [
            {
                "id": c.id,
                "author": c.author,
                "body": c.body,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in comments
        ]
        data["audit_events"] = [
            {
                "id": event.id,
                "actor": event.actor,
                "role": event.role,
                "action": event.action,
                "details": safe_json_loads(event.details_json, {}),
                "created_at": (
                    event.created_at.isoformat() if event.created_at else None
                ),
            }
            for event in audit_events
        ]

        return data

    finally:
        db.close()


@app.get("/workflows/{workflow_id}/brief", response_class=PlainTextResponse)
def get_workflow_brief(workflow_id: int):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        return generate_opportunity_brief(workflow)

    finally:
        db.close()


@app.post("/workflows/{workflow_id}/comments")
def add_comment(
    workflow_id: int,
    comment: CommentInput,
    auth: dict = Depends(require_write_access),
):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        new_comment = WorkflowCommentDB(
            workflow_id=workflow_id,
            author=comment.author or "Anonymous",
            body=comment.body,
            created_at=now(),
        )

        db.add(new_comment)
        log_audit_event(
            db,
            workflow_id,
            auth["actor"],
            auth["role"],
            "comment_added",
            {"author": comment.author or "Anonymous"},
        )
        db.commit()
        db.refresh(new_comment)

        return {"comment_id": new_comment.id}

    finally:
        db.close()


@app.put("/workflows/{workflow_id}/confirmed-saving")
def update_confirmed_saving(
    workflow_id: int,
    data: ConfirmedSavingInput,
    auth: dict = Depends(require_write_access),
):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        workflow.confirmed_saving_hours = data.confirmed_saving_hours
        if data.adoption_rate_pct is not None:
            workflow.adoption_rate_pct = data.adoption_rate_pct
        if data.quality_score_pct is not None:
            workflow.quality_score_pct = data.quality_score_pct
        if data.governance_notes is not None:
            workflow.governance_notes = data.governance_notes
        if data.after_evidence_url is not None:
            workflow.after_evidence_url = data.after_evidence_url
        if data.measurement_owner is not None:
            workflow.measurement_owner = data.measurement_owner
        if data.sample_size is not None:
            workflow.sample_size = data.sample_size
        if data.approval_status is not None:
            workflow.approval_status = data.approval_status
        if data.decision_needed is not None:
            workflow.decision_needed = data.decision_needed
        workflow.updated_at = now()

        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "measurement_updated",
            {
                "confirmed_saving_hours": workflow.confirmed_saving_hours,
                "adoption_rate_pct": workflow.adoption_rate_pct,
                "quality_score_pct": workflow.quality_score_pct,
            },
        )
        db.commit()
        db.refresh(workflow)

        estimated = (workflow.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP
        confirmed = data.confirmed_saving_hours * 52 * HOURLY_COST_GBP

        return {
            "workflow_id": workflow.id,
            "confirmed_annual_saving_gbp": confirmed,
            "estimated_annual_saving_gbp": estimated,
            "accuracy_pct": round((confirmed / estimated) * 100, 1) if estimated else 0,
            "adoption_rate_pct": workflow.adoption_rate_pct,
            "quality_score_pct": workflow.quality_score_pct,
        }

    finally:
        db.close()


@app.put("/workflows/{workflow_id}/measurement")
def update_measurement(
    workflow_id: int,
    data: WorkflowMeasurementInput,
    auth: dict = Depends(require_write_access),
):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        changed = {}

        for field in [
            "confirmed_saving_hours",
            "adoption_rate_pct",
            "quality_score_pct",
            "baseline_cycle_time_minutes",
            "target_cycle_time_minutes",
            "governance_notes",
            "evidence_url",
            "baseline_evidence_url",
            "after_evidence_url",
            "measurement_owner",
            "sample_size",
            "approval_status",
            "decision_needed",
        ]:
            value = getattr(data, field)
            if value is not None:
                setattr(workflow, field, value)
                changed[field] = value

        workflow.updated_at = now()

        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "measurement_updated",
            changed,
        )
        db.commit()
        db.refresh(workflow)

        return workflow_to_dict(workflow)

    finally:
        db.close()


@app.post("/workflows/{workflow_id}/reanalyse")
async def reanalyse_workflow(
    workflow_id: int, auth: dict = Depends(require_write_access)
):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        ai = await llm_analyse(
            workflow.task_name or "",
            workflow.team or "",
            workflow.time_spent_per_week or 0,
            workflow.pain_level or 1,
            workflow.notes or "",
        )

        workflow.ai_suggestion = ai.get("suggestion", workflow.ai_suggestion)
        workflow.automation_plan = ai.get("automation_plan", workflow.automation_plan)
        workflow.prototype_plan_json = json.dumps(
            ai.get("prototype_plan", safe_json_loads(workflow.prototype_plan_json, []))
        )
        workflow.estimated_effort_days = int(
            ai.get("estimated_effort_days", workflow.estimated_effort_days or 10)
        )
        workflow.confidence = ai.get("confidence", workflow.confidence or "Medium")
        workflow.risk_level = ai.get("risk_level", workflow.risk_level or "Medium")
        impact_score, score_breakdown = calculate_opportunity_score(
            workflow.time_spent_per_week or 0,
            workflow.pain_level or 1,
            workflow.business_impact_type or "Employee Productivity",
            workflow.affected_teams or workflow.team or "",
            workflow.confidence or "Medium",
            workflow.risk_level or "Medium",
            workflow.expected_quality_gain_pct or 0,
        )
        workflow.impact_score = impact_score
        workflow.recommendation = calculate_priority(impact_score)
        workflow.score_breakdown_json = json.dumps(score_breakdown)

        workflow.readiness_score = calculate_readiness_score(
            workflow.time_spent_per_week or 0,
            workflow.pain_level or 1,
            workflow.risk_level or "Medium",
            workflow.confidence or "Medium",
        )

        workflow.updated_at = now()

        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "workflow_reanalysed",
            {
                "impact_score": workflow.impact_score,
                "recommendation": workflow.recommendation,
            },
        )
        db.commit()
        db.refresh(workflow)

        return workflow_to_dict(workflow)

    finally:
        db.close()


@app.put("/update-status/{workflow_id}")
def update_status(
    workflow_id: int,
    status_input: StatusInput,
    auth: dict = Depends(require_lead_access),
):
    if status_input.status not in VALID_STATUSES:
        raise HTTPException(
            status_code=400, detail=f"Invalid status. Use: {VALID_STATUSES}"
        )

    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        if workflow.status != status_input.status:
            previous_status = workflow.status
            record_stage_change(workflow, status_input.status)
            log_audit_event(
                db,
                workflow.id,
                auth["actor"],
                auth["role"],
                "status_changed",
                {"from": previous_status, "to": status_input.status},
            )

        workflow.status = status_input.status
        workflow.updated_at = now()

        db.commit()
        db.refresh(workflow)

        return {"workflow_id": workflow.id, "status": workflow.status}

    finally:
        db.close()


@app.put("/advance-status/{workflow_id}")
def advance_status(workflow_id: int, auth: dict = Depends(require_lead_access)):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        new_status = get_next_status(workflow.status or "New")

        if workflow.status != new_status:
            previous_status = workflow.status
            record_stage_change(workflow, new_status)
            workflow.status = new_status
            workflow.updated_at = now()
            log_audit_event(
                db,
                workflow.id,
                auth["actor"],
                auth["role"],
                "status_advanced",
                {"from": previous_status, "to": new_status},
            )

            db.commit()
            db.refresh(workflow)

        return {"workflow_id": workflow.id, "new_status": workflow.status}

    finally:
        db.close()


@app.delete("/delete-workflow/{workflow_id}")
def delete_workflow(workflow_id: int, auth: dict = Depends(require_lead_access)):
    db = SessionLocal()

    try:
        workflow = db.query(WorkflowDB).filter(WorkflowDB.id == workflow_id).first()

        if workflow is None:
            raise HTTPException(status_code=404, detail="Workflow not found")

        db.query(WorkflowCommentDB).filter(
            WorkflowCommentDB.workflow_id == workflow_id
        ).delete()
        log_audit_event(
            db,
            workflow.id,
            auth["actor"],
            auth["role"],
            "workflow_deleted",
            {
                "team": workflow.team,
                "task_name": workflow.task_name,
                "status": workflow.status,
            },
        )

        db.delete(workflow)
        db.commit()

        return {"message": "Workflow deleted successfully"}

    finally:
        db.close()


@app.post("/run-automation-engine")
def run_automation_engine(auth: dict = Depends(require_lead_access)):
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).all()

        analysed = len(workflows)
        updated = 0
        high = 0
        medium = 0
        low = 0
        protected = 0

        for workflow in workflows:
            score, score_breakdown = calculate_opportunity_score(
                workflow.time_spent_per_week or 0,
                workflow.pain_level or 1,
                workflow.business_impact_type or "Employee Productivity",
                workflow.affected_teams or workflow.team or "",
                workflow.confidence or "Medium",
                workflow.risk_level or "Medium",
                workflow.expected_quality_gain_pct or 0,
            )
            workflow.impact_score = score
            workflow.recommendation = calculate_priority(score)
            workflow.score_breakdown_json = json.dumps(score_breakdown)
            current_status = workflow.status or "New"

            if current_status not in ["New", "Backlog", "Validation Needed"]:
                protected += 1
                continue

            if score >= PRIORITY_HIGH:
                new_status = "Under Review"
                high += 1
            elif score >= PRIORITY_MEDIUM:
                new_status = "Validation Needed"
                medium += 1
            else:
                new_status = "Backlog"
                low += 1

            if new_status != current_status:
                transitioned = record_stage_change(workflow, new_status, strict=False)

                if not transitioned:
                    protected += 1
                    continue

                workflow.status = new_status
                workflow.updated_at = now()
                log_audit_event(
                    db,
                    workflow.id,
                    auth["actor"],
                    auth["role"],
                    "engine_status_classified",
                    {"from": current_status, "to": new_status, "score": score},
                )
                updated += 1

        run = EngineRunDB(
            run_at=now(),
            analysed_workflows=analysed,
            updated_workflows=updated,
            high_priority_moved_to_review=high,
            medium_priority_moved_to_validation=medium,
            low_priority_moved_to_backlog=low,
            protected_unchanged=protected,
        )

        db.add(run)
        log_audit_event(
            db,
            None,
            auth["actor"],
            auth["role"],
            "engine_run",
            {
                "analysed": analysed,
                "updated": updated,
                "to_review": high,
                "to_validation": medium,
                "to_backlog": low,
                "protected": protected,
            },
        )
        db.commit()
        db.refresh(run)

        return {
            "message": "Automation engine completed",
            "run_id": run.id,
            "analysed": analysed,
            "updated": updated,
            "to_review": high,
            "to_validation": medium,
            "to_backlog": low,
            "protected": protected,
        }

    finally:
        db.close()


@app.get("/engine-runs")
def get_engine_runs(limit: int = 10):
    db = SessionLocal()

    try:
        runs = (
            db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).limit(limit).all()
        )

        return [
            {
                "id": r.id,
                "run_at": r.run_at.isoformat() if r.run_at else None,
                "analysed": r.analysed_workflows,
                "updated": r.updated_workflows,
                "to_review": r.high_priority_moved_to_review,
                "to_validation": r.medium_priority_moved_to_validation,
                "to_backlog": r.low_priority_moved_to_backlog,
                "protected": r.protected_unchanged,
            }
            for r in runs
        ]

    finally:
        db.close()


@app.get("/executive-summary")
def executive_summary():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).all()

        deployed = [w for w in workflows if (w.status or "") == "Deployed"]

        in_progress = [
            w
            for w in workflows
            if (w.status or "")
            in [
                "Validation Needed",
                "Under Review",
                "Prototype Built",
                "Pilot",
                "Scaling",
            ]
        ]

        high_priority = [w for w in workflows if (w.impact_score or 0) >= PRIORITY_HIGH]

        active_measurements = [
            w for w in workflows if (w.status or "") in ["Pilot", "Scaling", "Deployed"]
        ]

        measured_adoption = [
            w.adoption_rate_pct or 0
            for w in active_measurements
            if (w.adoption_rate_pct or 0) > 0
        ]

        measured_quality = [
            w.quality_score_pct or 0
            for w in active_measurements
            if (w.quality_score_pct or 0) > 0
        ]

        high_risk = [w for w in workflows if (w.risk_level or "Medium") == "High"]

        missing_evidence = [
            w
            for w in workflows
            if not (w.evidence_url or w.baseline_evidence_url or w.after_evidence_url)
        ]

        pending_approval = [
            w
            for w in workflows
            if (w.approval_status or "Not Reviewed") not in ["Approved", "approved"]
        ]

        impact_mix = {}

        for w in workflows:
            impact_type = w.business_impact_type or "Employee Productivity"
            impact_mix[impact_type] = impact_mix.get(impact_type, 0) + 1

        estimated = (
            sum(w.time_spent_per_week or 0 for w in workflows) * 52 * HOURLY_COST_GBP
        )

        confirmed = (
            sum((w.confirmed_saving_hours or 0) for w in deployed)
            * 52
            * HOURLY_COST_GBP
        )

        deploy_days = [(now() - w.created_at).days for w in deployed if w.created_at]

        average_days_to_deploy = (
            round(sum(deploy_days) / len(deploy_days), 1) if deploy_days else 0
        )

        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()

        top_wins = sorted(
            deployed, key=lambda x: x.confirmed_saving_hours or 0, reverse=True
        )[:5]

        return {
            "summary": {
                "total_workflows": len(workflows),
                "deployed": len(deployed),
                "in_progress": len(in_progress),
                "high_priority": len(high_priority),
                "high_risk": len(high_risk),
                "pilots_or_scaling": len(active_measurements),
                "average_days_to_deploy": average_days_to_deploy,
                "missing_evidence": len(missing_evidence),
                "pending_approval": len(pending_approval),
            },
            "roi": {
                "estimated_annual_saving_gbp": estimated,
                "confirmed_annual_saving_gbp": confirmed,
                "accuracy_pct": (
                    round((confirmed / estimated) * 100, 1) if estimated else 0
                ),
                "hourly_rate_gbp": HOURLY_COST_GBP,
            },
            "operating_metrics": {
                "average_adoption_rate_pct": (
                    round(sum(measured_adoption) / len(measured_adoption), 1)
                    if measured_adoption
                    else 0
                ),
                "average_quality_score_pct": (
                    round(sum(measured_quality) / len(measured_quality), 1)
                    if measured_quality
                    else 0
                ),
                "impact_mix": impact_mix,
                "auth_enforced": bool(AI_OS_API_KEY),
                "evidence_coverage_pct": round(((len(workflows) - len(missing_evidence)) / len(workflows)) * 100, 1) if workflows else 0,
            },
            "top_deployed_wins": [workflow_to_dict(w) for w in top_wins],
            "last_engine_run": {
                "run_at": (
                    last_run.run_at.isoformat()
                    if last_run and last_run.run_at
                    else "Never"
                ),
                "analysed": last_run.analysed_workflows if last_run else 0,
                "updated": last_run.updated_workflows if last_run else 0,
            },
        }

    finally:
        db.close()


@app.get("/dashboard")
def dashboard():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).all()

        deployed = [w for w in workflows if (w.status or "") == "Deployed"]

        in_progress = [
            w
            for w in workflows
            if (w.status or "")
            in ["Validation Needed", "Under Review", "Prototype Built"]
        ]

        estimated = (
            sum(w.time_spent_per_week or 0 for w in workflows) * 52 * HOURLY_COST_GBP
        )

        confirmed = (
            sum((w.confirmed_saving_hours or 0) for w in deployed)
            * 52
            * HOURLY_COST_GBP
        )

        adoption_values = [
            w.adoption_rate_pct or 0
            for w in workflows
            if (w.adoption_rate_pct or 0) > 0
        ]

        quality_values = [
            w.quality_score_pct or 0
            for w in workflows
            if (w.quality_score_pct or 0) > 0
        ]

        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()

        return {
            "total_workflows": len(workflows),
            "estimated_yearly_saving_gbp": estimated,
            "confirmed_annual_saving_gbp": confirmed,
            "in_progress": len(in_progress),
            "deployed": len(deployed),
            "average_adoption_rate_pct": (
                round(sum(adoption_values) / len(adoption_values), 1)
                if adoption_values
                else 0
            ),
            "average_quality_score_pct": (
                round(sum(quality_values) / len(quality_values), 1)
                if quality_values
                else 0
            ),
            "high_risk_workflows": sum(
                1 for w in workflows if (w.risk_level or "Medium") == "High"
            ),
            "last_engine_run": (
                last_run.run_at.isoformat() if last_run and last_run.run_at else "Never"
            ),
        }

    finally:
        db.close()


@app.get("/export-csv")
def export_csv():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc()).all()

        buffer = io.StringIO()
        writer = csv.writer(buffer)

        writer.writerow(
            [
                "ID",
                "Team",
                "Workflow",
                "Owner",
                "Affected Teams",
                "Business Impact Type",
                "Status",
                "Hours/Week",
                "Pain",
                "Baseline Cycle Time Minutes",
                "Target Cycle Time Minutes",
                "Impact Score",
                "Score Breakdown",
                "Priority",
                "AI Suggestion",
                "Automation Plan",
                "Prototype Plan",
                "Effort Days",
                "Confidence",
                "Risk",
                "Readiness",
                "Expected Quality Gain %",
                "Estimated Annual Saving GBP",
                "Confirmed Weekly Saving Hours",
                "Confirmed Annual Saving GBP",
                "Adoption Rate %",
                "Quality Score %",
                "Governance Notes",
                "Evidence URL",
                "Baseline Evidence URL",
                "After Evidence URL",
                "Measurement Owner",
                "Sample Size",
                "Approval Status",
                "Decision Needed",
            ]
        )

        for w in workflows:
            writer.writerow(
                [
                    w.id,
                    w.team,
                    w.task_name,
                    w.owner,
                    w.affected_teams,
                    w.business_impact_type,
                    w.status,
                    w.time_spent_per_week,
                    w.pain_level,
                    w.baseline_cycle_time_minutes,
                    w.target_cycle_time_minutes,
                    w.impact_score,
                    w.score_breakdown_json,
                    w.recommendation,
                    w.ai_suggestion,
                    w.automation_plan,
                    " | ".join(safe_json_loads(w.prototype_plan_json, [])),
                    w.estimated_effort_days,
                    w.confidence,
                    w.risk_level,
                    w.readiness_score,
                    w.expected_quality_gain_pct,
                    (w.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP,
                    w.confirmed_saving_hours,
                    (w.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP,
                    w.adoption_rate_pct,
                    w.quality_score_pct,
                    w.governance_notes,
                    w.evidence_url,
                    w.baseline_evidence_url,
                    w.after_evidence_url,
                    w.measurement_owner,
                    w.sample_size,
                    w.approval_status,
                    w.decision_needed,
                ]
            )

        buffer.seek(0)

        return StreamingResponse(
            iter([buffer.getvalue()]),
            media_type="text/csv",
            headers={
                "Content-Disposition": "attachment; filename=threecolts_ai_automation_export.csv"
            },
        )

    finally:
        db.close()


@app.get("/report", response_class=PlainTextResponse)
def generate_report():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc()).all()

        if not workflows:
            return "AI Impact OS — Workflow Intelligence Engine\n\nNo workflows yet."

        estimated = (
            sum(w.time_spent_per_week or 0 for w in workflows) * 52 * HOURLY_COST_GBP
        )

        deployed = [w for w in workflows if (w.status or "") == "Deployed"]

        confirmed = (
            sum((w.confirmed_saving_hours or 0) for w in deployed)
            * 52
            * HOURLY_COST_GBP
        )

        adoption_values = [
            w.adoption_rate_pct or 0
            for w in workflows
            if (w.adoption_rate_pct or 0) > 0
        ]

        quality_values = [
            w.quality_score_pct or 0
            for w in workflows
            if (w.quality_score_pct or 0) > 0
        ]

        impact_mix = {}

        for w in workflows:
            impact_type = w.business_impact_type or "Employee Productivity"
            impact_mix[impact_type] = impact_mix.get(impact_type, 0) + 1

        missing_evidence = [
            w
            for w in workflows
            if not (w.evidence_url or w.baseline_evidence_url or w.after_evidence_url)
        ]

        pending_approval = [
            w
            for w in workflows
            if (w.approval_status or "Not Reviewed") not in ["Approved", "approved"]
        ]

        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()

        lines = [
            "AI Impact OS — Executive Report",
            "=" * 60,
            "",
            f"Total workflows: {len(workflows)}",
            f"Deployed workflows: {len(deployed)}",
            f"Estimated annual saving: £{estimated:,}",
            f"Confirmed annual saving: £{confirmed:,.0f}",
            f"Hourly value assumption: £{HOURLY_COST_GBP}/hour",
            "",
            f"Average adoption: {round(sum(adoption_values) / len(adoption_values), 1) if adoption_values else 0}%",
            f"Average quality score: {round(sum(quality_values) / len(quality_values), 1) if quality_values else 0}%",
            f"High risk workflows: {sum(1 for w in workflows if (w.risk_level or 'Medium') == 'High')}",
            f"Workflows missing evidence: {len(missing_evidence)}",
            f"Workflows pending approval: {len(pending_approval)}",
            f"Impact mix: {', '.join(f'{k}: {v}' for k, v in sorted(impact_mix.items()))}",
            "Last Automation Engine Run",
            "-" * 60,
            f"Run at: {last_run.run_at.isoformat() if last_run and last_run.run_at else 'Never'}",
            f"Analysed: {last_run.analysed_workflows if last_run else 0}",
            f"Updated: {last_run.updated_workflows if last_run else 0}",
            "",
            "Top Automation Opportunities",
            "-" * 60,
        ]

        for index, w in enumerate(workflows[:8], start=1):
            plan = safe_json_loads(w.prototype_plan_json, [])

            lines += [
                f"{index}. {w.task_name}",
                f"   Team: {w.team}",
                f"   Owner: {w.owner or 'Unassigned'}",
                f"   Affected Teams: {w.affected_teams or w.team or 'Not recorded'}",
                f"   Business Impact: {w.business_impact_type or 'Employee Productivity'}",
                f"   Status: {w.status} ({days_in_stage(w.stage_entered_at)} days in stage)",
                f"   Score: {w.impact_score} | Priority: {w.recommendation}",
                f"   Readiness: {w.readiness_score}% | Confidence: {w.confidence} | Risk: {w.risk_level}",
                f"   Adoption: {w.adoption_rate_pct or 0}% | Quality: {w.quality_score_pct or 0}% | Expected Quality Gain: {w.expected_quality_gain_pct or 0}%",
                f"   Approval: {w.approval_status or 'Not Reviewed'} | Measurement Owner: {w.measurement_owner or 'Unassigned'} | Sample Size: {w.sample_size or 0}",
                f"   Before/After Cycle Time: {w.baseline_cycle_time_minutes or 0:g} -> {w.target_cycle_time_minutes or 0:g} minutes",
                f"   Evidence: {w.evidence_url or w.baseline_evidence_url or w.after_evidence_url or 'Not recorded'}",
                f"   Decision Needed: {w.decision_needed or 'Not recorded'}",
                f"   AI Suggestion: {w.ai_suggestion or 'Not generated'}",
                f"   Automation Plan: {w.automation_plan or 'Not generated'}",
                f"   Estimated Annual Saving: £{(w.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP:,}",
                (
                    f"   Confirmed Annual Saving: £{(w.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP:,.0f}"
                    if w.confirmed_saving_hours
                    else "   Confirmed Annual Saving: Not recorded yet"
                ),
                "   Prototype Task Plan:",
            ]

            for item in plan:
                lines.append(f"      - {item}")

            lines.append("")

        return "\n".join(lines)

    finally:
        db.close()


@app.get("/dashboard-ui", response_class=HTMLResponse)
def dashboard_ui():
    db = SessionLocal()

    try:
        workflows = db.query(WorkflowDB).order_by(WorkflowDB.impact_score.desc()).all()

        last_run = db.query(EngineRunDB).order_by(EngineRunDB.run_at.desc()).first()

    finally:
        db.close()

    total = len(workflows)

    estimated_saving = (
        sum(w.time_spent_per_week or 0 for w in workflows) * 52 * HOURLY_COST_GBP
    )

    deployed = [w for w in workflows if (w.status or "") == "Deployed"]

    confirmed_saving = (
        sum((w.confirmed_saving_hours or 0) for w in deployed) * 52 * HOURLY_COST_GBP
    )

    high_priority = sum(1 for w in workflows if (w.impact_score or 0) >= PRIORITY_HIGH)

    in_progress = sum(
        1
        for w in workflows
        if (w.status or "")
        in ["Validation Needed", "Under Review", "Prototype Built", "Pilot", "Scaling"]
    )

    adoption_values = [
        w.adoption_rate_pct or 0 for w in workflows if (w.adoption_rate_pct or 0) > 0
    ]

    quality_values = [
        w.quality_score_pct or 0 for w in workflows if (w.quality_score_pct or 0) > 0
    ]

    average_adoption = (
        round(sum(adoption_values) / len(adoption_values), 1) if adoption_values else 0
    )
    average_quality = (
        round(sum(quality_values) / len(quality_values), 1) if quality_values else 0
    )
    high_risk_count = sum(1 for w in workflows if (w.risk_level or "Medium") == "High")
    impact_mix = {}

    for w in workflows:
        impact_type = w.business_impact_type or "Employee Productivity"
        impact_mix[impact_type] = impact_mix.get(impact_type, 0) + 1

    impact_mix_html = (
        "".join(
            f"<div class='mix-row'><span>{escape(label)}</span><strong>{count}</strong></div>"
            for label, count in sorted(impact_mix.items())
        )
        or "<p class='sub'>No impact data yet.</p>"
    )

    engine_ready = sum(
        1
        for w in workflows
        if (w.status or "") in ["New", "Backlog", "Validation Needed"]
    )

    max_score = max((w.impact_score or 0 for w in workflows), default=1) or 1

    last_run_at = (
        last_run.run_at.strftime("%d %b %Y %H:%M")
        if last_run and last_run.run_at
        else "Not run yet"
    )

    last_analysed = last_run.analysed_workflows if last_run else 0
    last_updated = last_run.updated_workflows if last_run else 0
    last_review = last_run.high_priority_moved_to_review if last_run else 0
    last_backlog = last_run.low_priority_moved_to_backlog if last_run else 0
    last_protected = last_run.protected_unchanged if last_run else 0

    rows = ""

    for w in workflows:
        score = w.impact_score or 0
        status = w.status or "New"
        days = days_in_stage(w.stage_entered_at)
        confirmed = (w.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP
        stale = days > 14 and status not in ["Deployed", "Backlog"]
        action_label = get_action_label(status)

        if status == "Deployed":
            advance_button = '<button class="btn-done" disabled>Completed</button>'
        else:
            advance_button = f"""
            <button class="btn-adv" onclick="advanceStatus({w.id})">
                {escape(action_label)}
            </button>
            """

        note_html = ""

        if w.notes:
            short_note = escape((w.notes or "")[:72])
            if len(w.notes or "") > 72:
                short_note += "…"
            note_html = f"<div class='note-snip'>{short_note}</div>"

        confirmed_html = (
            "<strong>£" + f"{confirmed:,.0f}" + "</strong>/yr"
            if w.confirmed_saving_hours
            else "<span class='sub'>Not recorded</span>"
        )

        measurement_html = f"""
        <div><strong>{w.adoption_rate_pct or 0}%</strong> adoption</div>
        <div class="sub">{w.quality_score_pct or 0}% quality</div>
        """

        cycle_time_html = (
            f"{w.baseline_cycle_time_minutes or 0:g} -> {w.target_cycle_time_minutes or 0:g}m"
            if (w.baseline_cycle_time_minutes or w.target_cycle_time_minutes)
            else "<span class='sub'>Not measured</span>"
        )

        rows += f"""
        <tr data-status="{escape(status)}" data-priority="{escape(w.recommendation or '')}">
            <td>{escape(w.team or '')}</td>
            <td>
                <strong>{escape(w.task_name or '')}</strong>
                <div class="sub">{escape(w.frequency or '')}</div>
                {note_html}
            </td>
            <td><span class="owner-chip">{escape(w.owner or 'Unassigned')}</span></td>
            <td>{escape(w.affected_teams or w.team or '')}</td>
            <td>{escape(w.business_impact_type or 'Employee Productivity')}</td>
            <td>
                <span class="spill {get_status_class(status)}">{escape(status)}</span>
                <div class="sub{' stale' if stale else ''}">{days}d{' ⚠' if stale else ''}</div>
            </td>
            <td>{w.time_spent_per_week or 0}h</td>
            <td>{w.pain_level or 0}/5</td>
            <td><strong>{score}</strong></td>
            <td><span class="badge {get_badge_class(score)}">{escape(w.recommendation or '')}</span></td>
            <td>{escape(w.ai_suggestion or 'Not generated')}</td>
            <td>{escape(w.confidence or 'Medium')}</td>
            <td>{escape(w.risk_level or 'Medium')}</td>
            <td>{w.readiness_score or 0}%</td>
            <td>{cycle_time_html}</td>
            <td>{measurement_html}</td>
            <td><span class="nxt">{escape(generate_next_step(score, status))}</span></td>
            <td>{confirmed_html}</td>
            <td class="act-cell">
                {advance_button}
                <button class="btn-save" onclick="setSaving({w.id})">Set Saving</button>
                <button class="btn-brief" onclick="openBrief({w.id})">CEO Brief</button>
                <button class="btn-ai" onclick="reanalyze({w.id})">Reanalyse</button>
                <button class="btn-del" onclick="deleteWorkflow({w.id})">Remove</button>
            </td>
        </tr>
        """

    if not rows:
        rows = '<tr><td colspan="19" class="empty">No workflows yet — add one below.</td></tr>'

    chart_rows = ""

    for w in workflows:
        score = w.impact_score or 0
        bar = int(score / max_score * 100)

        chart_rows += f"""
        <div class="c-row">
            <div class="c-lbl">{escape(w.task_name or "")}</div>
            <div class="c-track">
                <div class="c-bar {get_badge_class(score)}" style="width:{bar}%"></div>
            </div>
            <div class="c-val">{score}</div>
        </div>
        """

    if not chart_rows:
        chart_rows = '<p class="sub">No data yet.</p>'

    spotlight = ""

    if workflows:
        top = workflows[0]
        top_estimated = (top.time_spent_per_week or 0) * 52 * HOURLY_COST_GBP
        top_confirmed = (top.confirmed_saving_hours or 0) * 52 * HOURLY_COST_GBP

        confirmed_part = ""

        if top.confirmed_saving_hours:
            confirmed_part = f" · confirmed <strong>£{top_confirmed:,.0f}/yr</strong>"

        spotlight = f"""
        <section class="spotlight">
            <div class="sp-body">
                <p class="eyebrow">Top opportunity</p>
                <h2>{escape(top.task_name or '')}</h2>
                <p>
                    <strong>{top.time_spent_per_week or 0} hrs/week</strong> manual effort ·
                    impact score <strong>{top.impact_score or 0}</strong> ·
                    estimated <strong>£{top_estimated:,}/yr</strong>{confirmed_part}
                </p>
                <p class="sub">
                    Owner: <strong>{escape(top.owner or 'Unassigned')}</strong> ·
                    Status: <strong>{escape(top.status or 'New')}</strong>
                    ({days_in_stage(top.stage_entered_at)}d) ·
                    Readiness: <strong>{top.readiness_score or 0}%</strong>
                </p>
            </div>
            <div class="sp-score">{top.impact_score or 0}<span>score</span></div>
        </section>
        """

    html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>AI Impact OS — Workflow Intelligence Engine</title>

<style>
:root {{
    --bg:#0a0d14;
    --surf:#111520;
    --surf2:#181d2a;
    --bord:#222840;
    --text:#e8eaf2;
    --muted:#8a92b2;
    --acc:#6c63ff;
    --acc2:#22d4a0;
    --danger:#ff4f6a;
    --warn:#f5a623;
    --r:16px;
    --r-sm:10px;
}}

* {{
    box-sizing:border-box;
    margin:0;
    padding:0;
}}

html {{
    scroll-behavior:smooth;
}}

body {{
    font-family:Arial,sans-serif;
    background:var(--bg);
    color:var(--text);
    font-size:14px;
    line-height:1.6;
}}

.layout {{
    display:flex;
    min-height:100vh;
}}

.sidebar {{
    width:240px;
    background:var(--surf);
    border-right:1px solid var(--bord);
    padding:28px 20px;
    position:fixed;
    top:0;
    bottom:0;
    left:0;
}}

.logo {{
    font-size:20px;
    font-weight:900;
    margin-bottom:28px;
}}

.logo span {{
    color:var(--acc);
}}

.nav {{
    display:block;
    text-decoration:none;
    padding:10px 14px;
    border-radius:var(--r-sm);
    color:var(--muted);
    font-weight:700;
    margin-bottom:6px;
}}

.nav:hover {{
    background:var(--surf2);
    color:var(--text);
}}

.nav.active {{
    background:var(--acc);
    color:#fff;
}}

.main {{
    margin-left:240px;
    padding:32px;
    width:calc(100% - 240px);
}}

.hero {{
    background:linear-gradient(135deg,#0f1929,#1a103d);
    border:1px solid var(--bord);
    border-radius:24px;
    padding:36px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:24px;
    margin-bottom:24px;
}}

.hero h1 {{
    font-size:34px;
    font-weight:900;
    margin-bottom:10px;
}}

.hero p {{
    color:#a9b0d0;
    max-width:680px;
}}

.hero-actions {{
    display:flex;
    flex-direction:column;
    gap:10px;
    align-items:flex-end;
}}

.pill {{
    background:rgba(255,255,255,.08);
    border:1px solid rgba(255,255,255,.12);
    padding:10px 18px;
    border-radius:999px;
    font-weight:800;
}}

.btn-engine,
.btn-submit {{
    background:var(--acc2);
    color:#061a14;
    padding:12px 20px;
    border-radius:999px;
    font-weight:900;
    border:none;
    cursor:pointer;
}}

.btn-link {{
    color:var(--text);
    text-decoration:none;
    background:rgba(255,255,255,.08);
    padding:10px 18px;
    border-radius:999px;
    font-weight:800;
    text-align:center;
}}

.eng-bar {{
    background:var(--surf);
    border:1px solid var(--bord);
    border-radius:var(--r);
    padding:20px 24px;
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}}

.eng-bar p {{
    color:var(--muted);
}}

.eng-log {{
    display:grid;
    grid-template-columns:repeat(6,1fr);
    gap:12px;
    margin-bottom:24px;
}}

.eng-tile {{
    background:var(--surf2);
    border:1px solid var(--bord);
    border-radius:var(--r);
    padding:16px;
}}

.eng-tile .lbl {{
    color:var(--muted);
    font-size:11px;
    text-transform:uppercase;
    letter-spacing:.8px;
}}

.eng-tile .val {{
    font-size:24px;
    font-weight:900;
}}

.kpis {{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:14px;
    margin-bottom:24px;
}}

.kpi {{
    background:var(--surf);
    border:1px solid var(--bord);
    border-radius:var(--r);
    padding:22px;
}}

.kpi .lbl {{
    color:var(--muted);
    font-size:12px;
    text-transform:uppercase;
    font-weight:800;
}}

.kpi .val {{
    font-size:28px;
    font-weight:900;
    margin-top:8px;
}}

.kpi .sub {{
    color:var(--muted);
    font-size:11px;
}}

.spotlight {{
    background:linear-gradient(135deg,var(--surf),var(--surf2));
    border:1px solid var(--acc);
    border-radius:24px;
    padding:28px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:24px;
    margin-bottom:24px;
}}

.eyebrow {{
    color:var(--acc);
    font-size:11px;
    font-weight:900;
    text-transform:uppercase;
    letter-spacing:1px;
}}

.sp-body h2 {{
    font-size:24px;
    margin:8px 0;
}}

.sp-score {{
    min-width:110px;
    height:110px;
    border-radius:50%;
    background:var(--acc);
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
    font-size:36px;
    font-weight:900;
}}

.sp-score span {{
    font-size:12px;
    opacity:.75;
}}

.two-col {{
    display:grid;
    grid-template-columns:1.3fr .7fr;
    gap:20px;
    margin-bottom:24px;
}}

.panel {{
    background:var(--surf);
    border:1px solid var(--bord);
    border-radius:var(--r);
    padding:24px;
}}

.panel h3 {{
    margin-bottom:18px;
}}

.mix-row {{
    display:flex;
    justify-content:space-between;
    gap:12px;
    padding:8px 0;
    border-bottom:1px solid var(--bord);
}}

.mix-row:last-child {{
    border-bottom:none;
}}

.c-row {{
    display:grid;
    grid-template-columns:160px 1fr 36px;
    align-items:center;
    gap:12px;
    margin-bottom:14px;
}}

.c-lbl {{
    overflow:hidden;
    white-space:nowrap;
    text-overflow:ellipsis;
}}

.c-track {{
    height:10px;
    background:var(--surf2);
    border-radius:99px;
    overflow:hidden;
}}

.c-bar {{
    height:100%;
    border-radius:99px;
}}

.c-bar.high {{
    background:var(--danger);
}}

.c-bar.medium {{
    background:var(--warn);
}}

.c-bar.low {{
    background:var(--acc2);
}}

form {{
    display:grid;
    gap:10px;
}}

input,
select,
textarea {{
    width:100%;
    padding:12px 14px;
    border-radius:var(--r-sm);
    border:1px solid var(--bord);
    background:var(--surf2);
    color:var(--text);
}}

textarea {{
    min-height:70px;
    resize:vertical;
}}

.filters {{
    display:flex;
    flex-wrap:wrap;
    gap:8px;
    margin-bottom:14px;
}}

.filter-btn {{
    background:var(--surf2);
    color:var(--text);
    border:1px solid var(--bord);
    padding:8px 12px;
    border-radius:999px;
    cursor:pointer;
}}

.filter-btn:hover {{
    border-color:var(--acc);
}}

.tbl-wrap {{
    background:var(--surf);
    border:1px solid var(--bord);
    border-radius:var(--r);
    overflow-x:auto;
    margin-bottom:24px;
}}

table {{
    width:100%;
    min-width:2300px;
    border-collapse:collapse;
}}

th {{
    background:var(--surf2);
    color:var(--muted);
    padding:14px 16px;
    text-align:left;
    font-size:11px;
    text-transform:uppercase;
    letter-spacing:.8px;
}}

td {{
    padding:14px 16px;
    border-bottom:1px solid var(--bord);
    vertical-align:top;
}}

tr:hover td {{
    background:rgba(255,255,255,.025);
}}

.sub {{
    color:var(--muted);
    font-size:12px;
    margin-top:3px;
}}

.stale {{
    color:var(--warn);
}}

.note-snip {{
    color:var(--muted);
    font-size:11px;
    margin-top:3px;
    font-style:italic;
}}

.empty {{
    text-align:center;
    color:var(--muted);
    padding:32px;
}}

.badge,
.spill,
.owner-chip,
.nxt {{
    display:inline-block;
    border-radius:999px;
    font-size:11px;
    font-weight:900;
    padding:5px 10px;
    white-space:nowrap;
}}

.badge.high {{
    background:rgba(255,79,106,.15);
    color:var(--danger);
}}

.badge.medium {{
    background:rgba(245,166,35,.15);
    color:var(--warn);
}}

.badge.low {{
    background:rgba(34,212,160,.12);
    color:var(--acc2);
}}

.s-new {{
    background:#1f2435;
    color:#9aa3d0;
}}

.s-backlog {{
    background:#1e2133;
    color:#8a92b2;
}}

.s-validation {{
    background:#2d2000;
    color:var(--warn);
}}

.s-review {{
    background:#001840;
    color:#60a5fa;
}}

.s-prototype {{
    background:#200060;
    color:#a78bfa;
}}

.s-pilot {{
    background:#352000;
    color:#facc15;
}}

.s-scaling {{
    background:#06283d;
    color:#38bdf8;
}}

.s-deployed {{
    background:#002515;
    color:var(--acc2);
}}

.owner-chip {{
    background:var(--surf2);
    border:1px solid var(--bord);
    color:var(--muted);
}}

.nxt {{
    background:rgba(34,212,160,.09);
    color:var(--acc2);
    line-height:1.3;
}}

.act-cell {{
    display:grid;
    gap:6px;
    min-width:130px;
}}

.btn-adv,
.btn-done,
.btn-del,
.btn-save,
.btn-brief,
.btn-ai {{
    padding:8px 12px;
    border-radius:var(--r-sm);
    font-weight:800;
    cursor:pointer;
    border:1px solid var(--bord);
}}

.btn-adv {{
    background:rgba(108,99,255,.18);
    color:#a78bfa;
}}

.btn-done {{
    background:var(--surf2);
    color:var(--muted);
    cursor:not-allowed;
}}

.btn-del {{
    background:rgba(255,79,106,.12);
    color:var(--danger);
}}

.btn-save {{
    background:rgba(34,212,160,.10);
    color:var(--acc2);
}}

.btn-brief {{
    background:rgba(108,99,255,.14);
    color:#c4b5fd;
}}

.btn-ai {{
    background:rgba(245,166,35,.12);
    color:var(--warn);
}}

.toast {{
    position:fixed;
    bottom:24px;
    right:24px;
    background:var(--surf2);
    border:1px solid var(--bord);
    color:var(--text);
    padding:14px 20px;
    border-radius:var(--r);
    opacity:0;
    transform:translateY(8px);
    transition:.25s;
    z-index:999;
    max-width:360px;
}}

.toast.show {{
    opacity:1;
    transform:translateY(0);
}}

.footer {{
    color:var(--muted);
    font-size:12px;
    padding:16px 0;
    border-top:1px solid var(--bord);
}}
</style>
</head>

<body>
<div class="layout">

<aside class="sidebar">
    <div class="logo">Threecolts <span>AI</span></div>
    <a class="nav active" href="#top">Dashboard</a>
    <a class="nav" href="#discovery">Discovery</a>
    <a class="nav" href="#engine">Engine</a>
    <a class="nav" href="#pipeline">Pipeline</a>
    <a class="nav" href="/executive-summary" target="_blank">Exec Summary</a>
    <a class="nav" href="/report" target="_blank">Report</a>
    <a class="nav" href="/export-csv" target="_blank">Export CSV</a>
</aside>

<main class="main" id="top">

<section class="hero">
    <div>
        <h1>AI Impact OS</h1>
        <p>
            Discover workflow bottlenecks, store AI-generated implementation plans,
            track stage history, compare estimated vs confirmed savings, and manage
            every opportunity through to deployment.
        </p>
    </div>

    <div class="hero-actions">
        <div class="pill">Ultimate · SQLAlchemy</div>
        <button class="btn-engine" onclick="runEngine()">Run Automation Engine</button>
        <a class="btn-link" href="/executive-summary" target="_blank">Executive Summary</a>
        <a class="btn-link" href="/export-csv" target="_blank">Export CSV</a>
    </div>
</section>

<section class="eng-bar" id="engine">
    <div>
        <h3>Automation Engine</h3>
        <p>{engine_ready} workflows ready for classification · engine history is saved in SQLAlchemy</p>
    </div>
    <button class="btn-engine" onclick="runEngine()">Run Engine</button>
</section>

<section class="eng-log">
    <div class="eng-tile">
        <div class="lbl">Last Run</div>
        <div class="val" style="font-size:14px">{escape(last_run_at)}</div>
    </div>

    <div class="eng-tile">
        <div class="lbl">Analysed</div>
        <div class="val">{last_analysed}</div>
    </div>

    <div class="eng-tile">
        <div class="lbl">Updated</div>
        <div class="val">{last_updated}</div>
    </div>

    <div class="eng-tile">
        <div class="lbl">To Review</div>
        <div class="val">{last_review}</div>
    </div>

    <div class="eng-tile">
        <div class="lbl">To Backlog</div>
        <div class="val">{last_backlog}</div>
    </div>

    <div class="eng-tile">
        <div class="lbl">Protected</div>
        <div class="val">{last_protected}</div>
    </div>
</section>

<section class="kpis">
    <div class="kpi">
        <div class="lbl">Workflows</div>
        <div class="val">{total}</div>
    </div>

    <div class="kpi">
        <div class="lbl">High Priority</div>
        <div class="val">{high_priority}</div>
    </div>

    <div class="kpi">
        <div class="lbl">In Progress</div>
        <div class="val">{in_progress}</div>
    </div>

    <div class="kpi">
        <div class="lbl">Est. Annual Saving</div>
        <div class="val">£{estimated_saving:,}</div>
        <div class="sub">at £{HOURLY_COST_GBP}/hr</div>
    </div>

    <div class="kpi">
        <div class="lbl">Confirmed Saving</div>
        <div class="val">£{confirmed_saving:,.0f}</div>
        <div class="sub">owner-reported actuals</div>
    </div>

    <div class="kpi">
        <div class="lbl">Avg Adoption</div>
        <div class="val">{average_adoption}%</div>
        <div class="sub">measured pilots and deployments</div>
    </div>

    <div class="kpi">
        <div class="lbl">Avg Quality</div>
        <div class="val">{average_quality}%</div>
        <div class="sub">owner validation score</div>
    </div>

    <div class="kpi">
        <div class="lbl">High Risk</div>
        <div class="val">{high_risk_count}</div>
        <div class="sub">needs controls before scale</div>
    </div>
</section>

{spotlight}

<section class="two-col" id="discovery">
    <div class="panel">
        <h3>Impact Score Ranking</h3>
        {chart_rows}
    </div>

    <div class="panel">
        <h3>Business Impact Mix</h3>
        {impact_mix_html}
    </div>

    <div class="panel">
        <h3>Add New Workflow</h3>

        <form onsubmit="submitWorkflow(event)">
            <input id="team" placeholder="Team e.g. Customer Support" required>
            <input id="task_name" placeholder="Task e.g. Manual ticket categorisation" required>
            <input id="owner" placeholder="Owner e.g. Support Lead">
            <input id="affected_teams" placeholder="Affected teams e.g. Support, Ops, Finance">

            <select id="business_impact_type">
                <option value="Employee Productivity">Employee Productivity</option>
                <option value="Cost Saving">Cost Saving</option>
                <option value="Revenue Growth">Revenue Growth</option>
                <option value="Risk Reduction">Risk Reduction</option>
                <option value="Customer Experience">Customer Experience</option>
                <option value="Quality Improvement">Quality Improvement</option>
            </select>

            <input id="time_spent" type="number" min="0" max="168" placeholder="Hours spent per week" required>
            <input id="baseline_cycle_time" type="number" min="0" max="10080" placeholder="Current cycle time minutes">
            <input id="target_cycle_time" type="number" min="0" max="10080" placeholder="Target cycle time minutes">
            <input id="expected_quality_gain" type="number" min="0" max="100" placeholder="Expected quality gain %">

            <select id="pain_level" required>
                <option value="">Pain level</option>
                <option value="1">1 - Low</option>
                <option value="2">2</option>
                <option value="3">3 - Medium</option>
                <option value="4">4</option>
                <option value="5">5 - High</option>
            </select>

            <input id="frequency" placeholder="Frequency e.g. Daily / Weekly" required>
            <textarea id="notes" placeholder="Problem notes or evidence summary"></textarea>
            <input id="evidence_url" placeholder="Evidence URL optional">
            <input id="baseline_evidence_url" placeholder="Baseline evidence URL optional">
            <input id="after_evidence_url" placeholder="After evidence URL optional">
            <input id="measurement_owner" placeholder="Measurement owner optional">
            <input id="sample_size" type="number" min="0" placeholder="Sample size optional">

            <select id="approval_status">
                <option value="Not Reviewed">Approval status: Not Reviewed</option>
                <option value="Needs Evidence">Needs Evidence</option>
                <option value="Ready for Review">Ready for Review</option>
                <option value="Approved">Approved</option>
                <option value="Rejected">Rejected</option>
            </select>

            <textarea id="decision_needed" placeholder="Decision needed optional"></textarea>

            <button type="submit" class="btn-submit">Add Workflow + AI Analysis</button>
        </form>
    </div>
</section>

<section id="pipeline">
    <div class="filters">
        <button class="filter-btn" onclick="filterRows('All')">All</button>
        <button class="filter-btn" onclick="filterRows('High Priority')">High Priority</button>
        <button class="filter-btn" onclick="filterRows('Under Review')">Under Review</button>
        <button class="filter-btn" onclick="filterRows('Validation Needed')">Validation Needed</button>
        <button class="filter-btn" onclick="filterRows('Prototype Built')">Prototype Built</button>
        <button class="filter-btn" onclick="filterRows('Pilot')">Pilot</button>
        <button class="filter-btn" onclick="filterRows('Scaling')">Scaling</button>
        <button class="filter-btn" onclick="filterRows('Deployed')">Deployed</button>
        <button class="filter-btn" onclick="filterRows('Backlog')">Backlog</button>
    </div>

    <div class="tbl-wrap">
        <table>
            <thead>
                <tr>
                    <th>Team</th>
                    <th>Workflow</th>
                    <th>Owner</th>
                    <th>Affected Teams</th>
                    <th>Impact Type</th>
                    <th>Status</th>
                    <th>Hrs/Wk</th>
                    <th>Pain</th>
                    <th>Score</th>
                    <th>Priority</th>
                    <th>AI Suggestion</th>
                    <th>Confidence</th>
                    <th>Risk</th>
                    <th>Readiness</th>
                    <th>Before/After</th>
                    <th>Adoption/Quality</th>
                    <th>Next Step</th>
                    <th>Confirmed Saving</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>{rows}</tbody>
        </table>
    </div>
</section>

<div class="footer">
    AI Impact OS — Workflow Intelligence Engine · FastAPI + SQLAlchemy + SQLite · Gemini-ready · £{HOURLY_COST_GBP}/hr assumption
</div>

</main>
</div>

<div class="toast" id="toast"></div>

<script>
function toast(message) {{
    const el = document.getElementById('toast');
    el.textContent = message;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 3200);
}}

async function submitWorkflow(event) {{
    event.preventDefault();

    const btn = event.target.querySelector('.btn-submit');
    btn.textContent = 'Analysing...';
    btn.disabled = true;

    const payload = {{
        team: document.getElementById('team').value,
        task_name: document.getElementById('task_name').value,
        owner: document.getElementById('owner').value,
        affected_teams: document.getElementById('affected_teams').value,
        business_impact_type: document.getElementById('business_impact_type').value,
        time_spent_per_week: parseInt(document.getElementById('time_spent').value),
        baseline_cycle_time_minutes: parseFloat(document.getElementById('baseline_cycle_time').value || '0'),
        target_cycle_time_minutes: parseFloat(document.getElementById('target_cycle_time').value || '0'),
        expected_quality_gain_pct: parseInt(document.getElementById('expected_quality_gain').value || '0'),
        pain_level: parseInt(document.getElementById('pain_level').value),
        frequency: document.getElementById('frequency').value,
        notes: document.getElementById('notes').value,
        evidence_url: document.getElementById('evidence_url').value,
        baseline_evidence_url: document.getElementById('baseline_evidence_url').value,
        after_evidence_url: document.getElementById('after_evidence_url').value,
        measurement_owner: document.getElementById('measurement_owner').value,
        sample_size: parseInt(document.getElementById('sample_size').value || '0'),
        approval_status: document.getElementById('approval_status').value,
        decision_needed: document.getElementById('decision_needed').value
    }};

    const response = await fetch('/submit-workflow', {{
        method: 'POST',
        headers: {{ 'Content-Type': 'application/json' }},
        body: JSON.stringify(payload)
    }});

    if (response.ok) {{
        const data = await response.json();
        toast('Added · Score ' + data.impact_score + ' · ' + data.recommendation);
        setTimeout(() => location.reload(), 900);
    }} else {{
        btn.textContent = 'Add Workflow + AI Analysis';
        btn.disabled = false;
        toast('Something went wrong. Check terminal.');
    }}
}}

async function runEngine() {{
    toast('Running automation engine...');

    const response = await fetch('/run-automation-engine', {{
        method: 'POST'
    }});

    if (response.ok) {{
        const data = await response.json();
        toast('Engine complete · ' + data.updated + ' workflows updated');
        setTimeout(() => location.reload(), 900);
    }} else {{
        toast('Engine failed. Check terminal.');
    }}
}}

async function advanceStatus(id) {{
    const response = await fetch('/advance-status/' + id, {{
        method: 'PUT'
    }});

    if (response.ok) {{
        const data = await response.json();
        toast('Moved to ' + data.new_status);
        setTimeout(() => location.reload(), 700);
    }} else {{
        toast('Could not update status.');
    }}
}}

function openBrief(id) {{
    window.open('/workflows/' + id + '/brief', '_blank');
}}

async function setSaving(id) {{
    const value = prompt('Enter confirmed weekly hours saved:');

    if (value === null || value === '') {{
        return;
    }}

    const adoption = prompt('Enter adoption rate %:', '0');
    const quality = prompt('Enter quality score %:', '0');

    const response = await fetch('/workflows/' + id + '/confirmed-saving', {{
        method: 'PUT',
        headers: {{ 'Content-Type': 'application/json' }},
        body: JSON.stringify({{
            confirmed_saving_hours: parseFloat(value),
            adoption_rate_pct: parseInt(adoption || '0'),
            quality_score_pct: parseInt(quality || '0')
        }})
    }});

    if (response.ok) {{
        toast('Confirmed saving updated');
        setTimeout(() => location.reload(), 700);
    }} else {{
        toast('Could not update saving.');
    }}
}}

async function reanalyze(id) {{
    toast('Reanalysing workflow...');

    const response = await fetch('/workflows/' + id + '/reanalyse', {{
        method: 'POST'
    }});

    if (response.ok) {{
        toast('AI analysis refreshed');
        setTimeout(() => location.reload(), 900);
    }} else {{
        toast('Could not reanalyse.');
    }}
}}

async function deleteWorkflow(id) {{
    if (!confirm('Remove this workflow?')) {{
        return;
    }}

    const response = await fetch('/delete-workflow/' + id, {{
        method: 'DELETE'
    }});

    if (response.ok) {{
        toast('Workflow removed');
        setTimeout(() => location.reload(), 700);
    }} else {{
        toast('Could not delete workflow.');
    }}
}}

function filterRows(filter) {{
    const rows = document.querySelectorAll('tbody tr');

    rows.forEach(row => {{
        const status = row.getAttribute('data-status') || '';
        const priority = row.getAttribute('data-priority') || '';

        if (filter === 'All' || status === filter || priority === filter) {{
            row.style.display = '';
        }} else {{
            row.style.display = 'none';
        }}
    }});
}}
</script>

</body>
</html>
"""

    return html


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
